const React = require('D:/PrintGo-S3K-MULTIPRINTER-CANDIDATE/frontend/node_modules/react');
const ReactDOMServer = require('D:/PrintGo-S3K-MULTIPRINTER-CANDIDATE/frontend/node_modules/react-dom/server');
const { QRCodeSVG } = require('D:/PrintGo-S3K-MULTIPRINTER-CANDIDATE/frontend/node_modules/qrcode.react/lib/index.js');
const fs = require('fs');
const path = require('path');

const flyersDir = 'D:/PrintGo-S3K-MULTIPRINTER-CANDIDATE/counter_flyers';
if (!fs.existsSync(flyersDir)) {
  fs.mkdirSync(flyersDir, { recursive: true });
}

function generateHtmlFlyer({ title, subtitle, model, queueName, deviceId, publicCode, targetUrl, accentColor }) {
  const qrSvg = ReactDOMServer.renderToStaticMarkup(
    React.createElement(QRCodeSVG, {
      value: targetUrl,
      size: 260,
      level: 'H'
    })
  );

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>${title} — PrintGo Customer Counter Stand</title>
  <style>
    @page { size: A4 portrait; margin: 0; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
      margin: 0;
      padding: 0;
      background: #f8fafc;
      color: #0f172a;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
    }
    .flyer-card {
      width: 500px;
      background: white;
      border-radius: 24px;
      box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
      border: 1px solid #e2e8f0;
      overflow: hidden;
      text-align: center;
      padding-bottom: 32px;
    }
    .header {
      background: linear-gradient(135deg, ${accentColor}, #1e293b);
      color: white;
      padding: 36px 24px;
    }
    .brand-title {
      font-size: 32px;
      font-weight: 900;
      letter-spacing: -0.04em;
      margin: 0 0 8px 0;
    }
    .brand-title span {
      color: #38bdf8;
    }
    .tagline {
      font-size: 14px;
      opacity: 0.9;
      margin: 0;
      font-weight: 500;
    }
    .device-badge {
      display: inline-block;
      margin-top: 16px;
      padding: 6px 14px;
      background: rgba(255, 255, 255, 0.15);
      backdrop-filter: blur(8px);
      border-radius: 9999px;
      font-size: 13px;
      font-weight: 600;
      letter-spacing: 0.02em;
    }
    .content {
      padding: 28px;
    }
    .qr-container {
      display: inline-flex;
      padding: 20px;
      background: white;
      border-radius: 20px;
      box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.08), 0 4px 6px -2px rgba(0, 0, 0, 0.04);
      border: 2px solid #f1f5f9;
      margin-bottom: 24px;
    }
    .instructions {
      text-align: left;
      background: #f8fafc;
      border-radius: 16px;
      padding: 16px 20px;
      margin: 0 auto;
      max-width: 400px;
      border: 1px solid #e2e8f0;
    }
    .instruction-step {
      display: flex;
      align-items: center;
      margin-bottom: 10px;
      font-size: 13px;
      font-weight: 500;
      color: #334155;
    }
    .instruction-step:last-child {
      margin-bottom: 0;
    }
    .step-num {
      width: 22px;
      height: 22px;
      background: ${accentColor};
      color: white;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 11px;
      font-weight: 700;
      margin-right: 12px;
      flex-shrink: 0;
    }
    .footer-meta {
      margin-top: 24px;
      font-size: 11px;
      color: #94a3b8;
    }
    .footer-meta span {
      display: block;
      margin-bottom: 2px;
    }
  </style>
</head>
<body>
  <div class="flyer-card">
    <div class="header">
      <h1 class="brand-title">Print<span>Go</span></h1>
      <p class="tagline">Autonomous Kiosk Printing — Scan & Print in Seconds</p>
      <div class="device-badge">${model}</div>
    </div>
    <div class="content">
      <h2 style="font-size: 20px; font-weight: 800; margin: 0 0 16px 0; color: #1e293b;">
        Scan to Print Here
      </h2>
      <div class="qr-container">
        ${qrSvg}
      </div>
      <div class="instructions">
        <div class="instruction-step">
          <div class="step-num">1</div>
          <div>Scan this QR code with any smartphone camera</div>
        </div>
        <div class="instruction-step">
          <div class="step-num">2</div>
          <div>Upload PDF or document (mobile data supported)</div>
        </div>
        <div class="instruction-step">
          <div class="step-num">3</div>
          <div>Choose settings & pay securely via UPI/QR</div>
        </div>
        <div class="instruction-step">
          <div class="step-num">4</div>
          <div>Collect your print immediately from this tray</div>
        </div>
      </div>
      <div class="footer-meta">
        <span>Station: ${title}</span>
        <span>Dedicated Queue: ${queueName}</span>
        <span>Device ID: ${deviceId}</span>
        <span>Flyer Token: ${publicCode}</span>
      </div>
    </div>
  </div>
</body>
</html>`;
}

function main() {
  const hpData = {
    title: 'HP LaserJet M1136 Station',
    subtitle: 'Dedicated Fast Black & White Printing',
    model: 'HP LaserJet Professional M1136 MFP',
    queueName: 'HP LaserJet Professional M1136 MFP (Copy 1)',
    deviceId: '77554510-b102-40c7-957f-6f735eba0bdc',
    publicCode: 'pq_Tp3gOvtvpYUW4IlDVWFG-yOYfbG1AK6r2qjGh1z_zuo',
    targetUrl: 'https://printgo-customer-staging.onrender.com/p/pq_Tp3gOvtvpYUW4IlDVWFG-yOYfbG1AK6r2qjGh1z_zuo',
    accentColor: '#0284c7' // Blue accent
  };

  const canonData = {
    title: 'Canon imageRUNNER ADV 4545 Station',
    subtitle: 'Heavy-Duty High-Speed Commercial Printing',
    model: 'Canon imageRUNNER ADV 4545',
    queueName: 'Canon Generic Plus UFR II (Copy 2)',
    deviceId: '114c0092-e3c6-4432-b17f-e7c6f42ec334',
    publicCode: 'pq_Zw10AK2C_MBdtbyJti_h5qE4jy1DcSN0rsmd0gFBMn4',
    targetUrl: 'https://printgo-customer-staging.onrender.com/p/pq_Zw10AK2C_MBdtbyJti_h5qE4jy1DcSN0rsmd0gFBMn4',
    accentColor: '#dc2626' // Canon Red accent
  };

  // Generate HP Flyer & SVG
  const hpHtml = generateHtmlFlyer(hpData);
  const hpSvg = ReactDOMServer.renderToStaticMarkup(
    React.createElement(QRCodeSVG, { value: hpData.targetUrl, size: 500, level: 'H' })
  );
  fs.writeFileSync(path.join(flyersDir, 'hp_m1136_counter_flyer.html'), hpHtml, 'utf8');
  fs.writeFileSync(path.join(flyersDir, 'hp_m1136_qr.svg'), hpSvg, 'utf8');

  // Generate Canon Flyer & SVG
  const canonHtml = generateHtmlFlyer(canonData);
  const canonSvg = ReactDOMServer.renderToStaticMarkup(
    React.createElement(QRCodeSVG, { value: canonData.targetUrl, size: 500, level: 'H' })
  );
  fs.writeFileSync(path.join(flyersDir, 'canon_4545_counter_flyer.html'), canonHtml, 'utf8');
  fs.writeFileSync(path.join(flyersDir, 'canon_4545_qr.svg'), canonSvg, 'utf8');

  console.log('✅ Generated HP Flyer:', path.join(flyersDir, 'hp_m1136_counter_flyer.html'));
  console.log('✅ Generated HP QR SVG:', path.join(flyersDir, 'hp_m1136_qr.svg'));
  console.log('✅ Generated Canon Flyer:', path.join(flyersDir, 'canon_4545_counter_flyer.html'));
  console.log('✅ Generated Canon QR SVG:', path.join(flyersDir, 'canon_4545_qr.svg'));
}

main();
