# PRINTGO — PHASE 9.1: DESIGN HARDENING REVIEW REPORT

**Execution Mode:** READ-ONLY DESIGN HARDENING REVIEW  
**Workspace:** `D:\PrintGo-S3K-MULTIPRINTER-CANDIDATE`  
**Backend:** Staging only  
**Agent PID:** `10940` (Running, untouched)  
**Host:** `DESKTOP-QB6Q3BC` (`192.168.1.10`)  
**Target Machine ID:** `d010496f-f176-41fe-9c98-efd2213a4a0e` (`Main Shop Printer`)  
**Approved Epson Device ID:** `619665e1-3c64-44eb-8f57-cb8c3c895e9b` (`EPSON L6460 Series`, `isDefault: true`)  
**Public QR Flyer:** `pq_YCuM5Lr2_nQMuxahsrBqjb9jWQSUhMDPd0Cbl_tpDB8`

---

## 1. Baseline Git Status & Working Tree Safety

### 1.1 Invariant: No Clean Working Tree Requirement
In accordance with instructions, this design explicitly **does not require a clean working tree**. Pre-existing uncommitted modifications in frontend, backend, and documentation files are recognized, isolated, and strictly protected.

### 1.2 Baseline Inventory of Uncommitted Files:
- **Pre-existing Frontend Modifications:**
  - `frontend/src/components/DocumentPreviewModal.jsx` (Modified)
  - `frontend/src/components/admin/views/PrinterFleetApprovalPanel.jsx` (Modified)
  - `frontend/src/__tests__/printer_fleet_approval_panel.test.jsx` (Untracked)
- **Pre-existing Backend Modifications (Phase 1 WebSocket Sync):**
  - `backend/src/modules/admin/printerDiscovery.admin.controller.js` (Modified)
  - `backend/src/services/printerAgentProtocol.service.js` (Modified)
  - `backend/tests/printer_agent_protocol.test.js` (Modified)
  - `backend/logs/combined.log`, `backend/logs/error.log` (Modified)
  - `backend/scratch/` (Untracked)
- **Pre-existing Candidate Agent Implementation (Phase 6):**
  - `printer-agent/src/printerFleetManager.js` (Modified)
  - `printer-agent/src/printerStatusMapping.js` (Modified)
  - `printer-agent/src/spooler.js` (Modified)
  - `printer-agent/tests/printerStatusMapping.test.js` (Modified)
  - `printer-agent/tests/spooler.test.js` (Modified)
  - `printer-agent/src/networkConnectivity.js` (Untracked)
  - `printer-agent/tests/contextualPrinterHealth.test.js` (Untracked)
- **Phase Reports (25 Untracked Markdown Files):** All preserved.

> [!IMPORTANT]
> Git commands `checkout`, `reset`, `clean`, and `stash` are **STRICTLY FORBIDDEN**. Implementation changes will touch only explicitly targeted files without altering unrelated user work.

---

## 2. Hardened Timestamp Safety & Concurrency Model

### 2.1 Server Receipt Time vs. Agent Event Time
- **Server Receipt Time (`serverReceiptTime = new Date()`):** The exact cloud timestamp when the backend socket receives the `'printer_status_update'` packet.
- **Agent Event Time (`eventDate = new Date(eventTimeMs)`):** The client timestamp when the physical spooler and TCP socket query occurred.
- **Rule:** Telemetry freshness and database records (`lastTelemetryAt`, `PrinterStatus.timestamp`) must reflect `eventDate`. `PrinterStatus.createdAt` records `serverReceiptTime`.

### 2.2 Strict Rejection of Invalid, Stale, and Future Timestamps
Instead of silently substituting the server timestamp, invalid timestamps must fail closed and be **REJECTED**:

```javascript
// 1. Missing or non-string timestamp
if (!status.timestamp || typeof status.timestamp !== 'string') {
  logger?.warn?.(`Rejected telemetry from Machine ${socket.machineId}: missing timestamp`);
  return { accepted: false, code: 'MISSING_TIMESTAMP' };
}

// 2. Unparseable ISO-8601 string
const eventTimeMs = Date.parse(status.timestamp);
if (!Number.isFinite(eventTimeMs)) {
  logger?.warn?.(`Rejected telemetry from Machine ${socket.machineId}: unparseable timestamp "${status.timestamp}"`);
  return { accepted: false, code: 'INVALID_TIMESTAMP' };
}

// 3. Excessive Future Clock Skew (>30s)
const serverReceiptTimeMs = Date.now();
const MAX_FUTURE_SKEW_MS = 30 * 1000;
if (eventTimeMs > serverReceiptTimeMs + MAX_FUTURE_SKEW_MS) {
  logger?.warn?.(`Rejected future-skewed telemetry from Machine ${socket.machineId}: ${eventTimeMs - serverReceiptTimeMs}ms in future`);
  return { accepted: false, code: 'FUTURE_TIMESTAMP' };
}

// 4. Stale Telemetry (>180s old)
const MAX_EVENT_AGE_MS = 180 * 1000; // Aligns with TELEMETRY_STALE_WINDOW_MS
if (serverReceiptTimeMs - eventTimeMs > MAX_EVENT_AGE_MS) {
  logger?.warn?.(`Rejected stale telemetry from Machine ${socket.machineId}: ${serverReceiptTimeMs - eventTimeMs}ms old`);
  return { accepted: false, code: 'STALE_TELEMETRY' };
}

const eventDate = new Date(eventTimeMs);
```

### 2.3 Atomic Out-of-Order & Concurrency Protection
To prevent out-of-order WebSocket packets or concurrent socket events from overwriting newer device telemetry:

```javascript
// Atomic monotonic update in PostgreSQL via Prisma updateMany
const updateResult = await prisma.printerDevice.updateMany({
  where: {
    id: device.id,
    machineId: socket.machineId,
    OR: [
      { lastTelemetryAt: null },
      { lastTelemetryAt: { lt: eventDate } }
    ]
  },
  data: {
    healthStatus,
    lastTelemetryAt: eventDate
  }
});

// If count === 0, a newer or identical packet was already written
if (updateResult.count === 0) {
  logger?.info?.(`Ignored out-of-order or duplicate telemetry for device ${device.id} (Event: ${status.timestamp})`);
  return {
    accepted: true,
    code: 'OUT_OF_ORDER_IGNORED',
    printerDeviceId: device.id,
    bridged: false
  };
}
```
- **Concurrency Guarantee:** `updateMany` executes an atomic conditional `UPDATE "PrinterDevice" ... WHERE "lastTelemetryAt" < eventDate` in PostgreSQL. If two packets race, only the strictly newer timestamp succeeds. The older packet is safely dropped without locks or race conditions.

---

## 3. Default Device Uniqueness & Machine Isolation

### 3.1 Strict Default Device Uniqueness Verification
Before executing any bridge mutation to the Machine-wide availability stream:
```javascript
const activeDefaultDevices = await prisma.printerDevice.findMany({
  where: {
    machineId: socket.machineId,
    status: 'ACTIVE',
    approvedAt: { not: null },
    windowsPrinterName: { not: null },
    isDefault: true
  },
  select: { id: true }
});

// Case A: Zero active default devices
if (activeDefaultDevices.length === 0) {
  logger?.warn?.(`Machine ${socket.machineId} has no active approved default device. Bridging skipped.`);
  return { accepted: true, printerDeviceId: device.id, healthStatus, bridged: false, reason: 'NO_ACTIVE_DEFAULT_DEVICE' };
}

// Case B: Invariant violation: Multiple active default devices
if (activeDefaultDevices.length > 1) {
  logger?.error?.(`Invariant violation: Machine ${socket.machineId} has ${activeDefaultDevices.length} active default devices. Bridging blocked.`);
  return { accepted: true, printerDeviceId: device.id, healthStatus, bridged: false, reason: 'MULTIPLE_DEFAULT_DEVICES_DETECTED' };
}

// Case C: Emitting device is NOT the confirmed active default device
if (activeDefaultDevices[0].id !== device.id) {
  // Emitting device is an active secondary printer (e.g. Canon or HP)
  return { accepted: true, printerDeviceId: device.id, healthStatus, bridged: false, reason: 'SECONDARY_DEVICE' };
}

// Case D: Confirmed sole active default device (Epson)
// Proceed to Bridge Mutation!
```

---

## 4. Health Policy, UNKNOWN Preserving & Customer Status

### 4.1 Consumable State Preservation (Safeguard 4)
- **Zero Fabrication:** The bridge explicitly permits `'UNKNOWN'` and preserves agent telemetry.
```javascript
const sourceTelemetry = isPlainObject(status.telemetry) ? status.telemetry : {};
const rawPaper = typeof sourceTelemetry.paperStatus === 'string'
  ? sourceTelemetry.paperStatus.toUpperCase().trim()
  : '';
const rawToner = typeof sourceTelemetry.tonerStatus === 'string'
  ? sourceTelemetry.tonerStatus.toUpperCase().trim()
  : '';

const validPaperStatus = ['OK', 'LOW', 'OUT', 'UNKNOWN'].includes(rawPaper)
  ? rawPaper
  : (message.includes('out of paper') || message.includes('paper out') ? 'OUT' : 'UNKNOWN');

const validTonerStatus = ['OK', 'LOW', 'EMPTY', 'UNKNOWN'].includes(rawToner)
  ? rawToner
  : 'UNKNOWN';
```
- If the Agent sends `paperStatus: 'UNKNOWN'`, it is stored in `PrinterStatus.paperStatus` as `'UNKNOWN'`. It is **never converted to `'OK'`**.

### 4.2 TCP Connectivity + Contextual `canPrint` vs. Customer "Printer Ready"
- **Architectural Policy:**  
  When an approved network printer reports WMI `DetectedErrorState: 0` (Unknown), queue is not offline, queue status is Idle (`3`) or Printing (`4`), and raw TCP 9100 socket connectivity succeeds:
  - The printer is physically online and capable of printing.
  - The bridge marks `isOnline: true`, `healthStatus: 'ONLINE'`.
  - Customer QR API returns:
    - `isOnline: true`
    - `hardwareStatus: 'ONLINE'`
    - `statusMessage: 'Printer Ready'`
  - **Simultaneous Diagnostic Transparency:**
    - `paperStatus: 'UNKNOWN'`
    - `tonerStatus: 'UNKNOWN'`
  - This accurately communicates that the device is available for print jobs, without falsely claiming hardware consumable supplies are known.

### 4.3 Explicit Behavior for Fault States
| Condition | Agent Output | `PrinterDevice.healthStatus` | `PrinterStatus.isOnline` | Customer QR `hardwareStatus` | Customer QR `statusMessage` | Customer QR `isOnline` |
| :--- | :--- | :--- | :---: | :--- | :--- | :---: |
| **Normal Ready (TCP OK, WMI 0)** | `isError: false` | `ONLINE` | `true` | `ONLINE` | `Printer Ready` | `true` |
| **WorkOffline === true** | `isError: true, errorMessage: 'Printer Offline'` | `OFFLINE` | `false` | `OFFLINE` | `Physical Printer Offline` | `false` |
| **TCP Port Unreachable** | `isError: true, errorMessage: 'Network Printer Unreachable'` | `OFFLINE` | `false` | `OFFLINE` | `Physical Printer Offline` | `false` |
| **TCP Port Timeout** | `isError: true, errorMessage: 'Network Connectivity Timeout'` | `OFFLINE` | `false` | `OFFLINE` | `Physical Printer Offline` | `false` |
| **Out of Paper** | `isError: true, errorMessage: 'Out of Paper'` | `PAPER_OUT` | `false` | `PAPER_OUT` | `Out of Paper` | `false` |
| **Paper Jam** | `isError: true, errorMessage: 'Paper Jam'` | `JAMMED` | `false` | `JAMMED` | `Paper Jam` | `false` |
| **Telemetry Stale (>180s)** | Agent stopped / crashed | Stale timestamp | Stale row | `UNKNOWN` | `Printer Status Unavailable` | `false` |

---

## 5. Database Write Strategy & Transaction Boundaries

### 5.1 Atomic Bridge Transaction
When `isEligibleDefaultBridge === true`, all machine-level updates are committed in an explicit transaction:
```javascript
await prisma.$transaction(async (tx) => {
  // 1. Update Machine metadata
  await tx.machine.update({
    where: { id: socket.machineId },
    data: {
      lastOnline: serverReceiptTime,
      printerModel: device.printerModel || device.displayName,
      connectionType
    }
  });

  // 2. Insert fresh Machine-level PrinterStatus row bound to default device
  await tx.printerStatus.create({
    data: {
      machineId: socket.machineId,
      printerDeviceId: device.id,
      isOnline: !status.isError,
      paperStatus: validPaperStatus,
      tonerStatus: validTonerStatus,
      jamStatus: message.includes('paper jam') || message.includes('jam'),
      connectionType: connectionType || undefined,
      timestamp: eventDate
    }
  });
});
```

---

## 6. Comprehensive 13-Case Test Matrix

| # | Test Suite | Test Scenario | Verified Assertions |
| :---: | :--- | :--- | :--- |
| **1** | `printer_agent_protocol.test.js` | Approved Default Printer (`isDefault: true`) | Updates `PrinterDevice`, updates `Machine`, inserts `PrinterStatus` row with `printerDeviceId`, broadcasts availability. |
| **2** | `printer_agent_protocol.test.js` | Approved Non-Default Printer (`isDefault: false`) | Updates `PrinterDevice` only. **Zero rows created in `PrinterStatus`**, `Machine` untouched. |
| **3** | `printer_agent_protocol.test.js` | Disabled or Unapproved Default Printer | Bridges blocked; returns `bridged: false`. `PrinterStatus` untouched. |
| **4** | `printer_agent_protocol.test.js` | Zero Default Devices | Returns `NO_ACTIVE_DEFAULT_DEVICE`. `PrinterStatus` untouched. |
| **5** | `printer_agent_protocol.test.js` | Multiple Default Devices Invariant Check | Returns `MULTIPLE_DEFAULT_DEVICES_DETECTED`. Bridge safely aborted. |
| **6** | `printer_agent_protocol.test.js` | UNKNOWN Paper and Toner Preservation | Asserts `paperStatus: 'UNKNOWN'` and `tonerStatus: 'UNKNOWN'` are stored verbatim without converting to `'OK'`. |
| **7** | `printer_agent_protocol.test.js` | `WorkOffline === true` | Maps to `healthStatus: 'OFFLINE'`, `isOnline: false`. |
| **8** | `printer_agent_protocol.test.js` | TCP Failure & Timeout | Maps to `healthStatus: 'OFFLINE'`, `isOnline: false`. |
| **9** | `printer_agent_protocol.test.js` | Hardware Error & Paper Jam | Maps to `healthStatus: 'JAMMED'`, `isOnline: false, jamStatus: true`. |
| **10** | `printer_agent_protocol.test.js` | Timestamp Validation Boundary: Missing, Invalid, Future, Stale | Rejects with `MISSING_TIMESTAMP`, `INVALID_TIMESTAMP`, `FUTURE_TIMESTAMP`, `STALE_TELEMETRY`. |
| **11** | `printer_agent_protocol.test.js` | Out-of-Order & Concurrent Telemetry Guard | Atomic `updateMany` returns count 0; rejects with `OUT_OF_ORDER_IGNORED`. Newer timestamp preserved. |
| **12** | `phase2_printer_qr_services_and_api.test.js` | Machine-Level QR Metadata Enrichment | Public QR returns `printerDeviceId: "619665e1..."`, `deviceHealth: "ONLINE"`, `isOnline: true`. |
| **13** | Regression | Existing User Modifications Preservation | Confirms pre-existing frontend (`DocumentPreviewModal.jsx`, `PrinterFleetApprovalPanel.jsx`) and Phase 1 backend code remain intact. |

---

## 7. Implementation Commands & Rollback Strategy

### 7.1 Proposed Test Execution Commands
```powershell
# Run the hardened protocol suite
npm --prefix D:\PrintGo-S3K-MULTIPRINTER-CANDIDATE\backend test -- printer_agent_protocol.test.js

# Run the customer QR API suite
npm --prefix D:\PrintGo-S3K-MULTIPRINTER-CANDIDATE\backend test -- phase2_printer_qr_services_and_api.test.js

# Run full backend regression suite
npm --prefix D:\PrintGo-S3K-MULTIPRINTER-CANDIDATE\backend test
```

### 7.2 Safe Targeted Rollback Strategy
If rollback is required after implementation:
```powershell
# Safely restore only the files modified in Phase 9
git -C D:\PrintGo-S3K-MULTIPRINTER-CANDIDATE checkout -- backend/src/services/printerAgentProtocol.service.js backend/src/socket.js backend/src/services/printerQr.service.js backend/tests/printer_agent_protocol.test.js
```
- **Safety Guarantee:** Targets only the 4 specific implementation files. Does **NOT** use `git clean`, `git reset`, or `git checkout .`, thereby preserving all pre-existing frontend and backend modifications.

---

## 8. Exact Files and Functions Requiring Modification

1. **`backend/src/services/printerAgentProtocol.service.js`:**
   - Function: `handlePrinterDeviceTelemetry()`
   - Changes: Add timestamp validation (missing/invalid/future/stale), atomic `updateMany` out-of-order protection, default device uniqueness query, UNKNOWN consumable preservation, and atomic `prisma.$transaction` for Machine/PrinterStatus bridge.
2. **`backend/src/socket.js`:**
   - Function: `socket.on('printer_status_update')`
   - Changes: Remove early return if bridged; broadcast updated machine availability to `machine_${machineId}` and `company_${companyId}` rooms when bridged.
3. **`backend/src/services/printerQr.service.js`:**
   - Function: `getPublicPrinterQrInfo()`
   - Changes: For machine-level QRs (`qr.printerDeviceId == null`), fall back to the machine's active default device for `printerDeviceId` and `deviceHealth` fields.
4. **`backend/tests/printer_agent_protocol.test.js`:**
   - Add unit tests covering the 13 scenarios in Section 6.

---

## 9. Conclusion & Recommendation

The Phase 9.1 design hardening review resolves all timestamp, concurrency, default device uniqueness, and consumable state preservation requirements. It establishes an atomic, fail-closed bridge that safely connects the running candidate agent's active Epson monitor to the public counter QR flyer without breaking multi-printer fleet isolation.

**Awaiting user authorization before executing implementation.**
