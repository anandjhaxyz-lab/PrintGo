const { isCurrentConnection, isCurrentRegistryResponse } = require('../src/connectionGuards');

describe('Printer Agent connection lifecycle guards', () => {
  const base = {
    connected: true,
    currentGeneration: 8,
    responseGeneration: 8,
    currentConnectionId: 'connection-new',
    responseConnectionId: 'connection-new'
  };

  test('accepts an acknowledgement from the active connection generation', () => {
    expect(isCurrentConnection(base)).toBe(true);
  });

  test('rejects acknowledgements after disconnect', () => {
    expect(isCurrentConnection({ ...base, connected: false })).toBe(false);
  });

  test('rejects an async response from a prior connection generation', () => {
    expect(isCurrentConnection({ ...base, responseGeneration: 7 })).toBe(false);
  });

  test('rejects a late acknowledgement from an older connection ID', () => {
    expect(isCurrentConnection({ ...base, responseConnectionId: 'connection-old' })).toBe(false);
  });

  test('accepts registry result only for current connection and response sequence', () => {
    expect(isCurrentRegistryResponse({
      ...base,
      currentSequence: 12,
      responseSequence: 12
    })).toBe(true);
  });

  test('rejects older registry refresh completion after a newer response arrives', () => {
    expect(isCurrentRegistryResponse({
      ...base,
      currentSequence: 13,
      responseSequence: 12
    })).toBe(false);
  });

  test('rejects registry completion from a disconnected/reconnected socket', () => {
    expect(isCurrentRegistryResponse({
      ...base,
      responseGeneration: 7,
      currentSequence: 12,
      responseSequence: 12
    })).toBe(false);
  });
});
