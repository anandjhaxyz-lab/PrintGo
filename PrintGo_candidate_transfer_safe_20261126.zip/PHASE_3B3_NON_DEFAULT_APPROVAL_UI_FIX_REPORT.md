# PRINTGO PHASE 3B.3 — SAFE NON-DEFAULT APPROVAL UI FIX REPORT

**Environment:** STAGING ONLY  
**Repository:** PrintGo  
**Baseline Commit:** `dfcbe42b5431cb3c0e932e178d02393beb221f08`  
**Scope:** Admin Frontend Only  
**Execution Timestamp:** 2026-11-24T02:11:00+05:30  
**Candidate Directory:** `D:\PrintGo-S3K-MULTIPRINTER-CANDIDATE`  

---

## 1. Executive Summary

In Phase 3B.2, approval of the secondary printers (**Target 1 — HP** and **Target 2 — Canon**) was halted because the Admin Frontend approval button in `PrinterFleetApprovalPanel.jsx` sent only `{ displayName: t.trim() }`, omitting `isDefault: false` and failing strict Safety Gate 5.

In Phase 3B.3, the Admin Frontend component has been updated and verified:
1. Located component: `frontend/src/components/admin/views/PrinterFleetApprovalPanel.jsx`.
2. Changed approval API POST payload from `{ displayName: displayName.trim() }` to `{ displayName: displayName.trim(), isDefault: false }`.
3. Created a dedicated Vitest test suite (`frontend/src/__tests__/printer_fleet_approval_panel.test.jsx`) verifying that approval calls explicitly submit `{ displayName, isDefault: false }` for both HP and Canon.
4. Executed all 6 frontend test suites (43/43 tests passing) and confirmed production build (`npm run build`) builds cleanly with `isDefault:!1` bundled.
5. Confirmed that **zero** printer approvals, QR code rotations, or database mutations occurred. The Epson legacy placeholder and active Front Desk Counter QR (`pq_YCuM5Lr2_...`) remain completely intact.

---

## 2. Changed File & Exact Diff

### File Changed:
`frontend/src/components/admin/views/PrinterFleetApprovalPanel.jsx`

### Exact Diff:
```diff
diff --git a/frontend/src/components/admin/views/PrinterFleetApprovalPanel.jsx b/frontend/src/components/admin/views/PrinterFleetApprovalPanel.jsx
index 37d3430..c7981ed 100644
--- a/frontend/src/components/admin/views/PrinterFleetApprovalPanel.jsx
+++ b/frontend/src/components/admin/views/PrinterFleetApprovalPanel.jsx
@@ -63,7 +63,7 @@ export const PrinterFleetApprovalPanel = ({ currentUser }) => {
     try {
       const response = await axios.post(
         `${API_URL}/api/admin/printer-discoveries/${discovery.id}/approve`,
-        { displayName: displayName.trim() }
+        { displayName: displayName.trim(), isDefault: false }
       );
       const registeredName = response.data?.data?.device?.displayName || displayName.trim();
       setSuccess(`${registeredName} approved and registered. You can now create its permanent customer QR.`);
```

*(Note: In `frontend/src/components/DocumentPreviewModal.jsx`, the existing fix from the main workspace was synchronized: `import pdfjsWorker from 'pdfjs-dist/build/pdf.worker.min.mjs?url'` to match `pdfjs-dist@6.5.438` on disk, allowing Vite production builds to compile cleanly).*

---

## 3. Test Suite & Verification Results

### Dedicated Test Suite:
`frontend/src/__tests__/printer_fleet_approval_panel.test.jsx`

```javascript
it('2. Submits approval request explicitly containing { displayName, isDefault: false } for Target 1 (HP)', async () => {
  vi.spyOn(window, 'prompt').mockReturnValue('HP LaserJet M1136');
  // ...
  fireEvent.click(approveButtons[0]);

  await waitFor(() => {
    expect(axios.post).toHaveBeenCalledTimes(1);
    const [url, payload] = axios.post.mock.calls[0];
    expect(url).toContain('/api/admin/printer-discoveries/disc_hp_001/approve');
    expect(payload).toEqual({
      displayName: 'HP LaserJet M1136',
      isDefault: false
    });
    expect(payload.isDefault).toBe(false);
  });
});

it('3. Submits approval request explicitly containing { displayName, isDefault: false } for Target 2 (Canon)', async () => {
  vi.spyOn(window, 'prompt').mockReturnValue('Canon imageRUNNER ADV');
  // ...
  fireEvent.click(approveButtons[1]);

  await waitFor(() => {
    expect(axios.post).toHaveBeenCalledTimes(1);
    const [url, payload] = axios.post.mock.calls[0];
    expect(url).toContain('/api/admin/printer-discoveries/disc_canon_002/approve');
    expect(payload).toEqual({
      displayName: 'Canon imageRUNNER ADV',
      isDefault: false
    });
    expect(payload.isDefault).toBe(false);
  });
});
```

### Test Execution Output:
```
 RUN  v5.1.0 D:/PrintGo-S3K-MULTIPRINTER-CANDIDATE/frontend

 ✓ src/__tests__/ad_suppression_views_integration.test.jsx (8 tests)
 ✓ src/__tests__/batch2_customer_checkout.test.jsx (10 tests)
 ✓ src/__tests__/ad_suppression_phase3.test.jsx (15 tests)
 ✓ src/__tests__/batch2_admin_invoices.test.jsx (2 tests)
 ✓ src/__tests__/printer_fleet_approval_panel.test.jsx (4 tests)
 ✓ src/__tests__/admin_overview_realtime_refresh.test.jsx (4 tests)

 Test Files  6 passed (6)
      Tests  43 passed (43)
   Duration  10.36s
```

---

## 4. Production Build Results

Executed `npm run build` (`vite build`) in `frontend/`:
```
vite v8.3.8 building client environment for production...
transforming...
✓ 2690 modules transformed.
rendering chunks...
computing gzip size...
dist/index.html                                   1.96 kB │ gzip:   0.79 kB
dist/assets/pdf.worker.min-CIqJB0yW.mjs       1,271.91 kB
dist/assets/index-D-KkQBos.css                   30.85 kB │ gzip:   7.13 kB
dist/assets/AdminDashboard-CVUFCoBE.js          623.89 kB │ gzip: 159.48 kB
dist/assets/MobileView-DCzugoe_.js            1,230.81 kB │ gzip: 406.53 kB
✓ built in 1.44s
```

### Inspection of Compiled Asset (`AdminDashboard-CVUFCoBE.js`):
Byte verification confirmed `isDefault:!1` (`false`) is explicitly present at offset `498348`:
```javascript
/printer-discoveries/${e.id}/approve`,{displayName:t.trim(),isDefault:!1})
```

---

## 5. Non-Demotion Invariant for Epson Primary Device

Verification against backend service logic (`printerDiscovery.service.js` lines 189–207):
1. When `isDefault: false` is submitted:
   - `data.isDefault !== undefined` evaluates to `true`.
   - `willBeDefault = Boolean(false) = false`.
   - `effectiveIsDefault` is set to `false`.
2. `existingDefault` (the Epson legacy placeholder where `isDefault: true`) is **not selected for demotion**:
   - `previousDefaultDeviceId` remains `null`.
   - `tx.printerDevice.update({ data: { isDefault: false } })` is **not executed**.
3. Therefore:
   - Epson placeholder maintains `isDefault = true`.
   - `isLegacyPlaceholderDevice()` in `printerQr.service.js` continues returning `true`.
   - Front Desk Counter QR (`pq_YCuM5Lr2_...`) remains completely unbroken and active.

---

## 6. Staging Deployment Assessment

Per deployment restrictions:
- The Render service `printgo-admin-staging` deploys from `origin/feature/printgo-production-readiness` with `autoDeploy=no`.
- Pushing to GitHub requires explicit operator approval because the remote repository branch is shared with backend code.
- Zero deployments were initiated during this task.
- Zero database migrations or backend modifications were run.

---

## 7. Confirmation of Zero Mutations

Direct probe to live Staging backend (`GET /api/auth/printer-qr/pq_YCuM5Lr2_nQMuxahsrBqjb9jWQSUhMDPd0Cbl_tpDB8`):
```json
{
  "status": "ACTIVE",
  "printer": {
    "name": "Main Shop Printer",
    "printerDeviceId": null
  }
}
```
- **Printer Approvals:** 0 approved. All 14 discovered queues remain in `DISCOVERED` review status.
- **PrinterDevice Rows:** 0 new devices created.
- **Customer QR Codes:** 0 created or modified.
- **Print Jobs:** 0 created.
- **Production PC (`D:\PrintGo-S3K`):** 100% untouched; all 51 uncommitted files remain intact.
