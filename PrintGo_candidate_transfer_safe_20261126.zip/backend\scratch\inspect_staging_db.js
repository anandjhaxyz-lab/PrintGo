const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient({
  datasources: { db: { url: 'postgresql://postgres@127.0.0.1:5433/printgo_staging_db?schema=public' } }
});

async function main() {
  const machines = await prisma.machine.findMany();
  console.log('MACHINES_COUNT:', machines.length);
  machines.forEach(m => console.log('Machine:', m.id, m.name, m.status));

  const devices = await prisma.printerDevice.findMany();
  console.log('DEVICES_COUNT:', devices.length);
  devices.forEach(d => console.log('Device:', d.id, d.displayName, d.windowsPrinterName, d.status, d.isDefault, d.machineId));

  const qrs = await prisma.printerQr.findMany();
  console.log('QRS_COUNT:', qrs.length);
  qrs.forEach(q => console.log('QR:', q.id, q.publicCode, q.label, q.status, q.machineId, q.printerDeviceId));
}

main()
  .catch(console.error)
  .finally(() => prisma.$disconnect());
