# PRINTGO PHASE 3B.2 — SECONDARY PRINTER APPROVAL REPORT

**Environment:** STAGING ONLY  
**Machine:** `Main Shop Printer`  
**Machine ID:** `d010496f-f176-41fe-9c98-efd2213a4a0e`  
**Candidate Directory:** `D:\PrintGo-S3K-MULTIPRINTER-CANDIDATE`  
**Backend URL:** `https://printgo-backend-staging.onrender.com`  
**Admin Dashboard:** `https://printgo-admin-staging.onrender.com`  
**Approved Baseline Commit:** `dfcbe42b5431cb3c0e932e178d02393beb221f08`  
**Execution Timestamp:** 2026-11-24T01:58:00+05:30  
**Audit Mode:** Strictly Read-Only / Safety-Gate Enforced  

---

## 1. Executive Summary & Verdict

### **VERDICT: STOP CONDITION TRIGGERED — MUTATIONS HALTED (SAFETY GATES 5 & 6)**

In strict adherence to the mandate:
> *"5. If the UI cannot guarantee non-default approval, STOP. Do not use the default approval button blindly."*  
> *"6. Use the authenticated Admin session only. Never bypass authentication or request/expose JWT credentials."*  
> *"If any safety condition fails, stop without mutation and report the blocker."*

The approval process was halted prior to mutating any database records because:
1. **Gate 5 Failure (UI Non-Default Guarantee):** Source inspection of the live deployed Admin Frontend React bundle (`AdminDashboard-ZlgLEZBc.js` line 498300) confirms that the Web Dashboard's approval button **omits `isDefault` from its POST payload** (sending `{ displayName }` only). The UI provides no mechanism, checkbox, or parameter to guarantee `isDefault: false`. Calling the UI approval button blindly risks implicit default inheritance.
2. **Gate 6 Failure (Admin Authentication Session):** The Admin REST API endpoints (`/api/admin/printer-discoveries` and `/approve`) strictly enforce `protect` middleware (`401 Unauthorized` without an authorized `SUPERADMIN` or `FRANCHISEE` JWT session). In compliance with the zero-bypass policy (*"Never bypass authentication or request/expose JWT credentials"*), no unverified session was spoofed or intercepted.

**Critical Epson Protection Maintained:**
- Zero modifications were made to the database.
- The Epson placeholder device and the active Front Desk Counter QR (`pq_YCuM5Lr2_...`) remain 100% untouched, functional, and in legacy single-printer dispatch mode.
- Zero customer QR codes and zero print jobs were generated.

---

## 2. Pre-Approval Checklist & Safety Verifications

| Check # | Requirement | Live Inspection Result | Status |
| :-: | :--- | :--- | :---: |
| **1** | **Target Discovery & Machine ID** | Machine `d010496f-f176-41fe-9c98-efd2213a4a0e` confirmed. Target 1 (HP, `USB011`) and Target 2 (Canon, `USB001`) present in discovery inventory. | **PASS** |
| **2** | **No Target Queues Already Mapped** | Candidate Agent registry request (`printer_device_registry_request`) confirmed `devices: []` (0 mapped devices). Neither queue is bound. | **PASS** |
| **3** | **No QR / Session / Job Dependency** | Neither HP nor Canon device exists in `PrinterDevice`. Zero historical QR codes, customer sessions, or print jobs reference them. | **PASS** |
| **4** | **API Supports Explicit `isDefault: false`** | `printerDiscovery.service.js` lines 189–207 explicitly accept and enforce `isDefault: false` in request body. | **PASS** |
| **5** | **UI Guarantees `isDefault: false`** | **FAILED:** Live frontend bundle sends only `{ displayName: t.trim() }`. UI has no `isDefault` toggle or payload guarantee. | **BLOCKED (STOP)** |
| **6** | **Authenticated Admin Session Available** | **FAILED:** Admin endpoints return `401 Unauthorized` without Admin JWT session. Chrome lacks remote debugging port. | **BLOCKED (STOP)** |

---

## 3. Deep-Dive Code Audit: Safety Gates 4 & 5

### 1. Backend API Capability (Safety Check 4 — PASS)
Inspection of `approvePrinterDiscovery` in `backend/src/services/printerDiscovery.service.js` (lines 189–208):
```javascript
const willBeDefault = Boolean(data.isDefault !== undefined ? data.isDefault : discovery.isDefault);
const existingDefault = await tx.printerDevice.findFirst({
  where: { machineId: discovery.machineId, isDefault: true }
});

let effectiveIsDefault = willBeDefault;
let previousDefaultDeviceId = null;

if (effectiveIsDefault) {
  if (existingDefault) {
    previousDefaultDeviceId = existingDefault.id;
    await tx.printerDevice.update({
      where: { id: existingDefault.id },
      data: { isDefault: false }
    });
  }
} else if (!existingDefault && deviceCount === 0) {
  effectiveIsDefault = true;
}

const device = await tx.printerDevice.create({
  data: {
    machineId: discovery.machineId,
    displayName,
    windowsPrinterName: discovery.windowsPrinterName,
    driverName: discovery.driverName,
    portName: discovery.portName,
    connectionType: discovery.connectionType,
    isDefault: effectiveIsDefault, // <--- Correctly sets false if passed in data
    status: 'ACTIVE',
    ...
  }
});
```
- When `POST /api/admin/printer-discoveries/:id/approve` is called with `{ "displayName": "...", "isDefault": false }`, `effectiveIsDefault` is explicitly `false`.
- The existing default device (Epson placeholder) is **not touched**, and `previousDefaultDeviceId` remains `null`.

### 2. Frontend UI Flaw (Safety Check 5 — FAILED & BLOCKED)
Inspection of the compiled production React bundle on `https://printgo-admin-staging.onrender.com/assets/AdminDashboard-ZlgLEZBc.js` (line 498300):
```javascript
let w = async (e) => {
  if (!x || d) return;
  let t = window.prompt(
    "Choose a customer-facing printer name. The exact Windows queue remains unchanged.",
    e.windowsPrinterName
  );
  if (t === null) return;
  if (!t.trim()) {
    h("Printer display name cannot be empty.");
    return;
  }
  let n = e.machine?.name || "this Machine";
  if (window.confirm(`Approve the exact Windows queue "${e.windowsPrinterName}" on "${n}"?`)) {
    f(e.id), h(""), v("");
    try {
      let n = (await _.post(
        `${lV}/api/admin/printer-discoveries/${e.id}/approve`,
        { displayName: t.trim() } // <--- FLAW: isDefault is omitted completely!
      )).data?.data?.device?.displayName || t.trim();
      v(`${n} approved and registered. You can now create its permanent customer QR.`);
      await C();
    } catch (e) {
      h(e.response?.data?.error || e.message || "Printer approval failed.");
    } finally {
      f(null);
    }
  }
};
```
- The Admin UI **only** sends `{ displayName: t.trim() }`.
- Because `data.isDefault` is `undefined`, the backend falls back to `discovery.isDefault`.
- While the Windows dry run reported `Default: false` for HP and Canon, clicking the UI approval button blindly **cannot guarantee non-default approval** under the strict safety requirement.

---

## 4. Current State of Physical Printers & QR flyer

### Target Physical Queues (Pending Approval):
1. **Target 1 — HP:**
   - Queue: `HP LaserJet Professional M1136 MFP (Copy 1)`
   - Port: `USB011`
   - Requested Display Name: `HP LaserJet M1136`
   - Status: `DISCOVERED` in `PrinterDiscovery`
2. **Target 2 — Canon:**
   - Queue: `Canon Generic Plus UFR II (Copy 2)`
   - Port: `USB001`
   - Requested Display Name: `Canon imageRUNNER ADV`
   - Status: `DISCOVERED` in `PrinterDiscovery`

### Epson & Counter QR Invariants (100% Protected):
- **Epson Windows Queue:** `EPSON L6460 Series` (Port `USB019`) remains unapproved (`reviewStatus: DISCOVERED`).
- **Epson Placeholder Device:** `isDefault = true`, `windowsPrinterName = null`, `status = DISCOVERY_REQUIRED`.
- **Permanent Front Desk Counter QR:**
  - Public Code: `pq_YCuM5Lr2_nQMuxahsrBqjb9jWQSUhMDPd0Cbl_tpDB8`
  - HTTP Status: `200 OK`
  - State: `status: ACTIVE`, bound to legacy primary dispatch.
  - Test Scan Outcome: 100% operational; zero downtime or disruption.

---

## 5. Authorized Execution Workflow

To approve both secondary printers safely with `isDefault: false` guaranteed, use either of the following authorized paths:

### Option A: Authorized API Mutation (Recommended)
From an authorized Admin shell with a valid Admin session token (`ADMIN_JWT`):

#### 1. Retrieve Discovery IDs:
```bash
curl -s -X GET "https://printgo-backend-staging.onrender.com/api/admin/printer-discoveries?limit=100&machineId=d010496f-f176-41fe-9c98-efd2213a4a0e" \
  -H "Authorization: Bearer <ADMIN_JWT>"
```
Locate the `id` for `HP LaserJet Professional M1136 MFP (Copy 1)` (`HP_DISCOVERY_ID`) and `Canon Generic Plus UFR II (Copy 2)` (`CANON_DISCOVERY_ID`).

#### 2. Approve Target 1 (HP) with Explicit `isDefault: false`:
```bash
curl -s -X POST "https://printgo-backend-staging.onrender.com/api/admin/printer-discoveries/<HP_DISCOVERY_ID>/approve" \
  -H "Authorization: Bearer <ADMIN_JWT>" \
  -H "Content-Type: application/json" \
  -d '{"displayName": "HP LaserJet M1136", "isDefault": false}'
```

#### 3. Approve Target 2 (Canon) with Explicit `isDefault: false`:
```bash
curl -s -X POST "https://printgo-backend-staging.onrender.com/api/admin/printer-discoveries/<CANON_DISCOVERY_ID>/approve" \
  -H "Authorization: Bearer <ADMIN_JWT>" \
  -H "Content-Type: application/json" \
  -d '{"displayName": "Canon imageRUNNER ADV", "isDefault": false}'
```

### Option B: UI Patch & Authorized Browser Approval
If approving via the Web Dashboard is preferred:
1. Update `AdminDashboard.jsx` in the frontend source so the approval prompt asks or hardcodes `{ displayName: t.trim(), isDefault: false }`.
2. Redeploy the Admin frontend to Staging.
3. Approve both queues via the Web Dashboard.
