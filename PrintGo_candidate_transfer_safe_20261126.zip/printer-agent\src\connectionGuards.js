function isCurrentConnection({
  connected,
  currentGeneration,
  responseGeneration,
  currentConnectionId,
  responseConnectionId
}) {
  return connected === true &&
    Number.isInteger(currentGeneration) &&
    Number.isInteger(responseGeneration) &&
    currentGeneration === responseGeneration &&
    typeof currentConnectionId === 'string' &&
    currentConnectionId.length > 0 &&
    currentConnectionId === responseConnectionId;
}

function isCurrentRegistryResponse({
  connected,
  currentGeneration,
  responseGeneration,
  currentConnectionId,
  responseConnectionId,
  currentSequence,
  responseSequence
}) {
  return isCurrentConnection({
    connected,
    currentGeneration,
    responseGeneration,
    currentConnectionId,
    responseConnectionId
  }) && Number.isInteger(currentSequence) &&
    Number.isInteger(responseSequence) &&
    currentSequence === responseSequence;
}

module.exports = { isCurrentConnection, isCurrentRegistryResponse };
