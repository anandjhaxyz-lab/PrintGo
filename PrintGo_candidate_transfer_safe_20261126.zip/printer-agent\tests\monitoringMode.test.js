const { runPrinterStatusMonitoring } = require('../src/monitoringMode');

describe('Printer Agent monitoring mode isolation', () => {
  let fleetManager;
  let spoolerMonitor;
  let socket;

  beforeEach(() => {
    fleetManager = { monitors: new Map([['device-a', {}]]), checkPrinterStatuses: jest.fn() };
    spoolerMonitor = { checkPrinterStatus: jest.fn() };
    socket = {};
  });

  test('PENDING handshake never invokes either monitor', () => {
    const result = runPrinterStatusMonitoring({ mode: 'PENDING', fleetManager, spoolerMonitor, socket });
    expect(result).toEqual({ mode: 'PENDING', monitored: false, monitorCount: 0 });
    expect(fleetManager.checkPrinterStatuses).not.toHaveBeenCalled();
    expect(spoolerMonitor.checkPrinterStatus).not.toHaveBeenCalled();
  });

  test('REJECTED handshake fails closed and never falls back to legacy', () => {
    const result = runPrinterStatusMonitoring({ mode: 'REJECTED', fleetManager, spoolerMonitor, socket });
    expect(result).toEqual({ mode: 'REJECTED', monitored: false, monitorCount: 0 });
    expect(spoolerMonitor.checkPrinterStatus).not.toHaveBeenCalled();
  });

  test('disconnected socket never invokes either monitor', () => {
    const result = runPrinterStatusMonitoring({ mode: 'LEGACY', fleetManager, spoolerMonitor, socket, connected: false });
    expect(result).toEqual({ mode: 'LEGACY', monitored: false, monitorCount: 0 });
    expect(spoolerMonitor.checkPrinterStatus).not.toHaveBeenCalled();
    expect(fleetManager.checkPrinterStatuses).not.toHaveBeenCalled();
  });

  test('negotiated multi-printer mode monitors fleet devices when monitors exist', () => {
    const result = runPrinterStatusMonitoring({ mode: 'MULTI_PRINTER', fleetManager, spoolerMonitor, socket });
    expect(result).toEqual({ mode: 'multi-printer', monitored: true, monitorCount: 1 });
    expect(fleetManager.checkPrinterStatuses).toHaveBeenCalledWith(socket);
    expect(spoolerMonitor.checkPrinterStatus).not.toHaveBeenCalled();
  });

  test('multi-printer mode with zero monitors fails closed without legacy fallback', () => {
    fleetManager.monitors.clear();
    const result = runPrinterStatusMonitoring({ mode: 'MULTI_PRINTER', fleetManager, spoolerMonitor, socket });
    expect(result).toEqual({ mode: 'multi-printer', monitored: false, monitorCount: 0 });
    expect(spoolerMonitor.checkPrinterStatus).not.toHaveBeenCalled();
  });

  test('multi-printer mode with missing fleet manager fails closed', () => {
    const result = runPrinterStatusMonitoring({ mode: 'MULTI_PRINTER', fleetManager: null, spoolerMonitor, socket });
    expect(result).toEqual({ mode: 'multi-printer', monitored: false, monitorCount: 0 });
    expect(spoolerMonitor.checkPrinterStatus).not.toHaveBeenCalled();
  });

  test('explicitly accepted legacy mode uses only the configured single-printer monitor', () => {
    const result = runPrinterStatusMonitoring({ mode: 'LEGACY', fleetManager, spoolerMonitor, socket });
    expect(result).toEqual({ mode: 'legacy', monitored: true, monitorCount: 1 });
    expect(spoolerMonitor.checkPrinterStatus).toHaveBeenCalledWith(socket);
    expect(fleetManager.checkPrinterStatuses).not.toHaveBeenCalled();
  });

  test('unknown mode fails closed', () => {
    const result = runPrinterStatusMonitoring({ mode: 'UNKNOWN', fleetManager, spoolerMonitor, socket });
    expect(result).toEqual({ mode: 'PENDING', monitored: false, monitorCount: 0 });
    expect(spoolerMonitor.checkPrinterStatus).not.toHaveBeenCalled();
  });
});
