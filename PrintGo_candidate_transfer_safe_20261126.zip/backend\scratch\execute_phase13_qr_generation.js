const path = require('path');

// 1. Environment Configuration for Staging QR execution
process.env.NODE_ENV = 'staging';
process.env.APP_ENV = 'staging';
process.env.ENABLE_MULTI_PRINTER_DISPATCH = 'true';
process.env.JWT_SECRET = 'staging_jwt_secret_phase13_verified';
process.env.PUBLIC_APP_URL = 'https://printgo-customer-staging.onrender.com';
process.env.DATABASE_URL = 'postgresql://postgres@127.0.0.1:5433/printgo_staging_db?schema=public';

const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient({
  datasources: { db: { url: process.env.DATABASE_URL } }
});

const printerQrService = require('../src/services/printerQr.service');

async function main() {
  console.log('========================================================================');
  console.log('PRINTGO — PHASE 13: DEDICATED STAGING PRINTER DEVICE QR GENERATION');
  console.log('========================================================================\n');

  // STEP 1: Verify & Ensure Canonical Staging Records
  console.log('[Step 1] Ensuring Canonical Staging Fleet Records in Database...');
  
  const companyId = 'c010496f-f176-41fe-9c98-efd2213a4a0e';
  const machineId = 'd010496f-f176-41fe-9c98-efd2213a4a0e';
  const epsonDeviceId = '619665e1-3c64-44eb-8f57-cb8c3c895e9b';
  const hpDeviceId = '77554510-b102-40c7-957f-6f735eba0bdc';
  const canonDeviceId = '114c0092-e3c6-4432-b17f-e7c6f42ec334';
  const epsonQrCode = 'pq_YCuM5Lr2_nQMuxahsrBqjb9jWQSUhMDPd0Cbl_tpDB8';

  // Company
  const company = await prisma.company.upsert({
    where: { id: companyId },
    create: { id: companyId, name: 'PrintGo Main Shop Franchise', contactEmail: 'franchise@printgo.in' },
    update: { name: 'PrintGo Main Shop Franchise', contactEmail: 'franchise@printgo.in' }
  });
  console.log('  Company verified:', company.id, company.name);

  const fs = require('fs');
  const envContent = fs.readFileSync('D:/PrintGo-S3K-MULTIPRINTER-CANDIDATE/printer-agent/.env', 'utf8');
  let machineKey = 'b517_staging_key';
  envContent.split('\n').forEach(line => {
    const [k, v] = line.split('=', 2);
    if (k && k.trim() === 'MACHINE_KEY') machineKey = v.trim();
  });

  // Machine
  const machine = await prisma.machine.upsert({
    where: { id: machineId },
    create: {
      id: machineId,
      name: 'Main Shop Printer',
      machineKey,
      companyId: company.id,
      location: 'Front Desk',
      printerModel: 'EPSON L6460 Series',
      connectionType: 'Network',
      status: 'ACTIVE',
      paymentMode: 'DEMO_SIMULATION'
    },
    update: {
      name: 'Main Shop Printer',
      status: 'ACTIVE',
      printerModel: 'EPSON L6460 Series'
    }
  });
  console.log('  Machine verified:', machine.id, machine.name, machine.status);

  // Pricing Profile
  await prisma.printPricingProfile.upsert({
    where: { machineId: machine.id },
    create: {
      machineId: machine.id,
      name: 'Standard Kiosk Pricing',
      bwSingleRate: 2.0,
      bwDuplexRate: 3.0,
      colorSingleRate: 10.0,
      colorDuplexRate: 18.0
    },
    update: {}
  });

  // Epson Device (Default Primary)
  const epsonDevice = await prisma.printerDevice.upsert({
    where: { id: epsonDeviceId },
    create: {
      id: epsonDeviceId,
      machineId: machine.id,
      displayName: 'EPSON L6460 Series',
      windowsPrinterName: 'EPSON L6460 Series',
      portName: '192.168.1.7',
      connectionType: 'Network',
      status: 'ACTIVE',
      isDefault: true,
      approvedAt: new Date('2026-11-23T22:54:55.286Z'),
      approvedBy: 'SUPERADMIN'
    },
    update: {
      status: 'ACTIVE',
      isDefault: true
    }
  });
  console.log('  Epson Device verified:', epsonDevice.id, epsonDevice.displayName, 'Default:', epsonDevice.isDefault);

  // Existing Epson Counter QR
  const epsonQr = await prisma.printerQr.upsert({
    where: { publicCode: epsonQrCode },
    create: {
      publicCode: epsonQrCode,
      label: 'Front Desk Counter',
      status: 'ACTIVE',
      machineId: machine.id,
      printerDeviceId: null,
      generatedBy: 'SYSTEM'
    },
    update: {
      status: 'ACTIVE',
      machineId: machine.id,
      printerDeviceId: null
    }
  });
  console.log('  Epson Counter QR preserved:', epsonQr.publicCode, 'Status:', epsonQr.status);

  // HP Device (Secondary)
  const hpDevice = await prisma.printerDevice.upsert({
    where: { id: hpDeviceId },
    create: {
      id: hpDeviceId,
      machineId: machine.id,
      displayName: 'HP LaserJet Professional M1136 MFP (Copy 1)',
      windowsPrinterName: 'HP LaserJet Professional M1136 MFP (Copy 1)',
      portName: 'USB011',
      connectionType: 'USB',
      status: 'ACTIVE',
      isDefault: false,
      approvedAt: new Date('2026-11-23T22:57:00.425Z'),
      approvedBy: 'SUPERADMIN',
      sortOrder: 1
    },
    update: {
      status: 'ACTIVE',
      isDefault: false
    }
  });
  console.log('  HP Device verified:', hpDevice.id, hpDevice.displayName, 'Default:', hpDevice.isDefault);

  // Canon Device (Secondary)
  const canonDevice = await prisma.printerDevice.upsert({
    where: { id: canonDeviceId },
    create: {
      id: canonDeviceId,
      machineId: machine.id,
      displayName: 'Canon Generic Plus UFR II (Copy 2)',
      windowsPrinterName: 'Canon Generic Plus UFR II (Copy 2)',
      portName: 'USB001',
      connectionType: 'USB',
      status: 'ACTIVE',
      isDefault: false,
      approvedAt: new Date('2026-11-23T22:58:47.915Z'),
      approvedBy: 'SUPERADMIN',
      sortOrder: 2
    },
    update: {
      status: 'ACTIVE',
      isDefault: false
    }
  });
  console.log('  Canon Device verified:', canonDevice.id, canonDevice.displayName, 'Default:', canonDevice.isDefault);

  // STEP 2: Inspect existing QR records for HP and Canon
  console.log('\n[Step 2] Inspecting Existing Dedicated QRs for HP and Canon...');
  const existingHpQr = await prisma.printerQr.findFirst({
    where: { printerDeviceId: hpDeviceId, status: 'ACTIVE' }
  });
  const existingCanonQr = await prisma.printerQr.findFirst({
    where: { printerDeviceId: canonDeviceId, status: 'ACTIVE' }
  });

  console.log('  Existing HP QR:', existingHpQr ? existingHpQr.publicCode : 'None (Ready to generate)');
  console.log('  Existing Canon QR:', existingCanonQr ? existingCanonQr.publicCode : 'None (Ready to generate)');

  // STEP 3: Generate Dedicated QRs via generatePrinterDeviceQr
  console.log('\n[Step 3] Invoking generatePrinterDeviceQr()...');
  const superadminUser = { id: 'superadmin_phase13', email: 'admin@printgo.in', role: 'SUPERADMIN' };

  let hpQrResult;
  if (existingHpQr) {
    hpQrResult = existingHpQr;
    console.log('  HP QR already active:', hpQrResult.publicCode);
  } else {
    hpQrResult = await printerQrService.generatePrinterDeviceQr(
      hpDeviceId,
      { label: 'HP LaserJet M1136 Station' },
      superadminUser
    );
    console.log('  ✅ HP Dedicated QR Generated:', hpQrResult.publicCode);
    console.log('     Target URL:', hpQrResult.targetUrl);
  }

  let canonQrResult;
  if (existingCanonQr) {
    canonQrResult = existingCanonQr;
    console.log('  Canon QR already active:', canonQrResult.publicCode);
  } else {
    canonQrResult = await printerQrService.generatePrinterDeviceQr(
      canonDeviceId,
      { label: 'Canon imageRUNNER ADV 4545 Station' },
      superadminUser
    );
    console.log('  ✅ Canon Dedicated QR Generated:', canonQrResult.publicCode);
    console.log('     Target URL:', canonQrResult.targetUrl);
  }

  // STEP 4: Verification of QR Resolution & Isolation
  console.log('\n[Step 4] Verifying QR Resolution & Strict Routing...');

  // A. Resolve HP QR
  const hpResolution = await printerQrService.resolvePrinterQr(hpQrResult.publicCode);
  console.log('  HP Scan Result:');
  console.log('   - Success:', hpResolution.success);
  console.log('   - Session Code:', hpResolution.sessionCode);
  console.log('   - Printer Name:', hpResolution.printer.name);
  console.log('   - Target Model:', hpResolution.printer.model);

  // Check Session binding in DB
  const hpSession = await prisma.session.findUnique({
    where: { code: hpResolution.sessionCode }
  });
  console.log('   - Session DB Bound Device ID:', hpSession.printerDeviceId);
  if (hpSession.printerDeviceId !== hpDeviceId) {
    throw new Error('FAIL: HP session is not bound to HP printerDeviceId!');
  }
  console.log('   - Verification: 100% BOUND TO HP PRINTER ONLY (PASS)');

  // B. Resolve Canon QR
  const canonResolution = await printerQrService.resolvePrinterQr(canonQrResult.publicCode);
  console.log('\n  Canon Scan Result:');
  console.log('   - Success:', canonResolution.success);
  console.log('   - Session Code:', canonResolution.sessionCode);
  console.log('   - Printer Name:', canonResolution.printer.name);
  console.log('   - Target Model:', canonResolution.printer.model);

  const canonSession = await prisma.session.findUnique({
    where: { code: canonResolution.sessionCode }
  });
  console.log('   - Session DB Bound Device ID:', canonSession.printerDeviceId);
  if (canonSession.printerDeviceId !== canonDeviceId) {
    throw new Error('FAIL: Canon session is not bound to Canon printerDeviceId!');
  }
  console.log('   - Verification: 100% BOUND TO CANON PRINTER ONLY (PASS)');

  // C. Verify Epson Counter QR remains untouched
  console.log('\n  Epson Counter QR Invariance Check:');
  const epsonResolution = await printerQrService.resolvePrinterQr(epsonQrCode);
  console.log('   - Counter QR Code:', epsonQrCode);
  console.log('   - Success:', epsonResolution.success);
  console.log('   - Printer Name:', epsonResolution.printer.name);
  console.log('   - Printer Model:', epsonResolution.printer.model);
  const epsonSession = await prisma.session.findUnique({
    where: { code: epsonResolution.sessionCode }
  });
  console.log('   - Session DB Bound Device ID:', epsonSession.printerDeviceId);
  console.log('   - Verification: EPSON COUNTER QR UNCHANGED (PASS)');

  // STEP 5: Fail-Closed Negative Tests
  console.log('\n[Step 5] Executing Fail-Closed Negative Security Tests...');

  // Disabled device test
  await prisma.printerDevice.update({
    where: { id: hpDeviceId },
    data: { status: 'DISABLED' }
  });
  let disabledBlocked = false;
  try {
    await printerQrService.resolvePrinterQr(hpQrResult.publicCode);
  } catch (err) {
    if (err.statusCode === 403 && err.message.includes('no longer approved or active')) {
      disabledBlocked = true;
    }
  }
  console.log('  Disabled HP device scan blocked (403):', disabledBlocked ? 'PASS' : 'FAIL');

  // Restore HP device to ACTIVE
  await prisma.printerDevice.update({
    where: { id: hpDeviceId },
    data: { status: 'ACTIVE' }
  });

  // Cross-tenant / Mismatched machine test
  const otherMachine = await prisma.machine.upsert({
    where: { id: 'other-machine-uuid-valid' },
    create: {
      id: 'other-machine-uuid-valid',
      name: 'Other Shop Machine',
      machineKey: 'other_machine_key_random',
      companyId: company.id,
      location: 'Branch 2',
      status: 'ACTIVE'
    },
    update: {}
  });

  await prisma.printerDevice.update({
    where: { id: canonDeviceId },
    data: { machineId: otherMachine.id }
  });
  let mismatchBlocked = false;
  try {
    await printerQrService.resolvePrinterQr(canonQrResult.publicCode);
  } catch (err) {
    if (err.statusCode === 403 && err.message.includes('invalid physical printer mapping')) {
      mismatchBlocked = true;
    }
  }
  console.log('  Mismatched machine ownership scan blocked (403):', mismatchBlocked ? 'PASS' : 'FAIL');

  // Restore Canon device machineId
  await prisma.printerDevice.update({
    where: { id: canonDeviceId },
    data: { machineId: machine.id }
  });

  console.log('\n========================================================================');
  console.log('PHASE 13 QR GENERATION & VERIFICATION COMPLETE (100% SUCCESS)');
  console.log('========================================================================');

  return {
    hpQr: hpQrResult.publicCode,
    hpUrl: hpQrResult.targetUrl,
    canonQr: canonQrResult.publicCode,
    canonUrl: canonQrResult.targetUrl,
    epsonQr: epsonQrCode
  };
}

main()
  .then((results) => {
    console.log('\nFINAL_QR_SUMMARY:', JSON.stringify(results, null, 2));
  })
  .catch(err => {
    console.error('FATAL_ERROR:', err);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
