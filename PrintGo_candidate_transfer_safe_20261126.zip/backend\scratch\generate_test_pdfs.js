const { PDFDocument, rgb, StandardFonts } = require('D:/PrintGo-S3K-MULTIPRINTER-CANDIDATE/backend/node_modules/pdf-lib');
const fs = require('fs');
const path = require('path');

async function createTestPdf(outputPath, title, queueName, deviceId) {
  const pdfDoc = await PDFDocument.create();
  const page = pdfDoc.addPage([595.28, 841.89]); // A4 in points (72 dpi)
  const font = await pdfDoc.embedFont(StandardFonts.Helvetica);
  const fontBold = await pdfDoc.embedFont(StandardFonts.HelveticaBold);

  // Draw Header Border
  page.drawRectangle({
    x: 40,
    y: 720,
    width: 515.28,
    height: 80,
    borderColor: rgb(0, 0, 0),
    borderWidth: 2,
    color: rgb(0.95, 0.95, 0.95)
  });

  page.drawText('PRINTGO — HARDWARE TEST PAGE', {
    x: 60,
    y: 765,
    size: 20,
    font: fontBold,
    color: rgb(0, 0, 0)
  });

  page.drawText('PHASE 13: CONTROLLED MULTI-PRINTER PHYSICAL VERIFICATION', {
    x: 60,
    y: 740,
    size: 11,
    font: font,
    color: rgb(0.2, 0.2, 0.2)
  });

  // Body content
  let y = 670;
  const drawRow = (label, value) => {
    page.drawText(label, { x: 50, y, size: 12, font: fontBold, color: rgb(0, 0, 0) });
    page.drawText(value, { x: 190, y, size: 11, font, color: rgb(0.1, 0.1, 0.1) });
    y -= 30;
  };

  drawRow('Target Printer:', title);
  drawRow('Windows Queue:', queueName);
  drawRow('Device UUID:', deviceId);
  drawRow('Machine ID:', 'd010496f-f176-41fe-9c98-efd2213a4a0e (Main Shop Printer)');
  drawRow('Host Machine:', 'DESKTOP-QB6Q3BC');
  drawRow('Execution Timestamp:', new Date().toISOString());
  drawRow('Page Specification:', 'Exactly 1 Page (Simplex A4 Black & White)');

  // Instructions Box
  y -= 20;
  page.drawRectangle({
    x: 40,
    y: y - 70,
    width: 515.28,
    height: 90,
    borderColor: rgb(0, 0, 0),
    borderWidth: 1.5,
    color: rgb(0.98, 0.98, 0.98)
  });

  page.drawText('OPERATOR PHYSICAL VERIFICATION INSTRUCTION:', {
    x: 55,
    y: y,
    size: 12,
    font: fontBold,
    color: rgb(0, 0, 0)
  });

  page.drawText('1. Verify that this single printed page exited from the designated printer tray.', {
    x: 55,
    y: y - 25,
    size: 10,
    font,
    color: rgb(0, 0, 0)
  });

  page.drawText('2. Check print quality: text alignment, contrast, zero clipping, and smooth sheet feed.', {
    x: 55,
    y: y - 45,
    size: 10,
    font,
    color: rgb(0, 0, 0)
  });

  page.drawText('3. Confirm no remaining sheets or paper jams are present in the printer mechanism.', {
    x: 55,
    y: y - 65,
    size: 10,
    font,
    color: rgb(0, 0, 0)
  });

  const pdfBytes = await pdfDoc.save();
  fs.writeFileSync(outputPath, pdfBytes);
  console.log(`Generated: ${outputPath} (${pdfBytes.length} bytes, 1 page)`);
}

async function main() {
  const scratchDir = 'D:/PrintGo-S3K-MULTIPRINTER-CANDIDATE/backend/scratch';
  const hpPdf = path.join(scratchDir, 'hp_m1136_test_page.pdf');
  const canonPdf = path.join(scratchDir, 'canon_4545_test_page.pdf');

  await createTestPdf(
    hpPdf,
    'HP LaserJet Professional M1136 MFP',
    'HP LaserJet Professional M1136 MFP (Copy 1)',
    '77554510-b102-40c7-957f-6f735eba0bdc'
  );

  await createTestPdf(
    canonPdf,
    'Canon imageRUNNER ADV 4545',
    'Canon Generic Plus UFR II (Copy 2)',
    '114c0092-e3c6-4432-b17f-e7c6f42ec334'
  );
}

main().catch(err => {
  console.error('Fatal error:', err);
  process.exit(1);
});
