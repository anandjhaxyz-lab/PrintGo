SELECT rolname, rolcanlogin, rolsuper, rolcreatedb FROM pg_roles WHERE rolname = 'printgo_app';
