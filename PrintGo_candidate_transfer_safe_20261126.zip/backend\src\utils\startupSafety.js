'use strict';

const LOOPBACK_HOSTS = new Set(['127.0.0.1', 'localhost', '::1']);
const POSTGRES_PROTOCOLS = new Set(['postgres:', 'postgresql:']);

const getDatabaseGuardPolicy = (env = process.env) => {
  const nodeEnv = String(env.NODE_ENV || 'development').trim().toLowerCase();

  if (nodeEnv === 'staging') {
    return {
      enforced: true,
      environment: 'staging',
      database: 'printgo_staging',
      port: 5432,
      hosts: LOOPBACK_HOSTS,
      username: 'printgo_app'
    };
  }

  if (nodeEnv === 'production') {
    return { enforced: false, environment: 'production' };
  }

  return {
    enforced: true,
    environment: nodeEnv,
    database: 'printgo_disposable_target',
    port: 5433,
    hosts: LOOPBACK_HOSTS
  };
};

const assertDatabaseIdentity = ({
  env = process.env,
  databaseName,
  serverPort,
  databaseUrl = env.DATABASE_URL
}) => {
  const policy = getDatabaseGuardPolicy(env);
  if (!policy.enforced) return { enforced: false, environment: policy.environment };

  if (!databaseUrl) {
    throw new Error('[DATABASE SAFETY GUARD] FATAL: DATABASE_URL is required for ' + policy.environment + '.');
  }

  let parsed;
  try {
    parsed = new URL(databaseUrl);
  } catch {
    throw new Error('[DATABASE SAFETY GUARD] FATAL: DATABASE_URL is malformed.');
  }

  const urlDatabase = decodeURIComponent(parsed.pathname.startsWith('/') ? parsed.pathname.slice(1) : parsed.pathname);
  const hostAllowed = policy.hosts.has(parsed.hostname.toLowerCase());
  const protocolAllowed = POSTGRES_PROTOCOLS.has(parsed.protocol);
  const port = Number(parsed.port || (protocolAllowed ? 5432 : 0));
  const username = decodeURIComponent(parsed.username || '');

  const mismatches = [];
  if (!protocolAllowed) mismatches.push('URL protocol must be PostgreSQL');
  if (!hostAllowed) mismatches.push('URL host is not loopback');
  if (port !== policy.port) mismatches.push('URL port must be ' + policy.port);
  if (parsed.pathname !== '/' + policy.database) mismatches.push('URL path must be /' + policy.database);
  if (urlDatabase !== policy.database) mismatches.push('URL database must be ' + policy.database);
  if (databaseName !== policy.database) mismatches.push('connected database must be ' + policy.database);
  if (Number(serverPort) !== policy.port) mismatches.push('connected port must be ' + policy.port);
  if (policy.username && username !== policy.username) mismatches.push('URL username must be ' + policy.username);

  if (mismatches.length) {
    throw new Error('[DATABASE SAFETY GUARD] FATAL: Refusing ' + policy.environment + ' startup: ' + mismatches.join('; ') + '.');
  }

  return {
    enforced: true,
    environment: policy.environment,
    database: policy.database,
    port: policy.port,
    host: parsed.hostname,
    username
  };
};

const shouldAutoSeed = (env = process.env) =>
  String(env.NODE_ENV || 'development').trim().toLowerCase() !== 'staging';

module.exports = {
  getDatabaseGuardPolicy,
  assertDatabaseIdentity,
  shouldAutoSeed
};
