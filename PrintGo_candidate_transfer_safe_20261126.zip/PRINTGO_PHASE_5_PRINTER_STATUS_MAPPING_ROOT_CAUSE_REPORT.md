# PRINTGO — PHASE 5: PRINTER STATUS MAPPING ROOT-CAUSE AUDIT REPORT

**Workspace:** `D:\PrintGo-S3K-MULTIPRINTER-CANDIDATE`  
**Target:** Staging Backend (`https://printgo-backend-staging.onrender.com`)  
**Host PC:** `DESKTOP-QB6Q3BC` (`192.168.1.10`)  
**Machine Display Name:** `Main Shop Printer`  
**Machine ID:** `d010496f-f176-41fe-9c98-efd2213a4a0e`  
**Audit Mode:** STRICTLY READ-ONLY (Zero modifications, zero deployments, zero job submissions)  
**Execution Timestamp:** 2026-11-24T14:52:00+05:30  
**Audit Verdict:** **ROOT CAUSE VERIFIED — WMI UNKNOWN (STATE 0) BLOCKING POLICY**

---

## 1. Executive Summary

Following the successful migration of `EPSON L6460 Series` to Standard TCP/IP Port `192.168.1.7:9100` and the successful reconnection of the candidate Printer Agent (PID `7664`), the customer QR endpoint and fleet overview card continue to report:
> **`PRINTER DISCONNECTED`** (`isOnline: false`)

This Phase 5 audit has uncovered and empirically proven the **exact 5-link causation chain**:
1. **Windows WMI Behavior:** Windows Spooler and WMI (`Win32_Printer`) report `WorkOffline = False`, `PrinterStatus = 3` (Idle/Ready), but `DetectedErrorState = 0` (`Unknown`). Standard TCP/IP port monitors on Windows do not implement bidirectional SNMP polling by default, so Windows sets `DetectedErrorState` to `0` ("No error detected / Error state unknown").
2. **Flawed Agent Policy:** `printer-agent/src/printerStatusMapping.js` explicitly defines `DetectedErrorState: 0` as `{ isError: true, isBlocking: true, message: 'Printer State Unknown' }`.
3. **Monitor Disqualification:** In `printer-agent/src/printerFleetManager.js`, `canPrint` is evaluated for each approved device. Because `isBlocking === true`, `canPrint` is set to `false`. Consequently, `nextMonitors.set(device.id, monitor)` is never executed, leaving `fleetManager.monitors.size === 0` (0 active independent monitors).
4. **Fallback Spooler Monitor Trigger:** In `printer-agent/index.js`, because `monitors.size === 0`, the agent falls back to legacy `spoolerMonitor.checkPrinterStatus()`. This monitor queries WMI, sees `DetectedErrorState = 0`, and emits `socket.emit('printer_status_update', { isError: true, errorMessage: 'Printer State Unknown' })`.
5. **Backend Database & Availability Evaluation:** In `backend/src/socket.js`, `PrinterStatus.isOnline` is saved as `!status.isError` (`false`). In `backend/src/services/printerAvailability.service.js`, `if (!isOnline) return PRINTER_DISCONNECTED`.

---

## 2. Audit 1 — PrinterDevice Database Records & Discrepancy Resolution

### A. Live Staging Database Inspection
An authenticated WebSocket handshake and device registry query (`printer_device_registry_request`) was performed against the Staging Backend for Machine `d010496f-f176-41fe-9c98-efd2213a4a0e`.

**Actual Registered `PrinterDevice` Records in Staging PostgreSQL:**
```json
[
  {
    "id": "619665e1-3c64-44eb-8f57-cb8c3c895e9b",
    "displayName": "EPSON L6460 Series",
    "windowsPrinterName": "EPSON L6460 Series",
    "status": "ACTIVE",
    "approvedAt": "2026-11-23T22:54:55.286Z",
    "sortOrder": 0
  },
  {
    "id": "77554510-b102-40c7-957f-6f735eba0bdc",
    "displayName": "HP LaserJet Professional M1136 MFP (Copy 1)",
    "windowsPrinterName": "HP LaserJet Professional M1136 MFP (Copy 1)",
    "status": "ACTIVE",
    "approvedAt": "2026-11-23T22:57:00.425Z",
    "sortOrder": 1
  },
  {
    "id": "114c0092-e3c6-4432-b17f-e7c6f42ec334",
    "displayName": "Canon Generic Plus UFR II (Copy 2)",
    "windowsPrinterName": "Canon Generic Plus UFR II (Copy 2)",
    "status": "ACTIVE",
    "approvedAt": "2026-11-23T22:58:47.915Z",
    "sortOrder": 2
  }
]
```

- **Epson L6460 Status:** **YES**, an approved `PrinterDevice` row exists (`id: 619665e1-3c64-44eb-8f57-cb8c3c895e9b`, `status: ACTIVE`, `approvedAt: 2026-11-23T22:54:55.286Z`).
- **All 3 Devices are ACTIVE:** All three devices were approved on `2026-11-23` between `22:54` and `22:58 UTC`.

### B. Discrepancy Explanation
- **Earlier Diagnostic Reports:** Stated that 3 approved devices were active in the database. This was **factually correct**.
- **Phase 4 Report Ambiguity:** The Phase 4 startup report observed the agent console log:
  ```
  🖨️ Printer fleet synchronized: 14 Windows queue(s) discovered; 0 approved device(s) have independent monitors.
  ```
  This log was mistakenly interpreted in prose as meaning "0 approved devices exist in the database".
- **The True Reality:** The backend returned **3 approved devices** in the `printer_device_registry` event. However, the agent's internal filtering logic (`fleetManager.refresh()`) evaluated `canPrint: false` for all 3 devices because of `DetectedErrorState: 0`. As a result, **0 devices were assigned independent monitors**, which printed the misleading log line `0 approved device(s) have independent monitors`.

### C. Role of `ADMIN_READ_ONLY` Mode
- `ADMIN_READ_ONLY="true"` is configured in `render.staging.yaml` (line 37).
- It intercepts HTTP mutation methods (`POST`, `PUT`, `DELETE`, `PATCH`) on `/api/admin/*`.
- It prevented subsequent *new* UI approvals or mutations from being executed without exemptions.
- It **does not affect** WebSocket connections, agent protocol handshakes, or existing records stored in PostgreSQL.

---

## 3. Audit 2 — Agent Monitor Selection & Fleet Manager Logic

### A. Monitor Initialization Flow
In `printer-agent/index.js` (lines 253–264):
```javascript
const nextFleetManager = new PrinterFleetManager({
  maxDevices: 10,
  journal,
  discoverPrinters: async () => discoveredPrinters,
  getDeviceRegistry: async () => devices,
  monitorFactory: ({ printerDevice, printerName }) => new SpoolerMonitor({
    execFile,
    printerName,
    printerDeviceId: printerDevice.id,
    journal
  })
});
```

### B. Device Filtering & Disqualification in `printerFleetManager.js`
In `printer-agent/src/printerFleetManager.js` (lines 155–182):
```javascript
const approvalValid = device.status === ACTIVE_DEVICE_STATUS && !!device.approvedAt;
let canPrint = approvalValid && !!discoveredPrinter;
let reason = null;

if (device.status !== ACTIVE_DEVICE_STATUS) {
  reason = 'ADMIN_APPROVAL_REQUIRED';
} else if (!device.approvedAt) {
  reason = 'APPROVAL_EVIDENCE_MISSING';
} else if (!device.windowsPrinterName) {
  reason = 'WINDOWS_QUEUE_NOT_BOUND';
} else if (!discoveredPrinter) {
  reason = 'WINDOWS_QUEUE_NOT_PRESENT';
} else if (discoveredPrinter.workOffline === true) {
  canPrint = false;
  reason = 'PRINTER_OFFLINE';
} else if (discoveredPrinter.detectedErrorState !== null && discoveredPrinter.detectedErrorState !== undefined) {
  const errorState = interpretDetectedErrorState(discoveredPrinter.detectedErrorState);
  if (errorState && errorState.isBlocking) {
    canPrint = false;
    reason = errorState.code === 9 ? 'PRINTER_OFFLINE' : 'PRINTER_ERROR_STATE';
  }
}

if (canPrint) {
  const monitor = this.monitorFactory({
    printerDevice: device,
    printerName: device.windowsPrinterName
  });
  if (monitor) nextMonitors.set(device.id, monitor);
}
```

### C. Live Empirical Simulation of `fleetManager.refresh()`
Executing `PrinterFleetManager.refresh()` with the 3 live database records and live Windows discovery produces:
```
619665e1-3c64-44eb-8f57-cb8c3c895e9b EPSON L6460 Series -> canPrint: false, reason: PRINTER_ERROR_STATE
77554510-b102-40c7-957f-6f735eba0bdc HP LaserJet M1136   -> canPrint: false, reason: PRINTER_ERROR_STATE
114c0092-e3c6-4432-b17f-e7c6f42ec334 Canon Generic Plus  -> canPrint: false, reason: PRINTER_ERROR_STATE
Active monitors count: 0
```
- **Finding:** Because `canPrint` evaluates to `false` due to `interpretDetectedErrorState(0).isBlocking === true`, `nextMonitors` is completely empty (`size: 0`).
- **Fallback Trigger:** In `printer-agent/index.js` (line 201):
  ```javascript
  if (fleetManager && fleetManager.monitors.size > 0) {
    fleetManager.checkPrinterStatuses(socket);
  } else {
    spoolerMonitor.checkPrinterStatus(socket); // <-- FALLBACK EXECUTED
  }
  ```
- **Conclusion:** Epson is **NOT** being monitored by its intended device-scoped monitor (`printerDeviceId: 619665e1-3c64-44eb-8f57-cb8c3c895e9b`). It is trapped in the fallback single-printer monitor.

---

## 4. Audit 3 — WMI Status Mapping Analysis

### A. Mapping for `DetectedErrorState = 0`
In `printer-agent/src/printerStatusMapping.js` (lines 27–40):
```javascript
const WIN32_DETECTED_ERROR_STATE = Object.freeze({
  0: { code: 0, name: 'Unknown', isError: true, isWarning: false, isBlocking: true, message: 'Printer State Unknown', reason: 'PRINTER_STATE_UNKNOWN' },
  1: { code: 1, name: 'Other', isError: true, isWarning: false, isBlocking: true, message: 'Printer Error', reason: 'PRINTER_ERROR_STATE' },
  2: { code: 2, name: 'No Error', isError: false, isWarning: false, isBlocking: false, message: '', reason: null },
  3: { code: 3, name: 'Low Paper', isError: false, isWarning: true, isBlocking: false, message: 'Low Paper', reason: null },
  4: { code: 4, name: 'No Paper', isError: true, isWarning: false, isBlocking: true, message: 'Out of Paper', reason: 'PRINTER_NO_PAPER' },
  5: { code: 5, name: 'Low Toner', isError: false, isWarning: true, isBlocking: false, message: 'Low Toner', reason: null },
  6: { code: 6, name: 'No Toner', isError: true, isWarning: false, isBlocking: true, message: 'No Toner', reason: 'PRINTER_NO_TONER' },
  7: { code: 7, name: 'Door Open', isError: true, isWarning: false, isBlocking: true, message: 'Door Open', reason: 'PRINTER_DOOR_OPEN' },
  8: { code: 8, name: 'Jammed', isError: true, isWarning: false, isBlocking: true, message: 'Paper Jam', reason: 'PRINTER_PAPER_JAM' },
  9: { code: 9, name: 'Offline', isError: true, isWarning: false, isBlocking: true, message: 'Printer Offline', reason: 'PRINTER_OFFLINE' },
  10: { code: 10, name: 'Service Requested', isError: true, isWarning: false, isBlocking: true, message: 'Service Requested', reason: 'PRINTER_SERVICE_REQUESTED' },
  11: { code: 11, name: 'Output Bin Full', isError: true, isWarning: false, isBlocking: true, message: 'Output Bin Full', reason: 'PRINTER_OUTPUT_BIN_FULL' }
});
```

### B. Interpretation of `PrinterStatus = 3` and `WorkOffline = false`
- **`PrinterStatus = 3` (Idle):**
  - In Windows `Win32_Printer` CIM definition, `3` means `Idle` (the queue is healthy and waiting for jobs).
  - In `printer-agent/src/spooler.js` (lines 100–127), `PrinterStatus` is **never parsed or evaluated**.
  - In `printer-agent/src/windowsPrinterDiscovery.js`, `PrinterStatus` is extracted but **never checked** in `printerFleetManager.js`.
- **`WorkOffline = false`:**
  - Evaluated in `spooler.js` line 104. Since it is `false`, `isError` remains `false` until it hits `else if (detectedErrorState !== null)`.
- **Sole Source of Failure:**
  - `isError` becomes `true` and `isBlocking` becomes `true` **solely and exclusively** because `DetectedErrorState = 0`.

### C. Separate Connectivity Checks
- **Network Printers:** There is **NO** TCP socket, ICMP, or port 9100 connectivity probe in `printer-agent`.
- The agent relies entirely on PowerShell querying `Win32_Printer`.

### D. Existing Test Coverage
1. `printer-agent/tests/printerStatusMapping.test.js` (line 51):
   - Explicitly tests and asserts that `code: 0` (`Unknown`) must return `isError: true, isBlocking: true`.
2. `printer-agent/tests/spooler.test.js` (line 89):
   - Explicitly tests: `it('should emit Printer State Unknown on DetectedErrorState 0 (Unknown)', ...)`.
3. `printer-agent/tests/printerFleetManager.test.js` (line 156):
   - Tests healthy printers using mocked `detectedErrorState: 2` ("No Error").
   - **Test Gap:** No unit or integration test was ever written for real-world Windows TCP/IP port queues where `detectedErrorState: 0`. The test suite incorrectly assumed Windows queues return `2` when healthy.

---

## 5. Audit 4 — Backend Availability Evaluation Chain

```mermaid
flowchart TD
    WMI["1. Windows WMI (Win32_Printer)<br/>WorkOffline: False<br/>PrinterStatus: 3 (Idle)<br/>DetectedErrorState: 0"] --> FleetMgr{"2. Agent FleetManager<br/>interpretDetectedErrorState(0)<br/>isBlocking === true"}
    FleetMgr -->|canPrint = false| ZeroMonitors["fleetManager.monitors.size === 0<br/>(0 Approved Monitors)"]
    ZeroMonitors --> Fallback["3. Fallback SpoolerMonitor<br/>queries PRINTER_NAME<br/>DetectedErrorState: 0 -> isError: true"]
    Fallback --> SocketEmit["4. socket.emit('printer_status_update')<br/>{ isError: true, errorMessage: 'Printer State Unknown' }"]
    SocketEmit --> BackendSocket["5. backend/src/socket.js<br/>prisma.printerStatus.create({ isOnline: false })"]
    BackendSocket --> AvailSvc["6. printerAvailability.service.js<br/>if (!isOnline) -> PRINTER_DISCONNECTED"]
    AvailSvc --> QRResp["7. GET /api/auth/printer-qr/:code<br/>hardwareStatus: 'PRINTER_DISCONNECTED'<br/>agentOnline: true"]
```

### Exact Source References:
- **WMI Query:** `printer-agent/src/spooler.js#L11` & `windowsPrinterDiscovery.js#L6`
- **Error Mapping:** `printer-agent/src/printerStatusMapping.js#L28`
- **Fleet Manager Disqualification:** `printer-agent/src/printerFleetManager.js#L170-L176`
- **Fallback Selection:** `printer-agent/index.js#L201-L205`
- **Spooler Monitor Emit:** `printer-agent/src/spooler.js#L114-L135`
- **Backend Socket Ingestion:** `backend/src/socket.js#L325-L333`
- **Availability Computation:** `backend/src/services/printerAvailability.service.js#L193-L203`
- **QR Endpoint Response:** `backend/src/modules/customer/printerQr.customer.controller.js#L70-L105`

---

## 6. Audit 5 — Recommendations & Minimal Proposed Change

### A. Architectural Context
In the Windows Driver Model:
- `DetectedErrorState` is defined by the CIM `Win32_Printer` schema.
- Code `0` is labeled `Unknown`.
- Standard TCP/IP port monitors (`tcpmon.dll`), RAW 9100 sockets, and basic USB class drivers **do not report active error states to WMI**. They report `DetectedErrorState: 0` permanently.
- Windows signals printer health through **`WorkOffline = False`** and **`PrinterStatus = 3 (Idle)`** or **`PrinterStatus = 4 (Printing)`**.
- Only printers with active, proprietary bi-directional status communication (e.g. Epson Status Monitor 3 or active SNMP community configurations) report `DetectedErrorState: 2` ("No Error").

### B. Minimal Proposed Fix (Agent Side Only)
To safely accommodate real-world Windows print queues without compromising safety:

**Rule:** `DetectedErrorState: 0` (`Unknown`) must **not** be treated as a fatal blocking error when the spooler confirms the queue is actively online and idle/ready.

In `printer-agent/src/printerStatusMapping.js`:
Change `WIN32_DETECTED_ERROR_STATE[0]` from:
```javascript
0: { code: 0, name: 'Unknown', isError: true, isWarning: false, isBlocking: true, message: 'Printer State Unknown', reason: 'PRINTER_STATE_UNKNOWN' },
```
To:
```javascript
0: { code: 0, name: 'Unknown', isError: false, isWarning: false, isBlocking: false, message: '', reason: null },
```
Or provide a contextual evaluator in `printerFleetManager.js` and `spooler.js`:
```javascript
// A DetectedErrorState of 0 (Unknown) is non-blocking if the queue is not WorkOffline
const isBlockingError = errorState && errorState.isBlocking && !(errorState.code === 0 && discoveredPrinter.workOffline === false);
```

### C. Gaps, Risks & Required Regression Tests
1. **Existing Unit Test Updates:**
   - Update `printerStatusMapping.test.js` (line 51) to reflect that `code: 0` is non-blocking when queue is healthy.
   - Update `spooler.test.js` (line 89) to reflect non-blocking behavior for `DetectedErrorState: 0`.
   - Add new test cases in `printerFleetManager.test.js` validating that queues with `DetectedErrorState: 0` and `WorkOffline: false` successfully obtain monitors (`canPrint: true`).
2. **Safety Preservation:**
   - True physical errors (`code 4`: Out of Paper, `code 6`: No Toner, `code 7`: Door Open, `code 8`: Jam, `code 9`: Offline, and `WorkOffline: True`) remain **100% blocking**.
3. **Rollback Plan:**
   - Toggling `code: 0` back to `isBlocking: true` is a one-line change that immediately restores the prior strict behavior.

---

## 7. Final Checklist & Next Steps

| Audit Item | Status | Key Finding |
|---|:---:|---|
| **1. Database Records** | **VERIFIED** | 3 approved `PrinterDevice` rows exist; Epson is row `619665e1-3c64...` |
| **2. Report Discrepancy** | **RESOLVED** | Log meant "0 approved *monitors* running", not 0 DB records |
| **3. Agent Monitor Selection** | **VERIFIED** | `canPrint: false` caused `monitors.size === 0`, falling back to single monitor |
| **4. WMI Mapping Analysis** | **VERIFIED** | `DetectedErrorState = 0` is the sole trigger for `isError: true` |
| **5. Availability Chain** | **VERIFIED** | Full end-to-end chain traced with 100% precision |
| **6. Minimal Fix Identified** | **READY** | Treat `DetectedErrorState: 0` as non-blocking when `WorkOffline: false` |

*(STRICT READ-ONLY AUDIT COMPLETE. No modifications have been made.)*
