function runPrinterStatusMonitoring({ mode, fleetManager, spoolerMonitor, socket, connected = true }) {
  if (!connected || mode === 'PENDING' || mode === 'REJECTED' || !mode) {
    return { mode: mode || 'PENDING', monitored: false, monitorCount: 0 };
  }

  if (mode === 'MULTI_PRINTER') {
    const monitorCount = fleetManager?.monitors?.size || 0;
    if (monitorCount > 0) {
      fleetManager.checkPrinterStatuses(socket);
      return { mode: 'multi-printer', monitored: true, monitorCount };
    }
    return { mode: 'multi-printer', monitored: false, monitorCount: 0 };
  }

  if (mode === 'LEGACY') {
    spoolerMonitor.checkPrinterStatus(socket);
    return { mode: 'legacy', monitored: true, monitorCount: 1 };
  }

  return { mode: 'PENDING', monitored: false, monitorCount: 0 };
}

module.exports = { runPrinterStatusMonitoring };
