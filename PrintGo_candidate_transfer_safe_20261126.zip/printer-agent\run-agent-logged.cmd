@echo off
cd /d "D:\PrintGo-S3K-MULTIPRINTER-CANDIDATE\printer-agent"
"C:\Program Files\nodejs\node.exe" index.js 1>>"logs\agent.stdout.log" 2>>"logs\agent.stderr.log"
exit /b %ERRORLEVEL%
