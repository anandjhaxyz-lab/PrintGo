const jwt = require('jsonwebtoken');
const AppError = require('../utils/AppError');
const prisma = require('../utils/prisma');

const protect = async (req, res, next) => {
  try {
    let token;
    
    if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
      token = req.headers.authorization.split(' ')[1];
    } else if (req.cookies?.jwt) {
      token = req.cookies.jwt;
    }
    
    if (!token) {
      return next(new AppError('You are not logged in! Please log in to get access.', 401));
    }
    
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    
    const currentUser = await prisma.user.findUnique({
      where: { id: decoded.id }
    });
    
    if (!currentUser) {
      return next(new AppError('The user belonging to this token does no longer exist.', 401));
    }
    
    req.user = currentUser;
    next();
  } catch (error) {
    next(new AppError('Invalid token or token has expired', 401));
  }
};

const restrictTo = (...roles) => {
  return (req, res, next) => {
    if (!roles.includes(req.user.role)) {
      return next(new AppError('You do not have permission to perform this action', 403));
    }
    next();
  };
};

const protectMachine = async (req, res, next) => {
  try {
    const machineKey = req.headers['x-machine-key'];
    if (!machineKey) {
      return next(new AppError('Authentication error: Missing machine key', 401));
    }

    const machine = await prisma.machine.findUnique({ where: { machineKey } });
    if (!machine) {
      return next(new AppError('Authentication error: Invalid machine key', 401));
    }
    if (machine.status === 'SUSPENDED') {
      return next(new AppError('Authentication error: Machine is suspended', 401));
    }

    req.machine = machine;
    next();
  } catch (error) {
    next(new AppError('Machine authentication failed', 401));
  }
};

module.exports = { protect, restrictTo, protectMachine };
