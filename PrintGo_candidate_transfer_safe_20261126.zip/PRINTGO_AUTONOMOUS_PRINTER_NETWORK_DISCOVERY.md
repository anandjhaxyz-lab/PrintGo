# PRINTGO — AUTONOMOUS PRINTER NETWORK DISCOVERY & DIAGNOSTIC REPORT

**Host:** `DESKTOP-QB6Q3BC` (`192.168.1.10`)  
**Gateway:** `192.168.1.1` (Nokia GPON Gateway `40-48-6E-05-13-61`)  
**Execution Mode:** STRICT READ-ONLY AUDIT & DISCOVERY  
**Machine Identity:** `Main Shop Printer` (`d010496f-f176-41fe-9c98-efd2213a4a0e`)  
**Date/Timestamp:** 2026-11-24T12:57:30+05:30  

---

## EXECUTIVE SUMMARY

A full autonomous audit was conducted across the Windows host subsystem, local USB bus (PnP), Windows Print Spooler registry/WMI, and the entire `192.168.1.0/24` subnet.

### Key Discoveries:
1. **Networked Printers Online:**
   - **Canon imageRUNNER ADVANCE 4545** is **ONLINE** at **`192.168.1.3`** (MAC: `F8-0D-60-9A-5C-DC`). Open ports: `9100` (RAW), `515` (LPR), `80/443/8000` (Canon Remote UI), WSD MEX endpoint active.
   - **EPSON L6460 Series** is **ONLINE** at **`192.168.1.7`** (MAC: `64-C6-D2-E5-23-65`). Open ports: `9100` (RAW), `631` (IPP), `515` (LPR), `80/443` (Epson Web Config EWS). Windows Spooler has matching port `EPE52365:L6460 SERIES`.
2. **Physical USB Printer State:**
   - All approved PrintGo queues (`EPSON L6460 Series` on `USB019`, `HP LaserJet Professional M1136 MFP (Copy 1)` on `USB011`, and `Canon Generic Plus UFR II (Copy 2)` on `USB001`) are bound to virtual USB ports where the physical USB cables are currently **disconnected/powered off** (`CM_PROB_PHANTOM`, Error 45).
3. **Non-Printer Network Devices Identified:**
   - `192.168.1.2`: Windows PC `DESKTOP-ILASQ4H` (HP, MAC `FC-15-B4-EA-62-14`).
   - `192.168.1.11`: Windows PC `DESKTOP-3LEQN6R` (Intel, MAC `00-C2-C6-4D-AD-B9`).
   - `192.168.1.6`: IoT module (Earda Technologies, MAC `AC-F4-2C-AD-61-D5`). No printing ports.
   - `192.168.1.12`: Client device with randomized private MAC (`BA-DB-E6-BC-D5-1A`).
   - `192.168.1.39`: Historical HP M128fw (`DEV2C8B2D`) WSD endpoint — currently unreachable (powered off).
4. **Root Cause of Dashboard `PRINTER DISCONNECTED` Status:**
   - The backend approval mutation does not push real-time WebSocket fleet update events to the running Agent.
   - Agent PID 516 (connected prior to approvals) has `monitors.size === 0` and runs the single-printer fallback spooler monitor on `PRINTER_NAME` (`EPSON L6460 Series`).
   - Because the Epson is monitored via the phantom `USB019` queue (which reports `WorkOffline: True`), the agent reports `isError: true` (`"Printer Offline"`), driving the backend availability calculation to `PRINTER_DISCONNECTED`.

---

## 1. WINDOWS PRINTER FLEET INVENTORY

Full audit of all 14 Windows Print Spooler queues (`Get-Printer` and WMI `Win32_Printer`):

| Queue Name | Driver Name | Port Name | Spooler Status | Work Offline | Attributes | Physical State |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **EPSON L6460 Series** *(Approved Default)* | EPSON L6460 Series | `USB019` | Normal | **True** | 3652 (0x0e44) | USB Phantom (Disconnected) |
| **HP LaserJet Professional M1136 MFP (Copy 1)** *(Approved)* | HP LaserJet Professional M1136 MFP | `USB011` | Normal | **True** | 3648 (0x0e40) | USB Phantom (Disconnected) |
| **Canon Generic Plus UFR II (Copy 2)** *(Approved)* | Canon Generic Plus UFR II | `USB001` | Normal | **True** | 3648 (0x0e40) | USB Phantom (Disconnected) |
| **Canon iR-ADV 4545** | Canon Generic Plus UFR II | `WSD-45aba35d-ee5d-435f-9b20-2e3cd045e937` | Normal | **False** | 2624 (0x0a40) | **Network ONLINE (`192.168.1.3`)** |
| **Canon Generic Plus UFR II (Copy 1)** | Canon Generic Plus UFR II | `192.168.1.6` | Normal | **True** | 3648 (0x0e40) | Port Mismatched (Points to IoT) |
| **HP LaserJet Pro MFP M128fw** | Microsoft IPP Class Driver | `WSD-c5b0ca64-b8b1-4a47-a84d-d17fef04ec69` | Normal | **False** | 2624 (0x0a40) | Network Offline (Was `192.168.1.39`) |
| **HP LaserJet Professional M1136 MFP** | HP LaserJet Professional M1136 MFP | `USB003` | Normal | **True** | 3648 (0x0e40) | USB Phantom (Disconnected) |
| **HP LaserJet 1018** | HP LaserJet 1018 | `USB014` | Normal | **True** | 3648 (0x0e40) | USB Phantom (Disconnected) |
| **Canon LBP2900** | Canon LBP2900 | `USB007` | Normal | **True** | 3648 (0x0e40) | USB Phantom (Disconnected) |
| **Microsoft Print to PDF** | Microsoft Print To PDF | `PORTPROMPT:` | Normal | False | 576 (0x0240) | Software |
| **Microsoft XPS Document Writer** | Microsoft XPS Document Writer v4 | `PORTPROMPT:` | Normal | False | 576 (0x0240) | Software |
| **OneNote (Desktop)** | Send to Microsoft OneNote 16 Driver | `nul:` | Normal | False | 2624 (0x0a40) | Software |
| **OneNote for Windows 10** | Microsoft Software Printer Driver | `nul:` | Normal | False | 2624 (0x0a40) | Software |
| **Fax** | Microsoft Shared Fax Driver | `SHRFAX:` | Normal | False | 2624 (0x0a40) | Software |

*Note on Attributes:* Attribute `3652` / `3648` includes flag `0x0400` (`PRINTER_ATTRIBUTE_WORK_OFFLINE`), causing Windows applications and WMI queries to report the printer as offline.

---

## 2. PHYSICAL USB CONNECTIVITY AUDIT (PnP SUBSYSTEM)

Inspection of Windows Plug-and-Play (`Get-PnpDevice` for Classes `Printer`, `USB`, `USBDevice`, `PrintQueue`):

| Device Name | Device ID / Instance Path | ConfigManager Status | Problem Code |
| :--- | :--- | :--- | :--- |
| **EPSON L6460 Series** | `SWD\PRINTENUM\{1283B1A2-4CFB-4F54-9494-1D96576C759C}` | `Unknown` | `CM_PROB_PHANTOM` (45) |
| **HP LaserJet Professional M1136 MFP (Copy 1)** | `SWD\PRINTENUM\{28B61EAF-745C-40FE-A9A4-688E2EF62121}` | `Unknown` | `CM_PROB_PHANTOM` (45) |
| **Canon Generic Plus UFR II (Copy 2)** | `SWD\PRINTENUM\{C2CD8917-DF2E-4D6F-9C1D-89C3FEA74C42}` | `Unknown` | `CM_PROB_PHANTOM` (45) |
| **HP LaserJet 1018** | `SWD\PRINTENUM\{A0EC1BBE-6C43-4552-AB2E-D1EC32D567AA}` | `Unknown` | `CM_PROB_PHANTOM` (45) |
| **Canon LBP2900** | `SWD\PRINTENUM\{AC52F2FA-AC6C-4977-80B8-F51BC71B0466}` | `Unknown` | `CM_PROB_PHANTOM` (45) |

**Physical USB Assessment:**  
None of the physical USB cables for these printers are actively enumerating on the USB controller (`USB\VID_*&PID_*`). In Windows PnP terminology, `CM_PROB_PHANTOM` (Error 45: "Currently, this hardware device is not connected to the computer") confirms that the physical cables are either unplugged or the printers are switched off at the physical power switch.

---

## 3. NETWORK TOPOLOGY & PRINTER DISCOVERY

Subnet: `192.168.1.0/24` (Local PC: `192.168.1.10`, Default Gateway: `192.168.1.1`)

```
                          [ 192.168.1.1 ]
                        Nokia GPON Gateway
                                |
       +------------------------+------------------------+
       |                        |                        |
[ 192.168.1.10 ]         [ 192.168.1.3 ]          [ 192.168.1.7 ]
Windows Shop PC       Canon imageRUNNER ADV     Epson L6460 Series
(PrintGo Host)          4545 (ONLINE)              (ONLINE)
       |                        |                        |
  USB Queues:             RAW: 9100                RAW: 9100
  - USB019 (Epson)        LPR: 515                 IPP: 631
  - USB011 (HP)           WSD: 80/wsd/mex          LPR: 515
  - USB001 (Canon)        Web: 8000/80/443         EWS: 80/443
  (All Disconnected)
```

### Detailed Network Host Audit

#### 1. Canon imageRUNNER ADVANCE 4545 — `192.168.1.3`
- **MAC Address:** `F8-0D-60-9A-5C-DC` (OUI: **CANON INC.**)
- **Host / Device Name:** `iR-ADV 4545`
- **WSD Endpoint:** `http://192.168.1.3:80/wsd/mex`
- **WSD Hardware UUID:** `urn:uuid:6d4ff0ce-6b11-11d8-8020-f80d609a5cdc` (matches MAC `f80d609a5cdc`)
- **Web UI:** Port 8000 / 80 / 443 — Canon Remote UI (`<title>User Authentication : iR-ADV 4545 : iR-ADV 4545</title>`)
- **Printing Protocols:**
  - **Port 9100 (RAW JetDirect):** **OPEN / LISTENING**
  - **Port 515 (LPD/LPR):** **OPEN / LISTENING**
  - **Port 80/443 (HTTP/HTTPS):** **OPEN / LISTENING**
- **Status:** **FULLY ONLINE and ready for network printing**.

#### 2. EPSON L6460 Series — `192.168.1.7`
- **MAC Address:** `64-C6-D2-E5-23-65` (OUI: **Seiko Epson Corporation**)
- **Host / Device Name:** `L6460 Series`
- **Windows Port:** `EPE52365:L6460 SERIES` (configured in Spooler, matches MAC suffix `E52365`)
- **Web UI:** Port 80 / 443 — Epson Web Config (`<title>L6460 Series</title>`)
- **Printing Protocols:**
  - **Port 9100 (RAW JetDirect):** **OPEN / LISTENING**
  - **Port 631 (IPP):** **OPEN / LISTENING**
  - **Port 515 (LPD/LPR):** **OPEN / LISTENING**
  - **Port 80/443 (HTTP/HTTPS):** **OPEN / LISTENING**
- **Status:** **FULLY ONLINE and ready for network printing**.

#### 3. HP LaserJet Pro MFP M128fw — (Former `192.168.1.39`)
- **Hardware Suffix:** `DEV2C8B2D` (MAC suffix: `2C-8B-2D`)
- **Windows Port:** `WSD-c5b0ca64-b8b1-4a47-a84d-d17fef04ec69` (Driver: `Microsoft IPP Class Driver`)
- **WSD Hardware UUID:** `urn:uuid:1e45875e-488a-7bf0-fd5b-8966bd7660e1`
- **Location in Registry:** `http://192.168.1.39:3911/1e45875e-488a-7bf0-fd5b-8966bd7660e1`
- **Network Status:** Currently unreachable (Ping and TCP connect fail; MAC `2C-8B-2D` absent from ARP table). The device is currently switched off or offline.

#### 4. Non-Printer Network Devices Identified (Negative Confirmations)
- **`192.168.1.2`:** MAC `FC-15-B4-EA-62-14` (Hewlett Packard). NetBIOS: `DESKTOP-ILASQ4H`. Port 5357 (WSDAPI) open. **Windows Desktop PC**.
- **`192.168.1.11`:** MAC `00-C2-C6-4D-AD-B9` (Intel Corporate). NetBIOS: `DESKTOP-3LEQN6R`. Port 5357 (WSDAPI) open. **Windows Desktop PC**.
- **`192.168.1.6`:** MAC `AC-F4-2C-AD-61-D5` (Earda Technologies Co.,Ltd). Ping responds, but all printing ports (80/443/515/631/9100/5357) are closed. **IoT Device / Smart Plug**. (Note: Queue `Canon Generic Plus UFR II (Copy 1)` is configured with port `192.168.1.6`, which is a stale/incorrect port configuration).
- **`192.168.1.12`:** MAC `BA-DB-E6-BC-D5-1A` (Randomized locally administered MAC). No printing ports. **Client Mobile / Tablet Device**.
- **`192.168.1.1`:** MAC `40-48-6E-05-13-61` (Nokia Solutions). **Default Gateway / Fiber Router**.

---

## 4. PROTOCOL CONNECTIVITY & PORT MATRIX

| Target IP | Host/Device | RAW (9100) | IPP (631) | LPR (515) | HTTP (80) | HTTPS (443) | WSD (5357) | Classification |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **`192.168.1.1`** | Nokia Router | Closed | Closed | Closed | **Open** | **Open** | Closed | Network Gateway |
| **`192.168.1.2`** | `DESKTOP-ILASQ4H` | Closed | Closed | Closed | Closed | Closed | **Open** | Windows Host (Not Printer) |
| **`192.168.1.3`** | `iR-ADV 4545` | **Open** | Closed | **Open** | **Open** | **Open** | Closed | **Canon Network Printer (ONLINE)** |
| **`192.168.1.6`** | IoT Device | Closed | Closed | Closed | Closed | Closed | Closed | IoT Device (Not Printer) |
| **`192.168.1.7`** | `L6460 Series` | **Open** | **Open** | **Open** | **Open** | **Open** | Closed | **Epson Network Printer (ONLINE)** |
| **`192.168.1.10`** | `DESKTOP-QB6Q3BC` | Closed | Closed | Closed | Closed | Closed | **Open** | Local Shop Host (This PC) |
| **`192.168.1.11`** | `DESKTOP-3LEQN6R` | Closed | Closed | Closed | Closed | Closed | **Open** | Windows Host (Not Printer) |
| **`192.168.1.12`** | Client Phone | Closed | Closed | Closed | Closed | Closed | Closed | Mobile Phone / Wi-Fi Client |
| **`192.168.1.39`** | `HP M128fw` | Down | Down | Down | Down | Down | Down | Printer (Powered Off) |

---

## 5. PRINTGO AGENT & TELEMETRY DESYNCHRONIZATION ANALYSIS

### Architecture & Data Flow

```
+-------------------------------------------------------------------------------+
| STAGING CLOUD BACKEND                                                         |
|                                                                               |
|  1. Admin approves printer discovery                                          |
|     -> Creates PrinterDevice records in PostgreSQL                            |
|     -> [GAP]: Does NOT emit WebSocket event to connected agent!               |
+-------------------------------------------------------------------------------+
                                      |
                      WebSocket (Heartbeat & Spooler Only)
                                      v
+-------------------------------------------------------------------------------+
| PRINTGO AGENT (Host: DESKTOP-QB6Q3BC, PID: 516)                               |
|                                                                               |
|  2. Agent Fleet Monitor: monitors.size === 0 (no approval event received)     |
|  3. Fallback: Activates spoolerMonitor for PRINTER_NAME ("EPSON L6460 Series")|
|  4. Spooler Query: "EPSON L6460 Series" is bound to USB019                    |
|  5. WMI Win32_Printer: USB019 has WorkOffline: True (Cable Disconnected)     |
|  6. Telemetry Emission: Sends printer_status_update { isError: true,          |
|                         error: "Printer Offline" }                            |
+-------------------------------------------------------------------------------+
                                      |
                                      v
+-------------------------------------------------------------------------------+
| STAGING CLOUD BACKEND AVAILABILITY EVALUATION                                 |
|                                                                               |
|  7. printerStatus.service.js writes PrinterStatus.isOnline = false            |
|  8. computePrinterAvailability() checks:                                      |
|     if (!status || !status.isOnline) return 'PRINTER_CONNECTED' -> FALSE      |
|     Result: "PRINTER DISCONNECTED" displayed in Admin UI                      |
+-------------------------------------------------------------------------------+
```

### Detailed Causality Chain:
1. **Approval Event Gap:** When the admin approves discovered printers via `/api/admin/printer-discovery/approve`, the backend inserts records into `PrinterDevice`, but does not notify the agent via `ws.send(JSON.stringify({ type: 'PRINTER_DEVICES_UPDATED' }))`.
2. **Agent Stale State:** Agent PID 516 (connected at `02:36 AM`) only initializes multi-device monitors when receiving `PRINTER_CONFIG` or `PRINTER_DEVICES_UPDATED`. Because no event was sent, `this.monitors` remained empty (`size === 0`).
3. **Fallback Loop Triggered:** Agent's `agent.js` checks:
   ```javascript
   if (this.multiDeviceManager && this.multiDeviceManager.monitors.size > 0) {
       // Multi-device fleet monitoring
   } else {
       // Fallback: poll Windows spooler for process.env.PRINTER_NAME
       this.spoolerMonitor.start();
   }
   ```
4. **Physical USB vs Network Discrepancy:** The default `PRINTER_NAME` is configured as `"EPSON L6460 Series"`. That queue points to `USB019`. Because the physical USB cable is detached, WMI returns `WorkOffline: True`.
5. **Backend Evaluates Disconnection:** The agent sends `printer_status_update` with `isError: true`. The staging backend sets `isOnline: false`. `computePrinterAvailability` therefore marks the entire machine's printer state as `PRINTER DISCONNECTED`.

---

## 6. CONFIRMED ISSUES & ROOT CAUSES

1. **Physical Cabling / Power State (Primary Root Cause for USB Queues):**
   - The three approved devices in PrintGo are bound to `USB019`, `USB011`, and `USB001`.
   - All three physical USB interfaces are currently disconnected (`CM_PROB_PHANTOM`).
2. **Networked Printers are Active but Ignored by PrintGo:**
   - Both the **Epson L6460** (`192.168.1.7`) and **Canon 4545** (`192.168.1.3`) are powered on and actively responding to print requests on Port 9100 / LPR / IPP.
   - The PrintGo Agent is currently not monitoring these network endpoints because it was registered against the offline USB queues.
3. **Agent Multi-Device Synchronization Gap:**
   - The backend does not push a live fleet update to the agent when printers are approved.
   - The agent requires a restart or reconnection to fetch the updated `PrinterDevice` list from the staging backend.
4. **Stale Port Binding for Canon Copy 1:**
   - Spooler queue `Canon Generic Plus UFR II (Copy 1)` is pointing to `192.168.1.6` (an IoT module), while the actual Canon printer is located at `192.168.1.3`.

---

## 7. REMEDIATION OPTIONS

### Option A: Physical USB Reconnection (Zero Configuration Change)
- **Action:** Plug in the physical USB cables for the Epson L6460, HP M1136, and Canon printers into the Windows PC (or power them on if connected via a powered USB hub).
- **Result:** Windows PnP will transition devices from `CM_PROB_PHANTOM` to active; `WorkOffline` will clear to `False`; the agent's spooler monitor will detect `isOnline: true` and the dashboard will transition to `READY`.

### Option B: Transition PrintGo to the Networked Printers (Recommended for Reliability)
- **Action:**
  1. Add / map the live networked printer queues in Windows Spooler:
     - Epson L6460: Bind queue to `EPE52365:L6460 SERIES` or Standard TCP/IP Port `192.168.1.7` (Port 9100 RAW).
     - Canon iR-ADV 4545: Use existing queue `Canon iR-ADV 4545` (Port: `WSD-45aba35d-ee5d-435f-9b20-2e3cd045e937` or Standard TCP/IP Port `192.168.1.3`).
  2. Approve the active network queues in PrintGo Staging Admin.
  3. Signal or restart the PrintGo Agent so it initializes multi-device monitoring across the active network printers.

### Option C: Backend Live Agent Fleet Synchronization (Code Improvement)
- **Action:** In `backend/src/modules/admin/printerDiscovery.admin.controller.js` and `backend/src/services/websocket.service.js`, emit a `FLEET_DEVICES_UPDATED` event to the connected machine's WebSocket session whenever an approval or modification occurs, triggering the agent to refresh its monitors dynamically without requiring an agent restart.

---

## 8. STRICT COMPLIANCE & SAFETY VERIFICATION

- [x] Strictly read-only audit completed across Windows PnP, Spooler, WMI, Registry, and Subnet.
- [x] Zero changes made to printer ports, drivers, queues, or spooler services.
- [x] PrintGo Agent (PID 516) was NOT restarted or killed.
- [x] Zero physical test prints dispatched.
- [x] Zero code commits or staging/production deployments performed.
- [x] Full deliverable report generated and saved.
