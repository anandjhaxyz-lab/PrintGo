# PRINTGO FLEET NETWORK ONBOARDING & REAL-TIME WEBSOCKET SYNCHRONIZATION
## READ-ONLY IMPLEMENTATION PLAN & ARCHITECTURAL REVIEW

**Project:** PrintGo Multi-Printer Fleet Management  
**Candidate Workspace:** `D:\PrintGo-S3K-MULTIPRINTER-CANDIDATE`  
**Target Branch:** `feature/printgo-production-readiness`  
**Execution Mode:** STRICTLY READ-ONLY PLANNING & AUDIT (No modifications executed)  
**Host Machine:** `DESKTOP-QB6Q3BC` (`192.168.1.10`)  
**PrintGo Machine ID:** `d010496f-f176-41fe-9c98-efd2213a4a0e` (`Main Shop Printer`)  
**Date/Timestamp:** 2026-11-24T13:11:00+05:30  

---

## 1. EXECUTIVE SUMMARY

The previous diagnostic confirmed that while PrintGo's registered USB queues are currently bound to phantom/unplugged USB ports (`USB019`, `USB011`, `USB001`), the shop's physical hardware fleet is actively online and listening over the local network:
1. **EPSON L6460 Series** is **ONLINE** on Wi-Fi/Ethernet at **`192.168.1.7`** (RAW 9100, IPP 631, LPR 515, EWS 80/443).
2. **Canon imageRUNNER ADVANCE 4545** is **ONLINE** on Ethernet at **`192.168.1.3`** (RAW 9100, LPR 515, WSD 80, Remote UI 8000).

Furthermore, the telemetry status reported `PRINTER DISCONNECTED` on the Admin UI because of an **architectural synchronization gap**:
- When an administrator approves discovered printers in the Admin Dashboard, the backend mutates database records in PostgreSQL (`PrinterDevice`), but **does not emit any WebSocket synchronization event** to the connected Printer Agent.
- The Agent continues running with its initial boot-time configuration (`monitors.size === 0`), falling back to single-printer monitoring on `PRINTER_NAME` (`EPSON L6460 Series` on `USB019`), which reported offline due to the unplugged USB cable.

This document specifies the exact, strictly validated implementation plan for:
- **Option B:** Network Queue Onboarding for the Epson L6460 and Canon 4545 without disrupting customer QR codes or machine identities.
- **Option C:** Real-time WebSocket fleet synchronization push (`pushPrinterDeviceRegistrySync`) eliminating the need for agent restarts.

---

## 2. TASK 1: WINDOWS NETWORK QUEUE & PORT AUDIT

### 2.1 Canon imageRUNNER ADVANCE 4545
* **Windows Queue Name:** `iR-ADV 4545`
* **Driver Name:** `Canon Generic Plus UFR II`
* **Port Name:** `WSD-45aba35d-ee5d-435f-9b20-2e3cd045e937`
* **Target Hardware Location:** `http://192.168.1.3:80/wsd/mex`
* **Physical Device MAC:** `F8-0D-60-9A-5C-DC` (Canon Inc.)
* **Current Spooler State:**
  - `PrinterStatus`: `3` (`Normal` / Ready)
  - `WorkOffline`: `False`
  - `DetectedErrorState`: `0` (`No Error`)
  - `JobCount`: `0`
* **Assessment:** The queue `iR-ADV 4545` is completely healthy, verified over WSD to `192.168.1.3`, and immediately capable of accepting print jobs.

### 2.2 Epson L6460 Series
* **Windows Queue Name:** `EPSON L6460 Series`
* **Driver Name:** `EPSON L6460 Series`
* **Current Port Name:** `USB019` (ConfigManager status: `CM_PROB_PHANTOM`)
* **Physical Device IP:** `192.168.1.7` (MAC: `64-C6-D2-E5-23-65`, Seiko Epson Corp.)
* **Existing Network Ports in Spooler:**
  - `EPE52365:L6460 SERIES` (Pre-existing EpsonNet Print Port matching MAC suffix `E52365`)
  - Standard TCP/IP Port can also be bound to `192.168.1.7` (Port 9100 RAW)
* **Assessment:** The physical Epson printer is online at `192.168.1.7`. The Windows queue is currently assigned to virtual USB port `USB019`.

---

## 3. TASK 3: CANON QUEUE MISMATCH ON 192.168.1.6

### 3.1 Forensic Analysis
* **Windows Queue Name:** `Canon Generic Plus UFR II (Copy 1)`
* **Configured Port:** `192.168.1.6` (Standard TCP/IP Port, Port 9100)
* **Current Status:** `Error` (`PrinterStatus: 1`, `DetectedErrorState: 1`, `JobCount: 1`)
* **Hardware at `192.168.1.6`:**
  - MAC Address: `AC-F4-2C-AD-61-D5`
  - OUI: **Earda Technologies Co.,Ltd**
  - Open Ports: Ping succeeds, but ports `9100`, `515`, `631`, `80`, `443`, `5357` are all **CLOSED**.
  - Device Classification: **IoT Smart Module / Wi-Fi Controller (NOT a printer)**.

### 3.2 Root Cause
A legacy Standard TCP/IP port `192.168.1.6` was created when the Canon printer previously occupied that dynamic DHCP lease or via manual input error. When the DHCP lease migrated the Canon to `192.168.1.3`, an IoT device acquired `192.168.1.6`. A subsequent print attempt to `Copy 1` failed and remains stuck in the Windows Print Spooler (`JobCount: 1`), keeping `Copy 1` permanently in an error state.

### 3.3 Safe Remediation Recommendation
1. In PrintGo Staging: Do **not** approve `Canon Generic Plus UFR II (Copy 1)`.
2. On Windows Host (when authorized): Cancel the single stuck print job on `Copy 1` via `Remove-PrintJob` and deprecate or remove the mismatched queue to prevent operator confusion.

---

## 4. TASK 2 & TASK 4: SAFE REAL-TIME FLEET SYNCHRONIZATION DESIGN (OPTION C)

### 4.1 The Existing Gap
```
[Admin Clicks "Approve" in UI]
             │
             ▼
[POST /api/admin/printer-discovery/:id/approve]
             │
             ▼
[approvePrinterDiscovery updates DB (PrinterDevice)]
             │
             ▼ (Response sent: 201 Created)
       ───► [NO WEBSOCKET EVENT EMITTED] ◄───
             │
[Running Agent PID 516 continues with empty fleet monitors]
             │
[Fallback spoolerMonitor checks PRINTER_NAME (USB019)]
             │
[USB019 Offline -> Backend availability returns 'PRINTER_DISCONNECTED']
```

### 4.2 Architecture of the Real-Time Event Push
The Printer Agent codebase (`printer-agent/index.js` lines 237–314) **already has** a robust, fully implemented listener for the event:
```javascript
socket.on('printer_device_registry', async (payload) => { ... });
```
When this event arrives, the Agent:
1. Validates the payload timestamp (`issuedAt`) against replay.
2. Validates the device records using `validatePrinterDeviceRegistry`.
3. Runs `discoverWindowsPrinters({ execFile })`.
4. Instantiates `PrinterFleetManager` with independent `SpoolerMonitor` instances for each approved queue.
5. Replaces in-memory monitors and starts sending per-device telemetry (`printer_device_status_update`).

**Conclusion:** The Printer Agent requires **ZERO CODE CHANGES**! It is already engineered to dynamically hot-reload its fleet upon receiving `printer_device_registry`.

### 4.3 Backend Synchronization Flow
```
[Admin Approval / Disable / Enable / Remap]
                   │
                   ▼
[DB Transaction Commits in PostgreSQL]
                   │
                   ▼
[pushPrinterDeviceRegistrySync(io, prisma, machineId, logger)]
                   │
                   ▼
[io.to(`machine_${machineId}`).emit('printer_device_registry', {
    protocolVersion: 1,
    machineId,
    issuedAt: new Date().toISOString(),
    devices: [...]
})]
                   │
                   ▼ (Instant WebSocket Delivery < 50ms)
[Running Agent hot-reloads monitors in memory — NO RESTART NEEDED]
```

---

## 5. TASK 5: EXACT FILES, FUNCTIONS, DATABASE & TEST PLAN

### 5.1 Exact Files to be Modified / Created

| Component | File Path | Nature of Change |
| :--- | :--- | :--- |
| **Backend Service** | `backend/src/services/printerAgentProtocol.service.js` | Export new helper `pushPrinterDeviceRegistrySync` |
| **Backend Controller** | `backend/src/modules/admin/printerDiscovery.admin.controller.js` | Call `pushPrinterDeviceRegistrySync` in `approvePrinterDiscovery`, `disablePrinterDevice`, `enablePrinterDevice`, `remapPrinterDevice` |
| **Backend Tests** | `backend/tests/printer_agent_protocol.test.js` | Add unit tests verifying `pushPrinterDeviceRegistrySync` behavior |
| **Agent** | *(No files modified)* | Existing agent logic in `printer-agent/index.js` already handles `printer_device_registry` |

---

### 5.2 Exact Code Implementations

#### File 1: `backend/src/services/printerAgentProtocol.service.js`
Add and export function:
```javascript
/**
 * Pushes the latest authenticated PrinterDevice registry to an active Agent session
 * via WebSocket, triggering an immediate in-memory fleet monitor synchronization.
 *
 * @param {object} io - Socket.IO server instance
 * @param {object} prisma - Prisma client instance
 * @param {string} machineId - Target Machine UUID
 * @param {object} [logger] - Optional logger instance
 * @returns {Promise<boolean>} True if event was emitted, false if skipped or failed
 */
async function pushPrinterDeviceRegistrySync(io, prisma, machineId, logger = null) {
  if (!io || !machineId) return false;

  try {
    const devices = await getPrinterDeviceRegistry(prisma, machineId);
    const payload = {
      protocolVersion: AGENT_PROTOCOL_VERSION,
      machineId,
      issuedAt: new Date().toISOString(),
      devices
    };

    io.to(`machine_${machineId}`).emit('printer_device_registry', payload);
    logger?.info?.(`[FleetSync] Emitted printer_device_registry to machine_${machineId} (${devices.length} approved devices)`);
    return true;
  } catch (error) {
    logger?.error?.(`[FleetSync] Failed to push printer_device_registry to machine_${machineId}:`, error.message);
    return false;
  }
}
```
Update `module.exports`:
```javascript
module.exports = {
  AGENT_PROTOCOL_VERSION,
  MAX_REGISTERED_PRINTERS,
  MAX_DISCOVERED_QUEUES,
  PrinterAgentProtocolError,
  validateAgentHello,
  getPrinterDeviceRegistry,
  validateDiscoveredPrinterInventory,
  handlePrinterAgentHello,
  handlePrinterDeviceRegistryRequest,
  handlePrinterInventoryReport,
  handlePrinterDeviceTelemetry,
  pushPrinterDeviceRegistrySync
};
```

---

#### File 2: `backend/src/modules/admin/printerDiscovery.admin.controller.js`
Import `pushPrinterDeviceRegistrySync`:
```javascript
const { pushPrinterDeviceRegistrySync } = require('../../services/printerAgentProtocol.service');
```

Update `approvePrinterDiscovery`:
```javascript
const approvePrinterDiscovery = async (req, res, next) => {
  try {
    const isStagingApprovalsEnabled = process.env.STAGING_PRINTER_APPROVALS_ENABLED === 'true' ||
                                     process.env.ALLOW_STAGING_PRINTER_APPROVALS === 'true';
    if (isStagingApprovalsEnabled && req.body?.isDefault !== false) {
      return res.status(400).json({
        success: false,
        error: 'Approval request must explicitly contain isDefault: false.'
      });
    }

    const result = await printerDiscoveryService.approvePrinterDiscovery(
      req.params.id, req.body || {}, req.user, prisma
    );

    // Real-time fleet synchronization push to active agent
    const io = req.app.get('io');
    const machineId = result.device?.machineId;
    if (io && machineId) {
      await pushPrinterDeviceRegistrySync(io, prisma, machineId, req.logger);
    }

    res.status(result.alreadyApproved ? 200 : 201).json({
      success: true,
      message: result.alreadyApproved ? 'Printer was already approved.' : 'Printer approved and registered successfully.',
      data: { device: result.device, alreadyApproved: result.alreadyApproved }
    });
  } catch (error) {
    next(error);
  }
};
```
Apply the identical non-blocking push pattern in `disablePrinterDevice`, `enablePrinterDevice`, and `remapPrinterDevice`.

---

### 5.3 Database Implications & Schema Migrations
* **Schema Modifications:** **ZERO**. No database migrations (`prisma migrate` / `prisma db push`) are required.
* **Tables Read/Written:**
  - `PrinterDevice`: Read via existing query in `getPrinterDeviceRegistry(prisma, machineId)`.
  - `Machine`: Read-only relationship lookup.
  - `ActivityLog`: Unchanged.
* **Concurrency & Locking:** Existing transactional locks (`SELECT ... FOR UPDATE`) in `printerDiscovery.service.js` remain completely untouched. The WebSocket push occurs *after* the transaction successfully commits.

---

### 5.4 Configuration & Environment Variables
* `ADMIN_READ_ONLY=true`: Preserved.
* `STAGING_PRINTER_APPROVALS_ENABLED=true`: Preserved.
* `ENABLE_MULTI_PRINTER_DISPATCH`: Staging flag preserved (defaults to `false` until Phase 4 activation).
* Zero new environment variables required.

---

### 5.5 Rollback Plan
If any anomaly occurs during integration:
1. **Git Revert:** The changes are isolated to `printerAgentProtocol.service.js` and `printerDiscovery.admin.controller.js`.
   ```powershell
   git checkout origin/feature/printgo-production-readiness -- backend/src/services/printerAgentProtocol.service.js backend/src/modules/admin/printerDiscovery.admin.controller.js
   ```
2. **Behavioral Rollback:** The controller falls back to database-only mutations; the agent falls back to connect-time hello registry synchronization.

---

### 5.6 Test & Verification Plan
1. **Unit Test Suite:**
   - Execute Jest test verifying `pushPrinterDeviceRegistrySync`:
     - Test A: Emits `printer_device_registry` payload matching `AGENT_PROTOCOL_VERSION` and `issuedAt`.
     - Test B: Gracefully handles null `io` or missing `machineId` without throwing.
     - Test C: Controller returns HTTP 201 even if `pushPrinterDeviceRegistrySync` encounters a socket error.
2. **Regression Gate:**
   - Run the full suite of 180 backend tests to confirm zero regressions.
3. **End-to-End Fleet Verification (Staging):**
   - Connect Agent.
   - Trigger approval for `iR-ADV 4545`.
   - Observe Agent log: verifies reception of `printer_device_registry` and dynamic monitor initialization without process restart.

---

## 6. TASK 6: CUSTOMER QR MAPPING & PRODUCTION SAFETY

### 6.1 Customer QR Protection Guarantee
1. **Machine-Level QR:** Customers scanning the physical kiosk/counter QR code target `MachineQr` (`/p/<publicCode>`).
   - The PrintGo routing engine routes legacy `MachineQr` jobs to the device marked `isDefault: true`.
   - The `isDefault: true` device remains `EPSON L6460 Series`.
   - When the Epson queue port is migrated from `USB019` to `EPE52365` or Standard TCP/IP `192.168.1.7`:
     - Queue name remains `EPSON L6460 Series`.
     - Device ID and QR mapping remain **100% unchanged**.
     - Customer print jobs immediately succeed over the network!
2. **Secondary Printers:**
   - `Canon iR-ADV 4545` is onboarded as `isDefault: false`.
   - It is available for multi-printer dispatch (Phase 4) without altering the default counter printing flow.

### 6.2 Machine Identity Protection
- `machineKey` in `.env` is unchanged.
- Machine UUID `d010496f-f176-41fe-9c98-efd2213a4a0e` is unchanged.
- Production database and environment remain untouched.

---

## 7. RECOMMENDED STEP-BY-STEP EXECUTION SEQUENCE

Upon explicit user authorization, the execution will proceed in 3 disciplined phases:

```
+─────────────────────────────────────────────────────────────────────────────+
| PHASE 1: CODE IMPLEMENTATION (OPTION C)                                     |
| 1. Implement pushPrinterDeviceRegistrySync in printerAgentProtocol.service.js|
| 2. Wire push calls into printerDiscovery.admin.controller.js                |
| 3. Add unit test suite in backend/tests/                                     |
| 4. Run all 180 regression tests to ensure 100% pass                          |
+─────────────────────────────────────────────────────────────────────────────+
                                      │
                                      ▼
+─────────────────────────────────────────────────────────────────────────────+
| PHASE 2: WINDOWS QUEUE REMAPPING & RESOLUTION (OPTION B)                    |
| 1. Switch Windows queue "EPSON L6460 Series" port from USB019 to             |
|    network port (EPE52365:L6460 SERIES or 192.168.1.7).                     |
| 2. Purge stuck job on "Canon Generic Plus UFR II (Copy 1)" and deprecate.   |
| 3. Verify queue "iR-ADV 4545" is ready on WSD / 192.168.1.3.               |
+─────────────────────────────────────────────────────────────────────────────+
                                      │
                                      ▼
+─────────────────────────────────────────────────────────────────────────────+
| PHASE 3: VERIFICATION & STAGING FLEET ACTIVATION                           |
| 1. Start Agent PID.                                                         |
| 2. Approve "iR-ADV 4545" in Staging Admin UI.                               |
| 3. Confirm Agent receives instant WebSocket sync and starts dual monitors.   |
| 4. Confirm Admin Dashboard reflects "READY" state across fleet.              |
+─────────────────────────────────────────────────────────────────────────────+
```

---

## 8. STRICT SAFETY & RESTRICTIONS COMPLIANCE CHECKLIST

- [x] **No files modified during this session**
- [x] **No printer ports or drivers changed**
- [x] **PrintGo Agent & Windows Spooler left untouched**
- [x] **Database records and approvals unmodified**
- [x] **Zero physical test prints sent**
- [x] **Zero code committed or deployed**
- [x] **Plan stopped and awaiting explicit user authorization**
