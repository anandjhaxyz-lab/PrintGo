'use strict';

const {
  getDatabaseGuardPolicy,
  assertDatabaseIdentity,
  shouldAutoSeed
} = require('../src/utils/startupSafety');

describe('staging startup safety', () => {
  const stagingEnv = {
    NODE_ENV: 'staging',
    DATABASE_URL: 'postgresql://printgo_app:unit-test-password@127.0.0.1:5432/printgo_staging?schema=public'
  };

  test('staging policy pins localhost PostgreSQL 16 staging database and app role', () => {
    expect(getDatabaseGuardPolicy(stagingEnv)).toMatchObject({
      enforced: true,
      environment: 'staging',
      database: 'printgo_staging',
      port: 5432,
      username: 'printgo_app'
    });
  });

  test('accepts only the exact staging identity', () => {
    expect(assertDatabaseIdentity({
      env: stagingEnv,
      databaseName: 'printgo_staging',
      serverPort: 5432
    })).toMatchObject({
      enforced: true,
      database: 'printgo_staging',
      port: 5432,
      host: '127.0.0.1',
      username: 'printgo_app'
    });
  });

  test.each([
    ['wrong actual database', 'printgo_dev', 5432, stagingEnv.DATABASE_URL],
    ['wrong actual port', 'printgo_staging', 5433, stagingEnv.DATABASE_URL],
    ['wrong URL database', 'printgo_staging', 5432, 'postgresql://printgo_app:x@127.0.0.1:5432/printgo_dev'],
    ['wrong URL port', 'printgo_staging', 5432, 'postgresql://printgo_app:x@127.0.0.1:5433/printgo_staging'],
    ['remote URL host', 'printgo_staging', 5432, 'postgresql://printgo_app:x@db.example.com:5432/printgo_staging'],
    ['wrong URL username', 'printgo_staging', 5432, 'postgresql://postgres:x@127.0.0.1:5432/printgo_staging'],
    ['non-PostgreSQL URL scheme', 'printgo_staging', 5432, 'http://printgo_app:x@127.0.0.1:5432/printgo_staging'],
    ['extra URL path segment', 'printgo_staging', 5432, 'postgresql://printgo_app:x@127.0.0.1:5432/printgo_staging/extra'],
    ['missing URL', 'printgo_staging', 5432, undefined]
  ])('rejects %s', (_label, databaseName, serverPort, databaseUrl) => {
    const env = { NODE_ENV: 'staging' };
    if (databaseUrl !== undefined) env.DATABASE_URL = databaseUrl;
    expect(() => assertDatabaseIdentity({ env, databaseName, serverPort }))
      .toThrow('[DATABASE SAFETY GUARD] FATAL');
  });

  test('disables automatic seed in staging', () => {
    expect(shouldAutoSeed(stagingEnv)).toBe(false);
  });

  test('preserves automatic seed behavior outside staging', () => {
    expect(shouldAutoSeed({ NODE_ENV: 'development' })).toBe(true);
    expect(shouldAutoSeed({ NODE_ENV: 'production' })).toBe(true);
  });

  test('preserves the existing local disposable database guard', () => {
    const env = {
      NODE_ENV: 'development',
      DATABASE_URL: 'postgresql://dev_user:x@localhost:5433/printgo_disposable_target'
    };
    expect(assertDatabaseIdentity({
      env,
      databaseName: 'printgo_disposable_target',
      serverPort: 5433
    })).toMatchObject({ enforced: true, database: 'printgo_disposable_target', port: 5433 });
  });

  test('production policy remains unchanged and unenforced by this local guard', () => {
    expect(assertDatabaseIdentity({
      env: { NODE_ENV: 'production' },
      databaseName: 'cloud_database',
      serverPort: 5432
    })).toMatchObject({ enforced: false, environment: 'production' });
  });
});
