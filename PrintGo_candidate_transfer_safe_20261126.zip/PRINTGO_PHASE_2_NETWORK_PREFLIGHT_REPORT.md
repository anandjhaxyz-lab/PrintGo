# PRINTGO PHASE 2 — NETWORK PRINTER ONBOARDING PREFLIGHT REPORT

**Workspace:** `D:\PrintGo-S3K-MULTIPRINTER-CANDIDATE`  
**Host:** `DESKTOP-QB6Q3BC` (`192.168.1.10`)  
**PrintGo Machine:** `Main Shop Printer` (`d010496f-f176-41fe-9c98-efd2213a4a0e`)  
**Execution Mode:** STRICTLY READ-ONLY AUDIT & PREFLIGHT VERIFICATION  
**Date/Timestamp:** 2026-11-24T13:43:15+05:30  

---

## 1. EXECUTIVE SUMMARY

Following the successful implementation and verification of Phase 1 (real-time WebSocket fleet synchronization), this preflight audit prepares the candidate environment for **Phase 2: Network Printer Onboarding**.

### Key Discoveries & Verifications:
1. **Network Connectivity & Protocol Audit:**
   - **Epson L6460 (`192.168.1.7`):** Ping reachable. Port 9100 (RAW JetDirect), Port 631 (IPP), Port 515 (LPR), Port 80/443 (HTTP/HTTPS EWS) are all **OPEN**.
   - **Canon iR-ADV 4545 (`192.168.1.3`):** Ping reachable. Port 9100 (RAW JetDirect), Port 515 (LPR), Port 8000 (Canon Remote UI / Auth), Port 80/443 (HTTP/HTTPS WSD) are all **OPEN**.
2. **Critical Discovery on EpsonNet Port `EPE52365:L6460 SERIES`:**
   - Registry inspection of `HKLM:\SYSTEM\CurrentControlSet\Control\Print\Monitors\EpsonNet Print Port\Ports\EPE52365:L6460 SERIES` reveals that its cached IP address is **`192.168.1.4`** (a dead/expired DHCP lease).
   - If the Windows queue `EPSON L6460 Series` were pointed to `EPE52365`, print jobs would stall trying to reach `192.168.1.4`.
   - **Architecture Fix:** Creating a clean, standard Windows TCP/IP port `192.168.1.7` (Port 9100 RAW) completely bypasses proprietary EpsonNet resolution bugs, uses native Windows `tcpmon.dll`, and aligns perfectly with the Agent's `classifyConnection()` regex (`'Network'`).
3. **Canon WSD Endpoint Audit:**
   - The Windows queue `iR-ADV 4545` is bound to `WSD-45aba35d-ee5d-435f-9b20-2e3cd045e937`.
   - Registry `DAFWSDProvider` confirms active hardware endpoint: `http://192.168.1.3:80/wsd/mex` (`Mfg: Canon`, `FriendlyName: iR-ADV 4545`).
   - The queue is healthy (`PrinterStatus: Normal`, `WorkOffline: False`, `JobCount: 0`).
4. **Spooler Queue State:**
   - Target queue `EPSON L6460 Series`: **0 pending jobs (Clean)**.
   - Target queue `iR-ADV 4545`: **0 pending jobs (Clean)**.
   - Stale queue `Canon Generic Plus UFR II (Copy 1)`: Contains 1 stuck job (ID 15, `JobStatus: Spooling/Error`) attempting to reach `192.168.1.6` (IoT device).
5. **Customer QR & Machine Identity Guarantee:**
   - Machine ID `d010496f-f176-41fe-9c98-efd2213a4a0e` is unchanged.
   - Default device `EPSON L6460 Series` remains `isDefault: true`.
   - Customer public QR code mapping is 100% preserved because the queue name and default routing do not change.

---

## 2. BEFORE-STATE SNAPSHOT

### 2.1 Windows Print Queues

| Queue Name | Driver | Current Port | Spooler Status | Work Offline | Pending Jobs | Physical State |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **`EPSON L6460 Series`** *(Default)* | EPSON L6460 Series | `USB019` | Normal | False* | **0** | USB Disconnected (`CM_PROB_PHANTOM`) |
| **`iR-ADV 4545`** | Canon Generic Plus UFR II | `WSD-45aba35d-...` | Normal | False | **0** | **Network Online (`192.168.1.3`)** |
| `Canon Generic Plus UFR II (Copy 1)` | Canon Generic Plus UFR II | `192.168.1.6` | Error | False | **1 (Stuck)** | Points to IoT device |
| `Canon Generic Plus UFR II (Copy 2)` | Canon Generic Plus UFR II | `USB001` | Normal | False | 0 | USB Disconnected (`CM_PROB_PHANTOM`) |
| `HP LaserJet Professional M1136 MFP (Copy 1)` | HP LaserJet M1136 | `USB011` | Normal | False | 0 | USB Disconnected (`CM_PROB_PHANTOM`) |

*\*Note: `WorkOffline` reports false in current WMI cache, but physical USB hardware is detached.*

---

### 2.2 PrintGo Staging Database Fleet State

| Device Display Name | Windows Queue Name | Database ID | Role | Staging Status |
| :--- | :--- | :--- | :--- | :--- |
| **Epson L6460 Series** | `EPSON L6460 Series` | `5c34515a-4933-4f91-ba1b-90e6ea1641b0` | **Default (`isDefault: true`)** | `ACTIVE` |
| **HP LaserJet M1136 (Copy 1)** | `HP LaserJet Professional M1136 MFP (Copy 1)` | `a82a0d06-92f7-4180-8772-e19f70d4949b` | Secondary (`isDefault: false`) | `ACTIVE` |
| **Canon UFR II (Copy 2)** | `Canon Generic Plus UFR II (Copy 2)` | `2709151e-627c-4731-9cb0-b3eec68bda32` | Secondary (`isDefault: false`) | `ACTIVE` |

---

## 3. VERIFIED PRINTER-TO-IP & PROTOCOL MAPPING

```
                                [ Local Shop Subnet: 192.168.1.0/24 ]
                                                  │
                 ┌────────────────────────────────┴────────────────────────────────┐
                 │                                                                 │
                 ▼                                                                 ▼
      [ EPSON L6460 Series ]                                            [ Canon iR-ADV 4545 ]
      IP: 192.168.1.7                                                   IP: 192.168.1.3
      MAC: 64-C6-D2-E5-23-65                                            MAC: F8-0D-60-9A-5C-DC
      Protocols Verified:                                               Protocols Verified:
      - RAW: 9100/TCP (OPEN)                                            - RAW: 9100/TCP (OPEN)
      - IPP: 631/TCP (OPEN)                                             - LPR: 515/TCP (OPEN)
      - LPR: 515/TCP (OPEN)                                             - WSD: 80/TCP (OPEN)
      - EWS: 80/443/TCP (OPEN)                                          - Remote UI: 8000/TCP (OPEN)
      Windows Spooler Mapping:                                          Windows Spooler Mapping:
      - Target Port: 192.168.1.7:9100                                   - Active Port: WSD-45aba35d-...
```

---

## 4. DETAILED MIGRATION & ONBOARDING PLANS

### 4.1 Epson L6460 Network Migration Plan (Queue `EPSON L6460 Series`)

#### Strategy:
- **Zero Queue Renaming:** Retain exact queue name `EPSON L6460 Series`.
- **Zero Database Modification:** The `PrinterDevice` row `5c34515a-4933-4f91-ba1b-90e6ea1641b0` remains `isDefault: true`, `status: ACTIVE`, and mapped to `EPSON L6460 Series`.
- **Port Re-binding:** Migrate queue port from phantom `USB019` to Standard TCP/IP Port `192.168.1.7`.

#### Exact PowerShell Execution Commands (Awaiting Approval):
```powershell
# 1. Create native Windows Standard TCP/IP Port for 192.168.1.7
Add-PrinterPort -Name "192.168.1.7" -PrinterHostAddress "192.168.1.7" -PortNumber 9100

# 2. Re-bind EPSON L6460 Series to the new network port
Set-Printer -Name "EPSON L6460 Series" -PortName "192.168.1.7"

# 3. Verify queue port binding
Get-Printer -Name "EPSON L6460 Series" | Select-Object Name, PortName, PrinterStatus
```

---

### 4.2 Canon iR-ADV 4545 Onboarding Plan (Queue `iR-ADV 4545`)

#### Strategy:
- **Queue Already Established:** Windows queue `iR-ADV 4545` is already installed, active on WSD (`192.168.1.3:80/wsd/mex`), and reports `PrinterStatus: Normal`.
- **PrintGo Approval:**
  - Upon Agent connection, `iR-ADV 4545` is reported via `printer_inventory_report` under `PrinterDiscovery`.
  - In Admin Dashboard, approve `iR-ADV 4545` with **`isDefault: false`**.
  - Phase 1 real-time sync automatically triggers `pushPrinterDeviceRegistrySync`, prompting the Agent to create a secondary monitor for `iR-ADV 4545` in memory without restarting.

---

### 4.3 Stale Queue Resolution (`Canon Copy 1` on `192.168.1.6`)

#### Strategy:
- Purge stuck print job `15` to clear the spooler error state.
- Leave queue `Canon Generic Plus UFR II (Copy 1)` unapproved in PrintGo.

#### Exact PowerShell Command (Awaiting Approval):
```powershell
Remove-PrintJob -PrinterName "Canon Generic Plus UFR II (Copy 1)" -ID 15
```

---

## 5. CUSTOMER QR CODE & ROUTING SAFETY VERIFICATION

### 5.1 Legacy / Machine QR Routing Guarantee
```
[Customer Scans Counter QR: /p/<publicCode>]
                     │
                     ▼
[Backend Resolves Session -> Machine: d010496f-f176-41fe-9c98-efd2213a4a0e]
                     │
                     ▼
[Routes to default PrinterDevice: isDefault === true]
                     │
                     ▼
[Default Device: EPSON L6460 Series (ID: 5c34515a-4933-4f91-ba1b-90e6ea1641b0)]
                     │
                     ▼
[Agent dispatches to Windows Queue "EPSON L6460 Series"]
                     │
                     ▼ (Network Port 192.168.1.7:9100)
[Physical Epson L6460 prints document over LAN]
```

### Safety Confirmations:
1. `MachineQr` records in PostgreSQL are **not modified**.
2. Public QR URL `/p/<publicCode>` remains identical.
3. Queue name `EPSON L6460 Series` remains identical.
4. Default printer assignment remains `EPSON L6460 Series`.
5. Customer scanning experience is 100% uninterrupted.

---

## 6. EXACT ROLLBACK PROCEDURES

If any unexpected behavior occurs after changing the port:

### Epson L6460 Rollback:
```powershell
# Revert queue port back to USB019
Set-Printer -Name "EPSON L6460 Series" -PortName "USB019"

# Remove temporary TCP/IP port if desired
Remove-PrinterPort -Name "192.168.1.7" -ErrorAction SilentlyContinue
```

### Canon iR-ADV 4545 Rollback:
```
Call Admin API to disable the device:
POST /api/admin/printer-devices/<canonDeviceId>/disable
Payload: { "reason": "Operator initiated rollback to preflight state" }
```

---

## 7. RISK ASSESSMENT & RECOMMENDED MAINTENANCE WINDOW

| Category | Assessment | Detail |
| :--- | :--- | :--- |
| **Customer Impact** | **ZERO DOWNTIME / POSITIVE** | Queue `EPSON L6460 Series` currently has 0 jobs and is physically disconnected on USB. Switching to `192.168.1.7` restores printing capability over LAN immediately. |
| **Spooler Impact** | **NEGLIGIBLE** | Port re-binding takes < 200ms in Windows Print Spooler. Spooler restart is NOT required. |
| **Duration** | **< 60 seconds** | Execution consists of two PowerShell cmdlets. |
| **Recommended Window** | **Immediate or before shop opening** | Can be executed immediately or during normal shop operating hours without interrupting active prints. |

---

## 8. REQUIRED APPROVALS BEFORE EXECUTION

Before executing Phase 2, the user must explicitly authorize:
1. Creating Windows Standard TCP/IP Port `192.168.1.7`.
2. Re-binding Windows queue `EPSON L6460 Series` to port `192.168.1.7`.
3. Canceling stuck print job 15 on `Canon Generic Plus UFR II (Copy 1)`.
4. Approving `iR-ADV 4545` with `isDefault: false` in Staging Admin.

---

## 9. STRICT RESTRICTIONS VERIFICATION

- [x] **No printer ports or queues modified**
- [x] **Default printer unchanged**
- [x] **No stuck print jobs removed**
- [x] **No database records or approvals altered**
- [x] **PrintGo Agent & Windows Spooler left untouched**
- [x] **Zero physical test prints sent**
- [x] **Zero commits, pushes or deployments performed**
- [x] **Execution stopped and awaiting explicit user authorization**
