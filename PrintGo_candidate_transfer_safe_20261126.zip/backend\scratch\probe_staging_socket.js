const { io } = require('D:/PrintGo-S3K-MULTIPRINTER-CANDIDATE/printer-agent/node_modules/socket.io-client');
const { buildAgentHello } = require('D:/PrintGo-S3K-MULTIPRINTER-CANDIDATE/printer-agent/src/agentProtocol');
const fs = require('fs');

const envPath = 'D:/PrintGo-S3K-MULTIPRINTER-CANDIDATE/printer-agent/.env';
const envContent = fs.readFileSync(envPath, 'utf8');
let machineKey = '';
let backendUrl = 'https://printgo-backend-staging.onrender.com';

envContent.split('\n').forEach(line => {
  const [k, v] = line.split('=', 2);
  if (k && k.trim() === 'MACHINE_KEY') machineKey = v.trim();
  if (k && k.trim() === 'BACKEND_URL') backendUrl = v.trim();
});

console.log('Connecting to:', backendUrl);
const socket = io(backendUrl, {
  transports: ['websocket'],
  auth: { machineKey }
});

socket.on('connect', () => {
  console.log('SOCKET_CONNECTED, id:', socket.id);
  const helloPayload = buildAgentHello({
    agentVersion: '1.0.0',
    markerPath: 'D:/PrintGo-S3K-MULTIPRINTER-CANDIDATE/printer-agent/journal.marker',
    journalSchemaVersion: 2
  });

  socket.emit('printer_agent_hello', helloPayload);
});

socket.on('printer_registered_success', (data) => {
  console.log('MACHINE_REGISTERED:', data.machineId, data.name);
});

socket.on('printer_agent_hello_ack', (ack) => {
  console.log('HELLO_ACK:', JSON.stringify(ack));
  if (ack.accepted && ack.supportsMultiPrinter) {
    socket.emit('printer_device_registry_request', { requestId: 'req_phase13_probe' });
  }
});

socket.on('printer_device_registry', (payload) => {
  console.log('--- STAGING REGISTERED PRINTER DEVICES ---');
  console.log(JSON.stringify(payload, null, 2));
  socket.disconnect();
  process.exit(0);
});

socket.on('printer_device_registry_error', (err) => {
  console.error('REGISTRY_ERROR:', JSON.stringify(err));
  socket.disconnect();
  process.exit(1);
});

setTimeout(() => {
  console.log('TIMEOUT');
  socket.disconnect();
  process.exit(0);
}, 10000);
