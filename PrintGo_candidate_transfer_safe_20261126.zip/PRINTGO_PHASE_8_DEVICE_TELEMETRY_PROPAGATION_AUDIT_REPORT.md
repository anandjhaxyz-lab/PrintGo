# PRINTGO — PHASE 8: READ-ONLY DEVICE TELEMETRY PROPAGATION AUDIT REPORT

**Target PC:** `DESKTOP-QB6Q3BC` (`192.168.1.10`)  
**Target Workspace:** `D:\PrintGo-S3K-MULTIPRINTER-CANDIDATE`  
**Backend:** `https://printgo-backend-staging.onrender.com` (Staging)  
**Agent PID:** `10940` (Running, untouched)  
**Machine:** `Main Shop Printer` (`d010496f-f176-41fe-9c98-efd2213a4a0e`)  
**Approved Epson Device ID:** `619665e1-3c64-44eb-8f57-cb8c3c895e9b`  
**Public QR Code:** `pq_YCuM5Lr2_nQMuxahsrBqjb9jWQSUhMDPd0Cbl_tpDB8`  
**Audit Mode:** STRICTLY READ-ONLY (Zero file edits, zero restarts, zero DB mutations)

---

## 1. Executive Summary

In Phase 7, the candidate agent was restarted under PID `10940`. The agent successfully initialized independent monitors for all 3 approved devices, and verified TCP connectivity to the Epson printer at `192.168.1.7:9100`.

However, the public customer QR API (`GET /api/auth/printer-qr/pq_YCuM5Lr2_nQMuxahsrBqjb9jWQSUhMDPd0Cbl_tpDB8`) returned:
- `agentOnline: true`
- `isOnline: false`
- `hardwareStatus: "UNKNOWN"`
- `statusMessage: "Printer Status Unavailable"`
- `lastTelemetryAt: null`
- `deviceHealth: null`
- `printerDeviceId: null`
- `paperStatus: "OK"`
- `tonerStatus: "OK"`

This Phase 8 read-only code audit traced the data flow across the entire pipeline:
`Agent SpoolerMonitor` → `WebSocket (printer_status_update)` → `Backend socket.js` → `printerAgentProtocol.service.js` → `Database (PrinterDevice vs PrinterStatus)` → `printerQr.service.js` → `Customer QR API`.

### Confirmed Findings in Brief:
1. **QR Type Decoupling:** Public QR code `pq_YCuM5Lr2_nQMuxahsrBqjb9jWQSUhMDPd0Cbl_tpDB8` is a **Machine-level counter QR** (`printerDeviceId: null`), NOT a device-specific QR. Consequently, `lastTelemetryAt`, `deviceHealth`, and `printerDeviceId` are intentionally evaluated as `null`.
2. **Intentional Socket Telemetry Split:** When the candidate Agent emits device-tagged telemetry (`status.printerDeviceId = "619665e1..."`), `backend/src/socket.js` routes it to `handlePrinterDeviceTelemetry()` and **immediately returns** (`socket.js:304`). It updates `PrinterDevice.healthStatus = 'ONLINE'` in the database, but **never writes** to the legacy `PrinterStatus` table.
3. **Telemetry Stale Window Expiration:** The legacy `PrinterStatus` table only contains rows written prior to Phase 7. Because no new legacy rows were inserted for >180 seconds, `printerAvailability.service.js` evaluated the machine telemetry as stale (`telemetryDiffMs > 180000`), forcing `hardwareStatus = 'UNKNOWN'` and `isOnline = false`.
4. **Paper/Toner Discrepancy:** The returned `paperStatus: "OK"` and `tonerStatus: "OK"` are read from the old stale row created during Phase 4/5. In that legacy path, `socket.js:329` hardcoded `paperStatus: 'OK'` via a ternary check against `'Out of Paper'`, while `tonerStatus` defaulted to `'OK'` from the Prisma schema definition (`@default("OK")`), completely ignoring the agent's telemetry payload.

---

## 2. End-to-End Code Trace & Architecture Mapping

```
                                      AGENT SIDE (PID 10940)
                                      ----------------------
                                   SpoolerMonitor.checkPrinterStatus()
                                                 │
                                                 ▼
                                     SpoolerMonitor.emitStatus()
                     Emits: 'printer_status_update' with printerDeviceId: "619665e1..."
                     Telemetry payload: { paperStatus: 'UNKNOWN', tonerStatus: 'UNKNOWN' }
                                                 │
                                                 ▼ (WebSocket)
                                      BACKEND (socket.js:299)
                                      -----------------------
                                    socket.on('printer_status_update')
                                                 │
                                     [status.printerDeviceId?]
                                                 │
                        ┌────────────────────────┴────────────────────────┐
                     YES│ (Candidate Agent Path)                       NO │ (Legacy Path)
                        ▼                                                 ▼
        handlePrinterDeviceTelemetry()                       prisma.printerStatus.create()
     (printerAgentProtocol.service.js)                           [SKIPPED COMPLETELY]
                        │                                                 │
                        ▼                                                 ▼
      prisma.printerDevice.update({                          Legacy table row becomes STALE
        healthStatus: 'ONLINE',                                  (> 180s old)
        lastTelemetryAt: now
      });
      RETURN EARLY (Line 304)
                        │
                        ▼
                                   CUSTOMER QR API REQUEST
                                   -----------------------
                        GET /api/auth/printer-qr/pq_YCuM5Lr2_...
                                   (printerQr.service.js)
                                                 │
                                [qr.printerDeviceId exists?]
                                                 │
                        ┌────────────────────────┴────────────────────────┐
                     YES│                                              NO │ (pq_YCuM5Lr2... has NULL)
                        ▼                                                 ▼
            Reads qr.printerDevice                             getMachineAvailability()
                                                                          │
                                                                          ▼
                                                              Reads legacy PrinterStatus
                                                                          │
                                                                          ▼
                                                                Evaluates as STALE (>180s)
                                                                          │
                                                                          ▼
                                                                Returns:
                                                                - hardwareStatus: UNKNOWN
                                                                - isOnline: false
                                                                - paperStatus: 'OK' (stale DB row)
                                                                - tonerStatus: 'OK' (stale DB row)
                                                                - deviceHealth: null
                                                                - printerDeviceId: null
```

---

## 3. Detailed Audit Findings

### 3.1 Agent Telemetry Event & Exact Payload Structure
- **File & Function:** [printer-agent/src/spooler.js:213-238](file:///D:/PrintGo-S3K-MULTIPRINTER-CANDIDATE/printer-agent/src/spooler.js#L213-L238), `SpoolerMonitor.emitStatus()`
- **Trigger:** Scheduled by `printer-agent/index.js:200-206` via `fleetManager.checkPrinterStatuses(socket)` every 30 seconds.
- **WebSocket Event Name:** `'printer_status_update'`
- **Exact Outgoing Payload Structure:**
  ```json
  {
    "isError": false,
    "errorMessage": "",
    "printerName": "EPSON L6460 Series",
    "printerDeviceId": "619665e1-3c64-44eb-8f57-cb8c3c895e9b",
    "connectionType": "Network",
    "telemetry": {
      "memoryUsage": "xx.xx%",
      "uptime": "xxxxs",
      "platform": "win32",
      "arch": "x64",
      "connectionType": "Network",
      "portName": "192.168.1.7",
      "diagnosticReason": "PRINTER_STATE_UNKNOWN",
      "paperStatus": "UNKNOWN",
      "tonerStatus": "UNKNOWN"
    },
    "timestamp": "2026-11-24T..."
  }
  ```

---

### 3.2 Backend Event Listener & Validation Path
- **File & Function:** [backend/src/socket.js:299-305](file:///D:/PrintGo-S3K-MULTIPRINTER-CANDIDATE/backend/src/socket.js#L299-L305), `socket.on('printer_status_update')`
- **Code:**
  ```javascript
  socket.on('printer_status_update', async (status) => {
    // Keep child-printer health separate from the legacy Machine-wide
    // PrinterStatus stream until device-bound QR/session routing ships.
    if (status?.printerDeviceId) {
      await handlePrinterDeviceTelemetry({ socket, io, prisma, logger, status });
      return;
    }
  ```
- **Validation Path in `handlePrinterDeviceTelemetry()`:** ([backend/src/services/printerAgentProtocol.service.js:377-412](file:///D:/PrintGo-S3K-MULTIPRINTER-CANDIDATE/backend/src/services/printerAgentProtocol.service.js#L377-L412))
  1. Verifies `socket.userType === 'printer'` and `socket.machineId` exists.
  2. Verifies `socket.agentProtocol?.supportsMultiPrinter === true`.
  3. Verifies `status.isError` is a boolean.
  4. Queries `prisma.printerDevice.findFirst` for matching `id` and `machineId`.
  5. Validates `status.printerName` matches `device.windowsPrinterName` (case-insensitive).

---

### 3.3 Device ID Association & Persistence Path
- **Persistence Location:** Table `PrinterDevice` in PostgreSQL.
- **Database Update:** ([backend/src/services/printerAgentProtocol.service.js:435-438](file:///D:/PrintGo-S3K-MULTIPRINTER-CANDIDATE/backend/src/services/printerAgentProtocol.service.js#L435-L438))
  ```javascript
  await prisma.printerDevice.update({
    where: { id: device.id },
    data: { healthStatus, lastTelemetryAt }
  });
  ```
- **Result for Epson (`619665e1-3c64-44eb-8f57-cb8c3c895e9b`):**
  - Because `status.isError === false`, `healthStatus` is set to **`ONLINE`**.
  - `lastTelemetryAt` is set to the current timestamp.
  - Broadcasts `printer_device_status_update` to `company_${companyId}` and `superadmins`.
- **Key Realization:** This device telemetry successfully updates `PrinterDevice`, but because of the `return;` on line 304 of `socket.js`, **zero records are inserted into table `PrinterStatus`**.

---

### 3.4 Customer QR API Response Calculation Path
- **File & Function:** [backend/src/services/printerQr.service.js:758-876](file:///D:/PrintGo-S3K-MULTIPRINTER-CANDIDATE/backend/src/services/printerQr.service.js#L758-L876), `getPublicPrinterQrInfo(publicCode)`
- **Query:** Looks up `publicCode` (`pq_YCuM5Lr2_nQMuxahsrBqjb9jWQSUhMDPd0Cbl_tpDB8`) in table `PrinterQr`.
- **Database State for this QR:**
  - `machineId`: `"d010496f-f176-41fe-9c98-efd2213a4a0e"`
  - `printerDeviceId`: **`null`** (This is a Machine Counter QR flyer, not a child device QR).
- **Execution Branch:**
  - Lines 824-852 (`if (qr.printerDevice && !legacyPlaceholderDevice)`) are **bypassed** because `qr.printerDeviceId` is `null`.
  - Lines 868-870:
    ```javascript
    lastTelemetryAt: null, // explicitly initialized to null at line 822
    deviceHealth: qr.printerDevice && !legacyPlaceholderDevice ? qr.printerDevice.healthStatus : null, // evaluates to null
    printerDeviceId: qr.printerDevice && !legacyPlaceholderDevice ? qr.printerDevice.id : null, // evaluates to null
    ```
  - Line 818 executes fallback availability calculation:
    `const availability = await getMachineAvailability(qr.machine.id, prisma);`

---

### 3.5 Telemetry Stale Window & Legacy Availability Evaluation
- **File & Function:** [backend/src/services/printerAvailability.service.js:223-249](file:///D:/PrintGo-S3K-MULTIPRINTER-CANDIDATE/backend/src/services/printerAvailability.service.js#L223-L249), `getMachineAvailability()`
- **Query:** `dbClient.machine.findUnique({ where: { id: machineId }, include: { printerStatuses: { take: 1, orderBy: { timestamp: 'desc' } } } })`
- **Evaluation:** [printerAvailability.service.js:96-162](file:///D:/PrintGo-S3K-MULTIPRINTER-CANDIDATE/backend/src/services/printerAvailability.service.js#L96-L162), `computePrinterAvailability()`
  1. **Agent Heartbeat:** Evaluates `machine.lastOnline`. Updated continuously by periodic `socket.on('heartbeat')`. Within 90s window (`ONLINE_HEARTBEAT_WINDOW_MS`), so **`agentOnline = true`**.
  2. **Physical Telemetry Staleness:**
     ```javascript
     const telemetryDiffMs = refTimeMs - telemetryMs;
     if (telemetryDiffMs < 0 || telemetryDiffMs > TELEMETRY_STALE_WINDOW_MS) {
       return {
         status: PRINTER_STATES.UNKNOWN,
         isReady: false,
         agentOnline,
         statusMessage: CUSTOMER_STATUS_MESSAGES[PRINTER_STATES.UNKNOWN],
         paperStatus: latestPrinterStatus.paperStatus || 'UNKNOWN',
         tonerStatus: latestPrinterStatus.tonerStatus || 'UNKNOWN',
         jamStatus: Boolean(latestPrinterStatus.jamStatus),
       };
     }
     ```
  3. Because the child monitors bypass `prisma.printerStatus.create()`, the newest row in `printerStatus` is from prior to Phase 7.
  4. `telemetryDiffMs` exceeds `TELEMETRY_STALE_WINDOW_MS` (180,000 ms / 3 minutes).
  5. The function returns:
     - `status`: `'UNKNOWN'` (`hardwareStatus: "UNKNOWN"`)
     - `isReady`: `false` (`isOnline: false`)
     - `statusMessage`: `'Printer Status Unavailable'`

---

### 3.6 Explanation of the `paperStatus: "OK"` and `tonerStatus: "OK"` Discrepancy
Why did the API return `paperStatus: "OK"` and `tonerStatus: "OK"` if the Agent sent `UNKNOWN`?
1. The Agent **did** emit `paperStatus: 'UNKNOWN'` and `tonerStatus: 'UNKNOWN'` inside `telemetry`.
2. However, the customer QR endpoint did not read the live telemetry object; it read the **stale legacy `PrinterStatus` row** in the database via `latestPrinterStatus.paperStatus`.
3. In that legacy row (written in Phase 4/5):
   - [backend/src/socket.js:329](file:///D:/PrintGo-S3K-MULTIPRINTER-CANDIDATE/backend/src/socket.js#L329) used a rigid ternary:
     `paperStatus: status.errorMessage === 'Out of Paper' ? 'OUT' : 'OK'`
     Because `errorMessage` was `'Printer State Unknown'`, it inserted **`'OK'`**.
   - `tonerStatus` was omitted from insertion, falling back to Prisma's default:
     [backend/prisma/schema.prisma:488](file:///D:/PrintGo-S3K-MULTIPRINTER-CANDIDATE/backend/prisma/schema.prisma#L488): `tonerStatus String @default("OK")`.
4. When `computePrinterAvailability` flagged the row as stale, it returned:
   `paperStatus: latestPrinterStatus.paperStatus || 'UNKNOWN'` -> read the stored `'OK'`.
   `tonerStatus: latestPrinterStatus.tonerStatus || 'UNKNOWN'` -> read the stored `'OK'`.

---

## 4. Confirmed Root Cause Summary

| Observation | Confirmed Root Cause | Evidence / File & Lines |
| :--- | :--- | :--- |
| **`agentOnline: true`** | Machine heartbeat arrives continuously via WebSocket `heartbeat` event and updates `machine.lastOnline`. | [backend/src/socket.js:286-297](file:///D:/PrintGo-S3K-MULTIPRINTER-CANDIDATE/backend/src/socket.js#L286-L297)<br>[printerAvailability.service.js:96-110](file:///D:/PrintGo-S3K-MULTIPRINTER-CANDIDATE/backend/src/services/printerAvailability.service.js#L96-L110) |
| **`printerDeviceId: null`**<br>**`deviceHealth: null`**<br>**`lastTelemetryAt: null`** | The scanned QR (`pq_YCuM5Lr2...`) is a Machine-level QR flyer (`qr.printerDeviceId == null`), not a child-printer QR. The QR handler explicitly leaves these fields `null`. | [backend/prisma/schema.prisma:220-222](file:///D:/PrintGo-S3K-MULTIPRINTER-CANDIDATE/backend/prisma/schema.prisma#L220-L222)<br>[printerQr.service.js:824-870](file:///D:/PrintGo-S3K-MULTIPRINTER-CANDIDATE/backend/src/services/printerQr.service.js#L824-L870) |
| **`isOnline: false`**<br>**`hardwareStatus: UNKNOWN`** | When child monitors emit telemetry with `printerDeviceId`, `socket.js` returns early and skips `PrinterStatus.create()`. The legacy table has zero rows younger than 180s, causing `computePrinterAvailability` to fail closed as `UNKNOWN` (stale telemetry). | [backend/src/socket.js:300-305](file:///D:/PrintGo-S3K-MULTIPRINTER-CANDIDATE/backend/src/socket.js#L300-L305)<br>[printerAvailability.service.js:151-162](file:///D:/PrintGo-S3K-MULTIPRINTER-CANDIDATE/backend/src/services/printerAvailability.service.js#L151-L162) |
| **`paperStatus: "OK"`**<br>**`tonerStatus: "OK"`** | Read from the stale legacy database row created prior to Phase 7, which defaulted to `'OK'` due to the legacy ternary operator and Prisma schema `@default("OK")`. | [backend/src/socket.js:329](file:///D:/PrintGo-S3K-MULTIPRINTER-CANDIDATE/backend/src/socket.js#L329)<br>[backend/prisma/schema.prisma:487-488](file:///D:/PrintGo-S3K-MULTIPRINTER-CANDIDATE/backend/prisma/schema.prisma#L487-L488) |

---

## 5. Recommended Minimal Fix (Recommendation Only — Not Implemented)

To bridge the child-printer architecture with the machine-level customer QR flyer without breaking existing contracts:

### Option A: Default Printer Telemetry Bridge (Recommended for Staging Backend)
In [backend/src/socket.js:302-305](file:///D:/PrintGo-S3K-MULTIPRINTER-CANDIDATE/backend/src/socket.js#L302-L305):
When `status?.printerDeviceId` is received:
1. Update `PrinterDevice` via `handlePrinterDeviceTelemetry()`.
2. Check if the device is the Machine's default printer (`device.isDefault === true`).
3. If it is the default device, also update the Machine-wide availability:
   - Create or update the latest `PrinterStatus` row with:
     - `isOnline: !status.isError`
     - `paperStatus: status.telemetry?.paperStatus || (status.errorMessage === 'Out of Paper' ? 'OUT' : 'OK')`
     - `tonerStatus: status.telemetry?.tonerStatus || 'OK'`
     - `connectionType: status.connectionType`
     - `timestamp: new Date()`
4. This ensures that customers scanning the existing physical counter QR flyer immediately receive live `Printer Ready` (`isOnline: true`) while child device routing is finalized.

### Option B: Machine Availability Service Fallback to Default PrinterDevice
In [backend/src/services/printerAvailability.service.js:223-249](file:///D:/PrintGo-S3K-MULTIPRINTER-CANDIDATE/backend/src/services/printerAvailability.service.js#L223-L249):
If `machine.printerStatuses` is empty or stale, check `prisma.printerDevice.findFirst({ where: { machineId, isDefault: true, status: 'ACTIVE' } })`. If found and `healthStatus === 'ONLINE'` with fresh `lastTelemetryAt` (<180s), return `status: PRINTER_STATES.ONLINE, isReady: true`.

---

## 6. Strict Safety & Invariant Confirmation

- **Code Modifications:** Exactly **0** files were modified or created in this audit.
- **Process Status:** Candidate Agent PID **`10940`** remains running continuously and untouched.
- **Service Status:** Windows Print Spooler service remains running and was **NOT restarted**.
- **Print Jobs:** Exactly **0 print jobs** were submitted across all physical or virtual queues.
- **Configuration & Database:** Zero database records, QR mappings, approvals, or environment variables were modified.
