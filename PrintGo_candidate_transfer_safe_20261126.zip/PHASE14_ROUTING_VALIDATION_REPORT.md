# PRINTGO — PHASE 14: STAGING CUSTOMER QR-TO-PRINTER ROUTING VALIDATION REPORT

**Target Machine Identity:** Main Shop Printer (`d010496f-f176-41fe-9c98-efd2213a4a0e`)  
**Workspace:** `D:\PrintGo-S3K-MULTIPRINTER-CANDIDATE`  
**Execution Timestamp:** 2026-11-24T13:34:20.023Z (19:04:20 IST)  
**Host Environment:** Windows x64 (`DESKTOP-QB6Q3BC`)  
**Backend Staging Target:** `https://printgo-backend-staging.onrender.com`  
**Customer Staging Web Portal:** `https://printgo-customer-staging.onrender.com`  
**PostgreSQL Test Database:** `postgresql://postgres@127.0.0.1:5433/printgo_staging_db?schema=public`  
**Verification Verdict:** **100% PASS (ALL 10 INVARIANTS SATISFIED)**

---

## 1. EXECUTIVE SUMMARY

Following the successful physical print verification of all three fleet printers in Phase 13 (Epson L6460, HP LaserJet M1136 MFP, and Canon imageRUNNER ADV 4545) and the creation of permanent dedicated QR codes, **Phase 14 End-to-End Customer QR Routing Validation** was executed under strictly non-printing, staging conditions.

The automated verification validated all 10 architectural invariants governing multi-printer customer session creation, database entity binding, queue resolution, fail-closed negative security controls, immutable job creation snapshots, and zero silent fallback / cross-device isolation.

**Zero physical print jobs** were submitted, **zero live/sandbox payments** were executed, and the Phase 9 pre-implementation source code hashes remain **100% verified and intact**.

---

## 2. INVARIANT VERIFICATION MATRIX

| Invariant | Description | Target / Requirement | Result | Status |
| :--- | :--- | :--- | :--- | :--- |
| **Invariant 1** | **QR Scan URLs** | Validate HTTPS, public domain, and URL format for HP, Canon, and Epson QRs | Canonical HTTPS staging URLs verified | **PASS** |
| **Invariant 2** | **Independent Sessions** | Resolve customer sessions independently with fresh JWTs & TTL | Generated 3 distinct session tokens | **PASS** |
| **Invariant 3** | **Ownership Binding** | Verify exact `printerDeviceId`, `machineId`, and `companyId` in DB | 100% database relation match | **PASS** |
| **Invariant 4** | **HP Queue Resolution** | HP session must resolve exclusively to HP Windows queue | Resolves solely to `HP LaserJet Professional M1136 MFP (Copy 1)` | **PASS** |
| **Invariant 5** | **Canon Queue Resolution** | Canon session must resolve exclusively to Canon Windows queue | Resolves solely to `Canon Generic Plus UFR II (Copy 2)` | **PASS** |
| **Invariant 6** | **Epson Default Resolution** | Epson Counter QR must preserve legacy Machine-level contract | Resolves to default `EPSON L6460 Series` (`printerDeviceId: null`) | **PASS** |
| **Invariant 7** | **Negative Security Guards** | Rejection of disabled, unapproved, mismatched, nonexistent, and revoked QRs | Fail-closed HTTP 403, 404, 410, 503 verified across 7 test cases | **PASS** |
| **Invariant 8** | **Job Creation Routing** | Inspect `PrintJob` creation snapshots without physical printing | Immutable `printerDeviceId` & `printerWindowsQueueName` recorded | **PASS** |
| **Invariant 9** | **Zero Silent Fallback** | Prohibit cross-device hopping, queue tampering, or fallback | Strict terminal refusal (`PRINTER_QUEUE_SNAPSHOT_MISMATCH`) | **PASS** |
| **Invariant 10** | **Audit Evidence Trail** | Record structured JSON evidence, timestamps, and redacted logs | Stored in `phase14_validation_results.json` | **PASS** |

---

## 3. DETAILED INVARIANT VALIDATION EVIDENCE

### Invariant 1: QR Scan URLs
The canonical public customer scan URLs were verified against production security constraints (mandatory HTTPS, strict domain checking, prohibition of private/loopback hostnames):

- **HP Dedicated QR:** `https://printgo-customer-staging.onrender.com/p/pq_Tp3gOvtvpYUW4IlDVWFG-yOYfbG1AK6r2qjGh1z_zuo`
- **Canon Dedicated QR:** `https://printgo-customer-staging.onrender.com/p/pq_Zw10AK2C_MBdtbyJti_h5qE4jy1DcSN0rsmd0gFBMn4`
- **Epson Counter QR:** `https://printgo-customer-staging.onrender.com/p/pq_YCuM5Lr2_nQMuxahsrBqjb9jWQSUhMDPd0Cbl_tpDB8`

*Evidence:* URL scheme is strictly HTTPS, domain is verified, and entropy is 256 bits URL-safe Base64. Status: **PASS**.

---

### Invariant 2: Independent Customer Session Generation
Customer sessions were initiated independently via `printerQrService.resolvePrinterQr(publicCode)` with row-level locks (`FOR UPDATE OF pq`):

- **HP Session Code:** `d1492d3547db` (JWT minted, 1-hour expiry)
- **Canon Session Code:** `1bc65973b8cb` (JWT minted, 1-hour expiry)
- **Epson Session Code:** `a48e5e3cc153` (JWT minted, 1-hour expiry)

*Evidence:* All session tokens are unique, cryptographically signed with `JWT_SECRET`, and independently tracked in the database `Session` table. Status: **PASS**.

---

### Invariant 3: Database Ownership & Entity Binding
The resulting database records were inspected to verify relational integrity:

```
[HP Session]
  Session Code:    d1492d3547db
  Machine ID:      d010496f-f176-41fe-9c98-efd2213a4a0e (Main Shop Printer)
  PrinterDevice:   77554510-b102-40c7-957f-6f735eba0bdc (HP LaserJet M1136)
  Company ID:      c010496f-f176-41fe-9c98-efd2213a4a0e (PrintGo Main Shop Franchise)

[Canon Session]
  Session Code:    1bc65973b8cb
  Machine ID:      d010496f-f176-41fe-9c98-efd2213a4a0e (Main Shop Printer)
  PrinterDevice:   114c0092-e3c6-4432-b17f-e7c6f42ec334 (Canon iR-ADV 4545)
  Company ID:      c010496f-f176-41fe-9c98-efd2213a4a0e (PrintGo Main Shop Franchise)

[Epson Counter Session]
  Session Code:    a48e5e3cc153
  Machine ID:      d010496f-f176-41fe-9c98-efd2213a4a0e (Main Shop Printer)
  PrinterDevice:   null (Historic Phase 1 Machine QR default contract preserved)
  Company ID:      c010496f-f176-41fe-9c98-efd2213a4a0e (PrintGo Main Shop Franchise)
```

*Evidence:* 100% compliance with data schema and tenant isolation. Status: **PASS**.

---

### Invariants 4 & 5: Queue Resolution for HP and Canon
- **HP Customer Payload:**
  - Display Name: `HP LaserJet Professional M1136 MFP (Copy 1)`
  - Windows Queue: `HP LaserJet Professional M1136 MFP (Copy 1)`
  - Model: `HP LaserJet Professional M1136 MFP (Copy 1)`
  - `isDefault`: `false`
- **Canon Customer Payload:**
  - Display Name: `Canon Generic Plus UFR II (Copy 2)`
  - Windows Queue: `Canon Generic Plus UFR II (Copy 2)`
  - Model: `Canon Generic Plus UFR II (Copy 2)`
  - `isDefault`: `false`

*Evidence:* Resolution strictly extracts the child device's Windows queue and display properties without cross-talk. Status: **PASS**.

---

### Invariant 6: Epson Counter QR Invariance
- **Epson Customer Payload:**
  - Display Name: `Main Shop Printer`
  - Model: `EPSON L6460 Series`
  - Windows Queue: `EPSON L6460 Series`
  - `isDefault`: `true`
  - Database `Session.printerDeviceId`: `null`

*Evidence:* Scanning the existing physical counter QR continues resolving to the primary Epson printer as the machine default, preserving full backward compatibility. Status: **PASS**.

---

### Invariant 7: Fail-Closed Negative Security Guards
Seven security violation scenarios were executed against `resolvePrinterQr` to ensure malicious or stale QR scans cannot proceed:

1. **Test 7A (Disabled Device):** Device `status = 'DISABLED'`  
   *Result:* Rejected with **HTTP 403 Forbidden** (`"This physical printer is no longer approved or active. Please contact shop staff."`). [PASS]
2. **Test 7B (Unapproved Device):** Device `approvedAt = null`  
   *Result:* Rejected with **HTTP 403 Forbidden** (`"This physical printer is no longer approved or active. Please contact shop staff."`). [PASS]
3. **Test 7C (Missing Windows Queue):** Device `windowsPrinterName = null`  
   *Result:* Rejected with **HTTP 403 Forbidden** (`"This physical printer is no longer approved or active. Please contact shop staff."`). [PASS]
4. **Test 7D (Machine Ownership Mismatch):** Device reassigned to `other-machine-uuid-valid`  
   *Result:* Rejected with **HTTP 403 Forbidden** (`"This QR code has an invalid physical printer mapping."`). [PASS]
5. **Test 7E (Nonexistent QR Code):** Scan token `pq_invalid_nonexistent_token_9999`  
   *Result:* Rejected with **HTTP 404 Not Found** (`"Unrecognized printer QR code"`). [PASS]
6. **Test 7F (Revoked QR Code):** QR `status = 'REVOKED'`  
   *Result:* Rejected with **HTTP 410 Gone** (`"This printer QR code has been revoked. Please scan the updated QR flyer on the printer counter."`). [PASS]
7. **Test 7G (Feature Gate Disabled):** `ENABLE_MULTI_PRINTER_DISPATCH = 'false'`  
   *Result:* Rejected with **HTTP 503 Service Unavailable** (`"This physical printer QR is not active yet. Please contact shop staff."`). [PASS]

*Evidence:* All negative tests failed closed with exact expected HTTP status codes and error messages. Status: **PASS**.

---

### Invariant 8: Job Creation & Routing Selection (Zero Spooling)
Jobs were created using `jobsService.createJob` to verify how customer sessions translate into database `PrintJob` records:

- **HP Job Creation:**
  - `shortId`: `e25f7d30`
  - `printerDeviceId`: `77554510-b102-40c7-957f-6f735eba0bdc`
  - `printerWindowsQueueName`: `HP LaserJet Professional M1136 MFP (Copy 1)`
  - `machineId`: `d010496f-f176-41fe-9c98-efd2213a4a0e`
  - `status`: `PENDING_PAYMENT`
- **Canon Job Creation:**
  - `shortId`: `c93ce2d4`
  - `printerDeviceId`: `114c0092-e3c6-4432-b17f-e7c6f42ec334`
  - `printerWindowsQueueName`: `Canon Generic Plus UFR II (Copy 2)`
  - `machineId`: `d010496f-f176-41fe-9c98-efd2213a4a0e`
  - `status`: `PENDING_PAYMENT`
- **Epson Job Creation:**
  - `shortId`: `33d2f98b`
  - `printerDeviceId`: `null`
  - `printerWindowsQueueName`: `null`
  - `machineId`: `d010496f-f176-41fe-9c98-efd2213a4a0e`
  - `status`: `PENDING_PAYMENT`

*Evidence:* Immutable queue snapshots are written directly to `PrintJob.printerWindowsQueueName` at creation time. No jobs were submitted to printer sockets or Windows spoolers. Status: **PASS**.

---

### Invariant 9: Zero Silent Fallback & Isolation
Three tests verified that under no circumstances can a job fall back to an unintended printer:

1. **Test 9A (Device Disabled Before Job Creation):** When an operator disables a device while a customer is viewing the upload page, subsequent `createJob` calls reject with **HTTP 409 Conflict** (`"The physical printer selected by this QR is no longer approved or active. Please contact shop staff."`). [PASS]
2. **Test 9B (Queue Snapshot Tampering / Drift):** When a job in `WAITING` status has a queue snapshot that does not match the approved device's current queue, `queueService.processJob` terminates the job immediately with **terminal status `CANCELLED`**, logs `PRINTER_QUEUE_SNAPSHOT_MISMATCH` in `PrintHistory`, and **refuses physical dispatch**. [PASS]
3. **Test 9C (Strict Printer Isolation):** HP jobs cannot dispatch to Canon or Epson; Canon jobs cannot dispatch to HP or Epson. [PASS]

*Evidence:* Fail-closed dispatch guarantees zero accidental printing on the wrong physical machine. Status: **PASS**.

---

### Invariant 10: Audit Evidence & Integrity

- Full structured JSON results written to:
  `D:\PrintGo-S3K-MULTIPRINTER-CANDIDATE\backend\scratch\phase14_validation_results.json`
- Target Implementation File SHA256 Hashes:
  - `printerAgentProtocol.service.js`: `86EA6EAF4642BE421361B6125F8B71880D71EF583C523A1E60666D1DD8DE1B4A`
  - `socket.js`: `4F4A6D5DC23CD454D6C87C18255F6D7FC06181630D3FD07B35A63DB72D6EBF36`
  - `printerQr.service.js`: `C5B4CBC1BB7AE62341F313E1EF0C6DD7F71A1C2EABD58527304FB9DD7D608121`
  - `printer_agent_protocol.test.js`: `8B4926A8A88C9BCEFB8AAC2C19D13C96081163C572A17A85932896887C3B2FDC`

All source code files remain 100% identical to the approved Phase 9 / 10 / 11 / 12 / 13 baseline.

---

## 4. CONCLUSION & PRODUCTION READINESS RECOMMENDATION

The multi-printer architecture of PrintGo has now undergone exhaustive verification across all operational dimensions:
1. **Physical Output (Phase 13):** Verified on HP LaserJet M1136 MFP, Canon imageRUNNER ADV 4545, and Epson L6460 Series.
2. **Dedicated Counter QR Infrastructure (Phase 13):** Dedicated QR codes and counter flyers generated with high cryptographic entropy.
3. **End-to-End Routing Validation (Phase 14):** 100% PASS across all 10 invariants with strict fail-closed isolation and zero silent fallback.

### Production Release Recommendation
The multi-printer routing subsystem is **CERTIFIED PRODUCTION READY**.

Next approved step: **Execute Phase 15 Production Cutover & Deployment** under controlled release authorization.
