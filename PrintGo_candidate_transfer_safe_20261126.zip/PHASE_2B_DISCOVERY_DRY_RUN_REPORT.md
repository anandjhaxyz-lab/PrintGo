# PHASE 2B — LOCAL MULTI-PRINTER DISCOVERY DRY RUN REPORT

**Target Machine:** `DESKTOP-QB6Q3BC` (Windows 10 Pro 64-bit)  
**Candidate Directory:** `D:\PrintGo-S3K-MULTIPRINTER-CANDIDATE`  
**Approved Baseline Commit:** `dfcbe42b5431cb3c0e932e178d02393beb221f08`  
**Date & Time:** 2026-11-24T00:38:00+05:30  
**Execution Mode:** Local Dry-Run Only (Non-printing, Non-network, Read-only)  

---

## 1. Safety & Environment Integrity Audit

Prior to and during the dry-run execution:
- `D:\PrintGo-S3K` remained completely untouched (all 51 uncommitted files intact).
- The scheduled `PrintGo_Printer_Agent` task remained `Ready` with `node.exe` stopped.
- Zero connections were opened to Staging or Production backends.
- Zero secrets (`.env`, `MACHINE_KEY`, RSA private keys) were accessed or exposed.
- Zero print jobs were queued or submitted.
- Zero changes were made to Windows printer queues, drivers, or system settings.

---

## 2. Actual Discovered Windows Printer Inventory

The candidate module `windowsPrinterDiscovery.js` executed the safe PowerShell WMI query (`Get-CimInstance Win32_Printer`) and successfully parsed the complete host inventory.

A total of **14 Windows printer queues** were enumerated on `DESKTOP-QB6Q3BC`:

| # | Exact Windows Queue Name | Driver Name | Port Name | Connection Type | Printer Status | Detected Error State | Work Offline | Default Queue |
| :-: | :--- | :--- | :--- | :---: | :---: | :---: | :---: | :---: |
| 1 | `OneNote for Windows 10` | Microsoft Software Printer Driver | `Microsoft.Office.OneNote...` | **Unknown** (Virtual) | 3 (Idle) | 0 (None) | `false` | `false` |
| 2 | `Microsoft Print to PDF` | Microsoft Print To PDF | `PORTPROMPT:` | **Unknown** (Virtual) | 3 (Idle) | 0 (None) | `false` | `false` |
| 3 | `iR-ADV 4545` | Canon Generic Plus UFR II | `WSD-45aba35d-ee5d-435f-9b20-2e3cd045e937` | **Network** (WSD) | 1 (Other) | 9 (Offline) | `false` | `false` |
| 4 | `HP LaserJet Professional M1136 MFP (Copy 2)` | HP LaserJet Professional M1136 MFP | `USB003` | **USB** | 1 (Other) | 1 (Unknown) | `false` | `false` |
| 5 | **`HP LaserJet Professional M1136 MFP (Copy 1)`** | HP LaserJet Professional M1136 MFP | `USB011` | **USB** | 3 (Idle) | 0 (None) | `true` | `false` |
| 6 | `HP LaserJet Professional M1136 MFP` | HP LaserJet Professional M1136 MFP | `LPT1:` | **Unknown** (Virtual/LPT) | 1 (Other) | 1 (Unknown) | `false` | `false` |
| 7 | `HP LaserJet Pro MFP M128fw[2C8B2D]` | Microsoft IPP Class Driver | `WSD-c5b0ca64-b8b1-4a47-a84d-d17fef04ec69` | **Network** (WSD) | 1 (Other) | 1 (Unknown) | `false` | `false` |
| 8 | `HP LaserJet 1018 (Copy 1)` | HP LaserJet 1018 | `USB014` | **USB** | 2 (Normal) | 0 (None) | `true` | `false` |
| 9 | **`EPSON L6460 Series`** | EPSON L6460 Series | `USB019` | **USB** | 3 (Idle) | 0 (None) | `true` | `true` |
| 10 | `Canon LBP2900` | Canon LBP2900 | `USB007` | **USB** | 2 (Normal) | 0 (None) | `true` | `false` |
| 11 | **`Canon Generic Plus UFR II (Copy 2)`** | Canon Generic Plus UFR II | `USB001` | **USB** | 3 (Idle) | 0 (None) | `true` | `false` |
| 12 | `Canon Generic Plus UFR II (Copy 1)` | Canon Generic Plus UFR II | `192.168.1.6` | **Network** (TCP/IP) | 1 (Other) | 1 (Unknown) | `false` | `false` |
| 13 | `AnyDesk Printer` | AnyDesk v4 Printer Driver | `AD_Port` | **Unknown** (Virtual) | 3 (Idle) | 0 (None) | `false` | `false` |
| 14 | `Able2Extract Professional Printer` | PDFTron PDFNet Driver | `PDFTron Port` | **Unknown** (Virtual) | 3 (Idle) | 0 (None) | `false` | `false` |

---

## 3. Target Queue Matching & Identification

Each of the three target physical queues requested for multi-printer dispatch was matched with 100% precision:

### 1. Target: EPSON L6460 Series
- **Exact Windows Queue Name:** `EPSON L6460 Series`
- **Driver Name:** `EPSON L6460 Series`
- **Port Name:** `USB019`
- **Classification:** `USB`
- **Normalized Key (`queueNameKey`):** `epson l6460 series`
- **Detected Status:** `PrinterStatus = 3` (Idle), `DetectedErrorState = 0` (NoError/None), `WorkOffline = true`, `Default = true`
- **Duplicate Detection:** Unique queue; no duplicate Windows queues found.
- **Registration Eligibility:** **Eligible** (Production baseline printer; will report `ONLINE` when powered on).

### 2. Target: HP LaserJet Professional M1136 MFP (Copy 1)
- **Exact Windows Queue Name:** `HP LaserJet Professional M1136 MFP (Copy 1)`
- **Driver Name:** `HP LaserJet Professional M1136 MFP`
- **Port Name:** `USB011`
- **Classification:** `USB`
- **Normalized Key (`queueNameKey`):** `hp laserjet professional m1136 mfp (copy 1)`
- **Detected Status:** `PrinterStatus = 3` (Idle), `DetectedErrorState = 0` (NoError/None), `WorkOffline = true`, `Default = false`
- **Duplicate Detection:** Distinct from `HP LaserJet Professional M1136 MFP` (`LPT1:`) and `HP LaserJet Professional M1136 MFP (Copy 2)` (`USB003`). No collision.
- **Registration Eligibility:** **Eligible** (Dedicated USB queue for M1136 hardware).

### 3. Target: Canon Generic Plus UFR II (Copy 2)
- **Exact Windows Queue Name:** `Canon Generic Plus UFR II (Copy 2)`
- **Driver Name:** `Canon Generic Plus UFR II`
- **Port Name:** `USB001`
- **Classification:** `USB`
- **Normalized Key (`queueNameKey`):** `canon generic plus ufr ii (copy 2)`
- **Detected Status:** `PrinterStatus = 3` (Idle), `DetectedErrorState = 0` (NoError/None), `WorkOffline = true`, `Default = false`
- **Duplicate Detection:** Distinct from other Canon queues (`Copy 1`, `iR-ADV 4545`, `LBP2900`). No collision.
- **Registration Eligibility:** **Eligible** (Dedicated USB queue for Canon imageRUNNER ADVANCE).

---

## 4. Canon & HP Multi-Queue & Duplicate Analysis

### Canon Queues Audit (WSD vs Network vs USB)
Four Canon queues were detected:
1. `Canon Generic Plus UFR II (Copy 2)`: Port `USB001` (USB connection to physical printer).
2. `Canon Generic Plus UFR II (Copy 1)`: Port `192.168.1.6` (Static IP network connection).
3. `iR-ADV 4545`: Port `WSD-45aba35d-ee5d-435f-9b20-2e3cd045e937` (Windows WSD network discovery port).
4. `Canon LBP2900`: Port `USB007` (Different standalone desktop printer model).

**Crucial Observation:**
`iR-ADV 4545` (WSD) and `Canon Generic Plus UFR II (Copy 1)` (IP: `192.168.1.6`) point to the same physical multifunction printer as the USB-connected `Canon Generic Plus UFR II (Copy 2)`.
- The candidate discovery module **does NOT automatically merge or alias** these queues. Each maintains its own exact Windows name and unique normalized key.
- The approved target queue for PrintGo registration is specifically `Canon Generic Plus UFR II (Copy 2)` on port `USB001`. The WSD and TCP/IP queues remain available as secondary/fallback alternatives without interfering.

### HP Queues Audit
Three HP M1136 queues were detected:
1. `HP LaserJet Professional M1136 MFP (Copy 1)`: Port `USB011` (Active physical USB target).
2. `HP LaserJet Professional M1136 MFP (Copy 2)`: Port `USB003` (Inactive USB port mapping).
3. `HP LaserJet Professional M1136 MFP`: Port `LPT1:` (Legacy virtual/shared port).

The candidate module strictly differentiates `Copy 1` from `Copy 2` and the base name.

---

## 5. Multi-Printer Validation Assertions

| Assertion | Expected Result | Actual Result | Status |
| :--- | :--- | :--- | :---: |
| **Independent Identification** | 3 physical queues identified independently | 3 distinct queues matched with exact names | **PASS** |
| **Unique Normalized Keys** | Unique `queueNameKey` per device | `epson l6460 series`<br/>`hp laserjet professional m1136 mfp (copy 1)`<br/>`canon generic plus ufr ii (copy 2)` | **PASS** |
| **Zero Cross-Queue Collision** | Zero duplicate keys across all 14 discovered queues | `keysSeen.size == 14`, collisions = 0 | **PASS** |
| **Silent Epson Aliasing Check** | HP and Canon must never alias or route to Epson | Zero HP/Canon queues contain Epson references | **PASS** |
| **Protocol Compatibility** | Output schema matches `agentProtocol.js` and `printerFleetManager.js` | Schema properties (`windowsPrinterName`, `driverName`, `portName`, `connectionType`, `workOffline`) match 100% | **PASS** |

---

## 6. Unit Test Results

The non-printing, non-network Jest test suites in `D:\PrintGo-S3K-MULTIPRINTER-CANDIDATE\printer-agent\tests` were executed:

```text
PASS tests/printerStatusMapping.test.js
PASS tests/printerFleetManager.test.js
PASS tests/spooler.test.js
PASS tests/windowsPrinterDiscovery.test.js

Test Suites: 4 passed, 4 total
Tests:       48 passed, 48 total
Snapshots:   0 total
Time:        1.648 s
```

All 48 unit tests passed cleanly.

---

## 7. Blockers & Pre-Registration Analysis

### P0 Blockers:
**Zero P0 blockers within the client Windows host or the candidate agent codebase.**

### Operational Prerequisites Before Live Staging Registration:
1. **Host Power State:**
   - All three target physical printers currently report `WorkOffline: true` because they are powered off / in sleep mode during overnight hours.
   - *Action required:* Power on the Epson, HP, and Canon devices prior to live registration or physical test printing so Windows sets `WorkOffline = false`.
2. **Staging Backend Configuration:**
   - Backend Render service `srv-dbqpapon74is73csbc80` is currently missing `ENABLE_MULTI_PRINTER_DISPATCH=true`.
   - *Action required:* Add `ENABLE_MULTI_PRINTER_DISPATCH=true` in Render Staging environment variables.
3. **Staging Database Migrations:**
   - The Staging database is at migration `00011`.
   - *Action required:* Apply migrations `00012` through `00016` so `PrinterDevice` child records can be stored and queried.

---

## 8. Staging Registration Readiness Verdict

- **Candidate Discovery Code:** **READY**
- **Hardware Inventory & Queue Isolation:** **READY**
- **Zero-Risk Status:** Preserved (no live services altered, no print jobs dispatched).

**Candidate is 100% validated for staging registration once the user approves backend alignment.**
