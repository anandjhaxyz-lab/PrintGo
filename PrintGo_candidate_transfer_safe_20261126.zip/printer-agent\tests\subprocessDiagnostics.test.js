const {
  buildSubprocessDiagnostic,
  formatSubprocessDiagnostic
} = require('../src/subprocessDiagnostics');

describe('subprocess diagnostics', () => {
  test('captures exit code, stderr, timeout and command category with bounded text', () => {
    const error = new Error('Command failed');
    error.code = 1;
    error.errno = 'EACCES';
    error.syscall = 'spawn powershell.exe';

    const result = buildSubprocessDiagnostic(
      'windows-printer-discovery',
      error,
      'Access is denied',
      15000
    );

    expect(result).toEqual(expect.objectContaining({
      category: 'windows-printer-discovery',
      exitCode: 1,
      errno: 'EACCES',
      syscall: 'spawn powershell.exe',
      timedOut: false,
      timeoutMs: 15000,
      stderr: 'Access is denied'
    }));
    expect(JSON.parse(formatSubprocessDiagnostic(result))).toEqual(result);
  });

  test('identifies a killed timed-out child process', () => {
    const error = new Error('Command timed out');
    error.code = 'ETIMEDOUT';
    error.killed = true;
    error.signal = 'SIGTERM';

    expect(buildSubprocessDiagnostic('windows-printer-status', error, '', 8000))
      .toEqual(expect.objectContaining({
        category: 'windows-printer-status',
        exitCode: null,
        errorCode: 'ETIMEDOUT',
        killed: true,
        signal: 'SIGTERM',
        timedOut: true,
        timeoutMs: 8000
      }));
  });

  test('strips control characters and truncates stderr', () => {
    const result = buildSubprocessDiagnostic('test', null, 'first\nsecond' + 'x'.repeat(2500), 100);
    expect(result.stderr).toHaveLength(2000);
    expect(result.stderr).not.toMatch(/[\u0000-\u001f\u007f]/);
  });
});
