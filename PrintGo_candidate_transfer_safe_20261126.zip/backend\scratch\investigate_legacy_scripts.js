const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');

const backendDir = 'D:/PrintGo-S3K-MULTIPRINTER-CANDIDATE/backend';
const testsDir = path.join(backendDir, 'tests');
const evidenceDir = 'D:/PrintGo-S3K-MULTIPRINTER-CANDIDATE/phase11_investigation_evidence';

const legacyFiles = [
  'render_cors_and_websocket.test.js',
  'reconciliation_and_acknowledgement.test.js',
  'queue_failure_injection.test.js',
  'phase5_dashboard_and_shop_management.test.js',
  'phase4_refunds_reconciliation.test.js',
  'phase3_pricing_and_invoices.test.js',
  'phase3_admin_dashboard_qr_integration.test.js',
  'phase3_1_security_and_financial.test.js',
  'phase4_customer_mobile_qr_flow.test.js',
  'phase3s_staging_demo_print.test.js',
  'phase3t_demo_access_lock.test.js',
  'phase2_1_concurrency_and_security_remediation.test.js',
  'remote_customer_connectivity.test.js',
  'phase1_and_2_payment_readiness.test.js',
  'phase1c_queue_cleanup_safety.test.js',
  'phase3q_pdf_preview_recovery.test.js',
  'batch1_payment_safety.test.js',
  'batch2_frontend_support_and_isolation.test.js',
  'gate2a_staging_and_readonly.test.js'
];

const auditResults = [];

for (const file of legacyFiles) {
  const fullPath = path.join(testsDir, file);
  console.log(`\n======================================================`);
  console.log(`INVESTIGATING: ${file}`);
  console.log(`======================================================`);

  const content = fs.readFileSync(fullPath, 'utf8');

  // Extract header comment
  const docMatch = content.match(/\/\*\*[\s\S]*?\*\//);
  const docstring = docMatch ? docMatch[0].replace(/\r/g, '').split('\n').slice(0, 10).join('\n') : '';

  // Identify dependencies
  const dbIsolationType = content.includes('assertDisposableDb')
    ? 'Enforces assertDisposableDb() strictly against 127.0.0.1:5433 printgo_disposable_target'
    : (content.includes('printgo_staging_db')
      ? 'Targets printgo_staging_db on 127.0.0.1:5433'
      : (content.includes('new PrismaClient') ? 'Connects to DATABASE_URL via Prisma' : 'In-memory / mock'));

  const usesMockGateway = content.includes('axios') || content.includes('mock') || content.includes('sandbox');
  const hasExternalNetworkCalls = !usesMockGateway && (content.includes('fetch(') || content.includes('http.request'));

  // Determine safe env overrides
  const env = {
    ...process.env,
    NODE_ENV: 'test',
    JWT_SECRET: process.env.JWT_SECRET || 'phase11_investigation_jwt_secret_321',
    DATABASE_URL: file.includes('staging') || file.includes('remote')
      ? 'postgresql://postgres@127.0.0.1:5433/printgo_staging_db?schema=public'
      : 'postgresql://postgres@127.0.0.1:5433/printgo_disposable_target?schema=public',
    CASHFREE_ENV: 'sandbox',
    ALLOW_EPHEMERAL_STORAGE_FOR_TESTS: 'true'
  };

  console.log(`DB Isolation: ${dbIsolationType}`);
  console.log(`External Network Calls: ${hasExternalNetworkCalls ? 'YES (RISK)' : 'NONE (MOCKED/ISOLATED)'}`);

  // Run standalone execution with node
  console.log(`Executing: node tests/${file} ...`);
  const startTime = Date.now();
  const run = spawnSync(process.execPath, [path.join(testsDir, file)], {
    cwd: backendDir,
    env,
    encoding: 'utf8',
    timeout: 30000 // 30s timeout per script
  });
  const durationMs = Date.now() - startTime;

  const stdout = run.stdout || '';
  const stderr = run.stderr || '';
  const exitCode = run.status;

  // Extract pass / fail lines
  const passMatches = stdout.match(/(PASS|passed|✅|\bOK\b).*$/gmi) || [];
  const failMatches = (stdout + '\n' + stderr).match(/(FAIL|failed|❌|Error:).*$/gmi) || [];

  console.log(`Exit Code: ${exitCode} (${durationMs}ms)`);
  console.log(`Pass count indications: ${passMatches.length}, Fail count indications: ${failMatches.length}`);

  // Save log artifact
  const logFile = path.join(evidenceDir, `${file}.log`);
  fs.writeFileSync(logFile, `=== EXECUTION LOG FOR ${file} ===\nExit Code: ${exitCode}\nDuration: ${durationMs}ms\n\n--- STDOUT ---\n${stdout}\n\n--- STDERR ---\n${stderr}`);

  auditResults.push({
    file,
    lines: content.split('\n').length,
    docstringSummary: docstring.split('\n').slice(0, 4).join(' '),
    runnerType: 'Standalone Node.js Runner',
    dbIsolationType,
    hasExternalNetworkCalls,
    exitCode,
    durationMs,
    passMatchesCount: passMatches.length,
    failMatchesCount: failMatches.length,
    samplePass: passMatches.slice(0, 3),
    sampleFail: failMatches.slice(0, 3),
    logPath: logFile
  });
}

fs.writeFileSync(
  path.join(evidenceDir, 'legacy_scripts_audit.json'),
  JSON.stringify(auditResults, null, 2)
);

console.log('\nAll 19 legacy test scripts investigated and recorded to evidence directory.');
