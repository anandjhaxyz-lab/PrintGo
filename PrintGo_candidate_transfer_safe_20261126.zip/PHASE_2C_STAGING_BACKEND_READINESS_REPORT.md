# PRINTGO PHASE 2C — STAGING BACKEND READINESS AUDIT REPORT

**Target Service:** `printgo-backend-staging` (`srv-dbqpapon74is73csbc80`)  
**Backend URL:** `https://printgo-backend-staging.onrender.com`  
**Candidate Baseline Commit:** `dfcbe42b5431cb3c0e932e178d02393beb221f08`  
**Host PC:** `DESKTOP-QB6Q3BC`  
**Execution Timestamp:** 2026-11-24T00:47:30+05:30  
**Audit Mode:** STRICT READ-ONLY (No configuration changes, no migrations, no secrets exposed)  

---

## 1. Backend Health & Readiness Probes

Live probe execution against `https://printgo-backend-staging.onrender.com`:

| Endpoint | HTTP Status | Response Payload | Status |
| :--- | :---: | :--- | :---: |
| `GET /api/health` | **`200 OK`** | `{"status":"ok","timestamp":"2026-11-23T19:10:48.667Z"}` | **HEALTHY** |
| `GET /api/ready` | **`200 OK`** | `{"status":"ready","checks":{"database":"ready","redis":"ready","printQueue":"ready","uploadWorker":"ready","uploadQueueEvents":"ready","socketIoRedisAdapter":"disabled"}}` | **HEALTHY** |

The underlying PostgreSQL database, Redis cluster, BullMQ print queue, and upload worker are all active and healthy.

---

## 2. Deployed Commit SHA vs Approved Baseline

- **Approved Multi-Printer Baseline:** `dfcbe42b5431cb3c0e932e178d02393beb221f08`  
  *(Author: Anand, Date: 2026-11-21T19:05:30Z, Merge of PRs #9–#15)*
- **Currently Deployed Backend Commit:** `cb4859550276bc73f1d4d3c07fc9fe011560878e`  
  *(Commit message: `fix(analytics): show clean payment method labels in overview chart`, 2026-11-19)*
- **Comparison & Root Cause:**  
  On 19-Nov-2026, Render Auto-Deploy was disabled on service `srv-dbqpapon74is73csbc80` (`autoDeploy=no`, Event ID: `evt-dbvg10jm8hqs739sn640`) as a safeguard against uncoordinated schema migrations. Consequently, commit `dfcbe42b` has **not been deployed** to Render Staging.

---

## 3. Feature Flag Status: `ENABLE_MULTI_PRINTER_DISPATCH`

- **Existence in Render Environment:** **MISSING / NOT CONFIGURED**.
- **Code Default Value:** Strict fail-closed comparison `process.env.ENABLE_MULTI_PRINTER_DISPATCH === 'true'`. When undefined or missing, it evaluates to `false`.
- **Runtime Impact:**
  - Device QR endpoints throw `503 Service Unavailable`: *"This physical printer QR is not active yet."*
  - Multi-printer dispatch routing is disabled.
- **Exposure:** Flag is not exposed in public health/ready endpoints; admin endpoints require authentication (`401`). No secret values were exposed.

---

## 4. Actual Staging Database Migration History

The remote PostgreSQL 18 database `_prisma_migrations` ledger currently records exactly **12 applied migrations**:

1. `20261110000000_init`
2. `20261110000001_financial_ledger_and_audit`
3. `20261110000002_pricing_and_invoices`
4. `20261110000003_invoice_lifecycle_and_credit_notes`
5. `20261110000004_refunds_and_reconciliation`
6. `20261110000005_add_istest_to_printjob`
7. `20261110000006_add_printer_qr`
8. `20261110000007_add_active_printer_qr_unique_index`
9. `20261111000008_add_advertisements`
10. `20261113000009_machine_wise_advertisements`
11. `20261118000010_add_machine_connection_type`
12. **`20261118000011_add_cash_payment_mode_and_confirmation`** *(Latest applied)*

---

## 5. Pending Migration Numbers

All five multi-printer migrations in candidate `dfcbe42b` are **PENDING (UNAPPLIED)** on Staging:

| Migration Number | Migration Directory Name | Purpose | Status on Staging |
| :-: | :--- | :--- | :---: |
| **00012** | `20261119000012_add_printer_devices` | Creates `PrinterDevice` table; adds `printerDeviceId` to `PrinterQr`, `Session`, `PrintJob`, `PrinterStatus`. Backfills 1 legacy device per Machine. | **PENDING** |
| **00013** | `20261119000013_printer_discovery_approval` | Creates `PrinterDiscovery` table for discovery inventory and approval tracking. | **PENDING** |
| **00014** | `20261119000014_printer_device_qr_uniqueness` | Replaces Machine active QR unique index with `(printerDeviceId, isActive)` index. | **PENDING** |
| **00015** | `20261119000015_printer_device_dispatch_leases` | Creates `PrinterDeviceDispatchLease` table for cross-device queue leases. | **PENDING** |
| **00016** | `20261119000016_print_job_queue_snapshot` | Adds immutable `windowsPrinterNameSnapshot` and `printerDriverSnapshot` to `PrintJob`. | **PENDING** |

---

## 6. Prisma Schema & API Compatibility

### Prisma Schema Compatibility:
- **In Candidate Baseline (`dfcbe42b`):** Defines `PrinterDevice`, `PrinterDiscovery`, and `PrinterDeviceDispatchLease`, with relationships to `Machine`, `PrinterQr`, `Session`, `PrintJob`, and `PrinterStatus`.
- **In Deployed Backend (`cb48595`):** These models do not exist in the deployed schema or database. Querying them throws SQL errors (`relation "PrinterDevice" does not exist`).

### Admin API Compatibility:
- **In Candidate Baseline (`dfcbe42b`):**
  - `GET /api/admin/printer-discoveries`
  - `GET /api/admin/printer-devices`
  - `POST /api/admin/printer-discoveries/:id/approve`
  - `POST /api/admin/printer-devices/:id/remap`
  - `POST /api/admin/printer-devices/:id/disable` & `/enable`
  - `POST /api/admin/printer-devices/:id/qr`
- **In Deployed Backend (`cb48595`):** These routes are not declared in `admin.routes.js`. Requests return `401 Unauthorized` without auth and `404 Not Found` with auth.

### Candidate Agent Protocol Support:
- **In Candidate Baseline (`dfcbe42b`):** Full handshake via `printerAgentProtocol.service.js` (`agent:hello`, `agent:hello:ack`, `printer:discovery:report`).
- **In Deployed Backend (`cb48595`):** `printerAgentProtocol.service.js` is missing. The Socket.IO server only handles legacy single-printer events and ignores multi-device handshakes.

---

## 7. Missing Environment Variables & Dependencies

1. **`ENABLE_MULTI_PRINTER_DISPATCH`**: Missing on Render service `srv-dbqpapon74is73csbc80` (must be set to `true`).
2. **Database Schema State**: Migrations `00012` through `00016` must be applied (`npx prisma migrate deploy`).
3. **Service Deployment**: Render service must be deployed from commit `dfcbe42b5431cb3c0e932e178d02393beb221f08`.

---

## 8. P0 / P1 Blockers Summary

### P0 Blockers (Prevent Registration & Dispatch):
1. **[P0-1] Deployed Commit Mismatch:** Staging backend is running `cb4859550276bc73f1d4d3c07fc9fe011560878e` instead of `dfcbe42b5431cb3c0e932e178d02393beb221f08`.
2. **[P0-2] Database Migrations Unapplied:** Migrations `00012` through `00016` are pending in PostgreSQL.
3. **[P0-3] Feature Flag Disabled:** `ENABLE_MULTI_PRINTER_DISPATCH=true` is missing on Render.

### P1 Blockers (Operational & UI Completeness):
1. **[P1-1] Staging Admin Frontend Alignment:** The Admin Dashboard web UI needs deployment from `dfcbe42b` to expose the new Printer Discoveries and Printer Devices management views.
2. **[P1-2] Host Printer Power State:** The 3 target printers on `DESKTOP-QB6Q3BC` report `WorkOffline: true` because they are powered off overnight; they must be powered on before approval.

---

## 9. Staging Registration Readiness Verdict

### **VERDICT: BLOCKED**

The candidate multi-printer agent code and host discovery are 100% validated on `DESKTOP-QB6Q3BC`, but **the Staging Backend is currently blocked** until:
1. Render service `srv-dbqpapon74is73csbc80` is deployed with commit `dfcbe42b5431cb3c0e932e178d02393beb221f08`.
2. Pre-deploy command `npx prisma migrate deploy` executes migrations `00012` through `00016`.
3. `ENABLE_MULTI_PRINTER_DISPATCH=true` is set in the Render Staging environment variables.
