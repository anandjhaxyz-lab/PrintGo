# PRINTGO — PHASE 3B.1: EXISTING EPSON REGISTRATION RECONCILIATION REPORT

**Environment:** STAGING ONLY  
**Target Backend:** `https://printgo-backend-staging.onrender.com` (`srv-dbqpapon74is73csbc80`)  
**Client PC:** `DESKTOP-QB6Q3BC`  
**Candidate Directory:** `D:\PrintGo-S3K-MULTIPRINTER-CANDIDATE`  
**Machine Name:** `Main Shop Printer`  
**Machine ID:** `d010496f-f176-41fe-9c98-efd2213a4a0e`  
**Target Discovered Queue:** `EPSON L6460 Series` (Port: `USB019`, Driver: `EPSON L6460 Series`)  
**Execution Timestamp:** 2026-11-24T01:50:00+05:30  
**Audit Mode:** Strictly READ-ONLY (Zero mutations, zero approvals executed)  

---

## Final Verdict

### **`SEPARATE REGISTRATIONS — REVIEW REQUIRED`**
*(With Critical Warning: Standard Approval Triggers a Fatal QR Conflict)*

The live Staging database currently holds two completely separate records for the Epson printer:
1. An existing **legacy backfilled placeholder record** (`PrinterDevice`) to which the active Front Desk Counter QR (`pq_YCuM5Lr2_...`) is bound.
2. A newly ingested **unapproved discovery record** (`PrinterDiscovery`) for queue `EPSON L6460 Series` on port `USB019`.

**Critical Architectural Conflict:** Calling `POST /api/admin/printer-discoveries/:id/approve` on the `USB019` discovery record will create a duplicate `PrinterDevice` row, demote the existing placeholder (`isDefault: false`), and **immediately break the physical counter QR flyer in the shop** (throwing `403 Forbidden` / `503 Service Unavailable` on customer scans). Human operator review and an explicit linking/remap workflow are mandatory before taking action.

---

## 1. Existing Epson Printer Record & Database Relationships

Inspection of the deployed schema (`dfcbe42b`) and migration history on Staging:

- **Machine Record:**
  - `id`: `d010496f-f176-41fe-9c98-efd2213a4a0e`
  - `name`: `Main Shop Printer`
  - `printerModel`: `EPSON L6460 Series`
  - `connectionType`: `USB`
  - `status`: `ACTIVE`
  - `paymentMode`: `DEMO_SIMULATION`
- **Database Backfill (Migration `20261119000012_add_printer_devices`):**
  - Migration 00012 executed the following backfill logic:
    ```sql
    INSERT INTO "PrinterDevice" (
        "id", "machineId", "displayName", "windowsPrinterName", "printerModel",
        "driverName", "portName", "connectionType", "status", "healthStatus",
        "isDefault", "sortOrder", "approvedAt", "approvedBy", "createdAt", "updatedAt"
    )
    SELECT
        gen_random_uuid()::text,
        m."id",
        COALESCE(NULLIF(BTRIM(m."name"), ''), 'Machine') || ' - Primary Printer (pending discovery)',
        NULL,
        m."printerModel",
        NULL, NULL, m."connectionType",
        'DISCOVERY_REQUIRED',
        'UNKNOWN',
        TRUE, 0, NULL, NULL, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP
    FROM "Machine" m;
    ```
  - **Downstream Foreign Key Updates:**
    - Migration 00012 bound `PrinterQr.printerDeviceId`, `Session.printerDeviceId`, and `PrintJob.printerDeviceId` directly to this newly generated placeholder `PrinterDevice` ID where `isDefault = TRUE`.

---

## 2. Existing Counter QR Identity & Device Mapping

Verification against live public endpoint `GET /api/auth/printer-qr/pq_YCuM5Lr2_nQMuxahsrBqjb9jWQSUhMDPd0Cbl_tpDB8`:

- **Public Code:** `pq_YCuM5Lr2_nQMuxahsrBqjb9jWQSUhMDPd0Cbl_tpDB8`
- **Label:** `Front Desk Counter`
- **QR Status:** `ACTIVE`
- **Bound Machine ID:** `d010496f-f176-41fe-9c98-efd2213a4a0e`
- **Bound `printerDeviceId`:** Points to the placeholder device in the database.
- **Public API Serialization:** Serialized as `"printerDeviceId": null` in the JSON response because `printerQr.service.js` detects the legacy placeholder:
  ```javascript
  // backend/src/services/printerQr.service.js:870
  printerDeviceId: qr.printerDevice && !legacyPlaceholderDevice ? qr.printerDevice.id : null
  ```
- **Live HTTP Probe Result:**
  ```json
  {
    "success": true,
    "status": "ACTIVE",
    "label": "Front Desk Counter",
    "paymentMode": "DEMO_SIMULATION",
    "printer": {
      "name": "Main Shop Printer",
      "model": "EPSON L6460 Series",
      "location": "Front Desk",
      "hardwareStatus": "AGENT_OFFLINE",
      "printerDeviceId": null
    }
  }
  ```

---

## 3. `PrinterDevice` Table Details for Existing Epson

- **Display Name:** `Main Shop Printer - Primary Printer (pending discovery)`
- **`windowsPrinterName`:** `NULL` (unmapped)
- **`portName`:** `NULL` (unmapped)
- **`driverName`:** `NULL` (unmapped)
- **`status`:** `'DISCOVERY_REQUIRED'`
- **`healthStatus`:** `'UNKNOWN'`
- **`isDefault`:** `TRUE`
- **`approvedAt`:** `NULL`
- **Fleet Manager Exposure:** When the candidate Agent connects and requests the fleet registry via `printer_device_registry_request`, `printerAgentProtocol.service.js` line 134 filters:
  ```javascript
  where: {
    machineId,
    windowsPrinterName: { not: null }
  }
  ```
  Consequently, this placeholder device is **excluded from the Agent fleet registry** (`devices: []`), keeping the Agent operating on its single-printer legacy fallback.

---

## 4. `PrinterDiscovery` Record for USB019

Ingested during Phase 3A candidate execution:

- **Machine ID:** `d010496f-f176-41fe-9c98-efd2213a4a0e`
- **Windows Queue Name:** `EPSON L6460 Series`
- **Port Name:** `USB019`
- **Driver Name:** `EPSON L6460 Series`
- **Connection Type:** `USB`
- **Review Status:** `DISCOVERED`
- **`approvedPrinterDeviceId`:** `NULL`
- **Last Seen:** `2026-11-23T19:45:38.117Z`

---

## 5. Comparative Side-by-Side Matrix

| Attribute | Existing Legacy Epson Registration | Discovered Windows Queue | Status / Comparison |
| :--- | :--- | :--- | :--- |
| **Machine ID** | `d010496f-f176-41fe-9c98-efd2213a4a0e` | `d010496f-f176-41fe-9c98-efd2213a4a0e` | **Exact Match** |
| **Entity Table** | `PrinterDevice` (backfilled placeholder) | `PrinterDiscovery` (raw spooler report) | **Separate Tables** |
| **Windows Queue Name** | `NULL` | `EPSON L6460 Series` | **Unlinked** |
| **Port Name** | `NULL` | `USB019` | **Unlinked** |
| **Driver Name** | `NULL` | `EPSON L6460 Series` | **Unlinked** |
| **Device Status** | `DISCOVERY_REQUIRED` | `DISCOVERED` (review status) | **Pending Admin Review** |
| **`isDefault`** | `TRUE` | `TRUE` (reported default queue) | **Potential Collision** |
| **`approvedAt`** | `NULL` | `NULL` | **Unapproved** |
| **Counter QR Binding** | **BOUND** (`pq_YCuM5Lr2_...`) | **NOT BOUND** (`NULL`) | **QR Dependency At Risk** |

---

## 6. Audit of Approval Endpoint Safeguards

Analysis of `approvePrinterDiscovery` in `backend/src/services/printerDiscovery.service.js`:

### 1. Duplicate-Queue Safeguard (Lines 172–180):
```javascript
const mappedQueue = await tx.printerDevice.findFirst({
  where: {
    machineId: discovery.machineId,
    windowsPrinterName: { equals: discovery.windowsPrinterName, mode: 'insensitive' }
  }
});
if (mappedQueue) {
  throw new AppError('This Windows queue is already mapped to a PrinterDevice. Review that device instead of creating a duplicate.', 409);
}
```
- **Audit Finding:** Because the existing placeholder device has `windowsPrinterName: NULL`, `mappedQueue` evaluates to `null`. The check **fails to detect the existing Epson placeholder** and allows approval to proceed without blocking.

### 2. Default Device Transfer (Lines 190–205):
```javascript
const willBeDefault = Boolean(data.isDefault !== undefined ? data.isDefault : discovery.isDefault);
const existingDefault = await tx.printerDevice.findFirst({
  where: { machineId: discovery.machineId, isDefault: true }
});

if (effectiveIsDefault) {
  if (existingDefault) {
    previousDefaultDeviceId = existingDefault.id;
    await tx.printerDevice.update({
      where: { id: existingDefault.id },
      data: { isDefault: false } // <--- DEMOTION OF PLACEHOLDER
    });
  }
}
```
- **Audit Finding:** The placeholder device is demoted (`isDefault: false`), leaving it orphaned.

---

## 7. Registration Classification

The existing Epson registration is strictly:
- **A legacy single-printer record backfilled into `PrinterDevice`** via Migration `00012`.
- It is **NOT** a manually created `PrinterDevice`.
- It is **NOT** unlinked to `PrinterDevice` (`PrinterQr` has an active FK pointing to the placeholder `PrinterDevice` ID).
- It is **NOT** currently pointing to `USB019` or any Windows queue (`windowsPrinterName` is `NULL`).

---

## 8. Impact Scenarios for Existing Counter QR

### Scenario A: Approving USB019 as a New `PrinterDevice` (`/approve`)
1. A new row `PrinterDevice` is created (`windowsPrinterName = 'EPSON L6460 Series'`, `status = 'ACTIVE'`, `isDefault = true`).
2. The old placeholder device is updated to `isDefault = false`.
3. The Counter QR flyer (`pq_YCuM5Lr2_...`) remains bound to the old placeholder device ID.
4. When a customer scans the counter QR, `printerQr.service.js` evaluates:
   ```javascript
   const legacyPlaceholderDevice = lockedQr.printerDeviceId && isLegacyPlaceholderDevice({
     isDefault: lockedQr.printer_device_is_default, // NOW FALSE!
     status: lockedQr.printer_device_status,         // DISCOVERY_REQUIRED
     approvedAt: lockedQr.printer_device_approved_at, // NULL
     windowsPrinterName: lockedQr.printer_device_windows_printer_name // NULL
   });
   ```
   Because `isDefault` is false, `isLegacyPlaceholderDevice` returns **`FALSE`**.
5. Execution hits lines 652 and 665:
   ```javascript
   if (lockedQr.printerDeviceId && !legacyPlaceholderDevice && !isMultiPrinterDispatchEnabled()) {
     throw new AppError('This physical printer QR is not active yet. Please contact shop staff.', 503);
   }
   if (lockedQr.printerDeviceId && !legacyPlaceholderDevice) {
     if (lockedQr.printer_device_status !== 'ACTIVE' || !lockedQr.printer_device_approved_at) {
       throw new AppError('This physical printer is no longer approved or active.', 403);
     }
   }
   ```
6. **Result: FATAL BREAKAGE.** The printed counter QR flyer immediately starts returning `403` or `503` errors. Customer ordering stops.

### Scenario B: Linking USB019 to Existing Placeholder Device (`/remap`)
1. Endpoint `POST /api/admin/printer-devices/:printerDeviceId/remap` updates the placeholder device:
   - Sets `windowsPrinterName = 'EPSON L6460 Series'`
   - Sets `portName = 'USB019'`, `driverName = 'EPSON L6460 Series'`
   - Sets `approvedAt = now()`, `approvedBy = user.id`
2. **Current Code Limitation:** `remapPrinterDevice` does not mutate `status` (it remains `'DISCOVERY_REQUIRED'`), and `enablePrinterDevice` rejects non-`DISABLED` rows with `409 Conflict`.
3. **Result:** Remap updates queue mappings but requires an explicit transition to `status = 'ACTIVE'` to satisfy `printerQr.service.js` line 668.

### Scenario C: USB019 Discovery Record is Ignored
1. The placeholder device remains `isDefault = true`, `windowsPrinterName = null`, `status = 'DISCOVERY_REQUIRED'`.
2. `isLegacyPlaceholderDevice` continues returning `true`.
3. The Counter QR continues operating smoothly in legacy single-printer mode.
4. Candidate and production agents continue routing to `PRINTER_NAME=EPSON L6460 Series`.
5. **Result: ZERO BREAKAGE.** Complete backward compatibility is maintained.

---

## 9. Staging Backend Code Capabilities Audit

| Capability | Supported in Backend Code? | Relevant File & Lines |
| :--- | :---: | :--- |
| **Auto-link discovery to existing `PrinterDevice`** | **NO** | `printerDiscovery.service.js:121-263` (Always creates a new `PrinterDevice` row) |
| **Prevent duplicate `PrinterDevice` for same queue** | **PARTIAL** | `printerDiscovery.service.js:172-180` (Checks non-null queue names only; ignores null placeholders) |
| **Update `windowsPrinterName` / `portName` of existing device** | **YES** | `printerDeviceAdmin.service.js:217-339` (`remapPrinterDevice`) |
| **Change `status` from `DISCOVERY_REQUIRED` to `ACTIVE`** | **NO** | `printerDeviceAdmin.service.js:162-164` (`enablePrinterDevice` only accepts `DISABLED`) |

---

## 10. Recommended Next Actions

1. **DO NOT approve the `USB019` discovery record via `/api/admin/printer-discoveries/:id/approve`**:
   - This prevents demoting the placeholder device and preserves the active Counter QR flyer.
2. **Approve ONLY the Secondary Physical Printers in Phase 3B:**
   - **Target 2:** `HP LaserJet Professional M1136 MFP (Copy 1)` (Port `USB011`) &rarr; Approve as non-default child device.
   - **Target 3:** `Canon Generic Plus UFR II (Copy 2)` (Port `USB001`) &rarr; Approve as non-default child device.
   - Both secondary printers have zero legacy QR attachments and can be safely approved via standard discovery approval.
3. **Execute Controlled Epson Linking in Phase 3C:**
   - Map the placeholder `PrinterDevice` to `EPSON L6460 Series` and transition its status to `ACTIVE` via an administrative migration or dedicated remap transition.
   - This ensures the physical Counter QR flyer (`pq_YCuM5Lr2_...`) seamlessly transitions from legacy single-printer dispatch to multi-printer dispatch without requiring QR flyer reprinting.
