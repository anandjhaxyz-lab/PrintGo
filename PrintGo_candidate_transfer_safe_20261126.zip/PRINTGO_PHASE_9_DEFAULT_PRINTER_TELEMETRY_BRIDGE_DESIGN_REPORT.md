# PRINTGO — PHASE 9: DEFAULT PRINTER TELEMETRY BRIDGE DESIGN REVIEW

**Execution Mode:** READ-ONLY DESIGN REVIEW  
**Workspace:** `D:\PrintGo-S3K-MULTIPRINTER-CANDIDATE`  
**Backend:** Staging  
**Agent PID:** `10940` (Running, untouched)  
**Target Machine ID:** `d010496f-f176-41fe-9c98-efd2213a4a0e` (`Main Shop Printer`)  
**Target Default Device ID:** `619665e1-3c64-44eb-8f57-cb8c3c895e9b` (`EPSON L6460 Series`, `isDefault: true`)  
**Public QR Flyer:** `pq_YCuM5Lr2_nQMuxahsrBqjb9jWQSUhMDPd0Cbl_tpDB8`

---

## 1. Executive Summary & Objective

Phase 8 proved why the customer QR endpoint reports `isOnline: false` and `hardwareStatus: "UNKNOWN"` despite the candidate Agent PID `10940` successfully monitoring the Epson printer over RAW TCP 9100:
1. When child monitors send `printerDeviceId`, [backend/src/socket.js:304](file:///D:/PrintGo-S3K-MULTIPRINTER-CANDIDATE/backend/src/socket.js#L304) diverts telemetry into `handlePrinterDeviceTelemetry()` and returns immediately.
2. It updates `PrinterDevice.healthStatus = 'ONLINE'`, but **never inserts into the legacy `PrinterStatus` table**.
3. The counter QR flyer `pq_YCuM5Lr2...` is a Machine-level QR (`printerDeviceId: null`).
4. Machine availability evaluates `machine.printerStatuses`. Because no new rows were inserted since Phase 7, the legacy telemetry exceeded the 180s stale window (`TELEMETRY_STALE_WINDOW_MS`), failing closed as `UNKNOWN`.
5. Stored `'OK'` values for paper/toner originate from the old legacy ternary operator in `socket.js:329` and schema defaults.

**Objective of Phase 9:**  
Review the design for **Option A**: safely bridging device-level telemetry for the **active default printer** to the Machine-level availability stream while enforcing all 10 mandatory design safeguards.

---

## 2. Proposed Exact Event Flow

```
                                      AGENT (PID 10940)
                                      -----------------
                     SpoolerMonitor.emitStatus('printer_status_update', payload)
                     Includes: printerDeviceId, printerName, isError, telemetry
                                             │
                                             ▼ (WebSocket)
                                  BACKEND socket.js:299
                                  ---------------------
                            socket.on('printer_status_update')
                                             │
                             [status.printerDeviceId present?]
                                             │
                                             ▼ YES
                             handlePrinterDeviceTelemetry(...)
                       (backend/src/services/printerAgentProtocol.service.js)
                                             │
             ┌───────────────────────────────┴───────────────────────────────┐
             │ 1. Validate Socket, Protocol & Identity                       │
             │    - socket.userType === 'printer'                            │
             │    - socket.agentProtocol.supportsMultiPrinter === true       │
             │    - device belongs to socket.machineId                       │
             │    - status.printerName matches device.windowsPrinterName     │
             └───────────────────────────────┬───────────────────────────────┘
                                             │
             ┌───────────────────────────────┴───────────────────────────────┐
             │ 2. Always Update Device Health                                │
             │    - Update PrinterDevice.healthStatus ('ONLINE', 'ERROR'...) │
             │    - Update PrinterDevice.lastTelemetryAt = eventTimestamp    │
             │    - Emit 'printer_device_status_update' to admin rooms       │
             └───────────────────────────────┬───────────────────────────────┘
                                             │
                                 [Is Bridge Eligible?]
                                 - device.status === 'ACTIVE'
                                 - device.approvedAt != null
                                 - device.isDefault === true
                                             │
                      ┌──────────────────────┴──────────────────────┐
                   NO │ (Secondary Printer)                      YES│ (Default Epson)
                      ▼                                             ▼
             Skip Machine Bridge                           Execute Bridge
             Return { accepted: true,                      1. Validate & Parse Telemetry
               bridged: false }                               - Validate timestamp & check freshness
                                                              - Extract actual paperStatus & tonerStatus
                                                           2. Update Machine Metadata & Heartbeat
                                                              - Machine.lastOnline = now
                                                              - Machine.printerModel = device.displayName
                                                              - Machine.connectionType = status.connectionType
                                                           3. Persist to PrinterStatus Table
                                                              - machineId: socket.machineId
                                                              - printerDeviceId: device.id
                                                              - isOnline: !status.isError
                                                              - paperStatus: validPaperStatus
                                                              - tonerStatus: validTonerStatus
                                                              - timestamp: eventDate
                                                           4. Broadcast Machine Availability
                                                              - io.to(`machine_${machineId}`).emit(...)
                                                              - io.to(`company_${companyId}`).emit(...)
```

---

## 3. Default-Printer Selection and Validation Logic

### 3.1 Device Query Expansion
In [backend/src/services/printerAgentProtocol.service.js:391-401](file:///D:/PrintGo-S3K-MULTIPRINTER-CANDIDATE/backend/src/services/printerAgentProtocol.service.js#L391-L401), expand the `prisma.printerDevice.findFirst` selection:
```javascript
const device = await prisma.printerDevice.findFirst({
  where: {
    id: printerDeviceId,
    machineId: socket.machineId
  },
  select: {
    id: true,
    displayName: true,
    windowsPrinterName: true,
    printerModel: true,
    isDefault: true,
    status: true,
    approvedAt: true,
    machine: { select: { id: true, companyId: true, name: true } }
  }
});
```

### 3.2 Bridge Eligibility Predicate
A device is eligible to bridge to the machine-level availability stream if and only if:
```javascript
const isEligibleDefaultBridge = Boolean(
  device.isDefault === true &&
  device.status === 'ACTIVE' &&
  device.approvedAt !== null &&
  device.windowsPrinterName !== null
);
```

### 3.3 Strict Isolation Rules
- **Rule 1 (Secondary Device Exclusion):** If `device.isDefault === false` (e.g., HP M1136 or Canon Copy 2), `isEligibleDefaultBridge` evaluates to `false`. Telemetry is recorded in `PrinterDevice`, but **never touches `Machine` or `PrinterStatus`**.
- **Rule 2 (Approval Invariant):** If a default device is disabled (`status: 'DISABLED'`) or unapproved (`approvedAt: null`), bridging is rejected.
- **Rule 3 (Identity Invariant):** If `device.windowsPrinterName` does not match `status.printerName` (case-insensitive), the handler rejects the telemetry with `QUEUE_IDENTITY_MISMATCH` before reaching the bridge.

---

## 4. Database Fields to be Updated

### 4.1 Table `PrinterDevice` (Always updated for all approved devices)
- `healthStatus`: `'ONLINE'`, `'PAPER_OUT'`, `'JAMMED'`, `'OFFLINE'`, or `'ERROR'`
- `lastTelemetryAt`: Event timestamp (`DateTime`)

### 4.2 Table `Machine` (Updated ONLY when `isEligibleDefaultBridge === true`)
- `lastOnline`: `new Date()` (extends machine heartbeat)
- `printerModel`: `device.printerModel || device.displayName`
- `connectionType`: `status.connectionType` (`'Network'` or `'USB'`)

### 4.3 Table `PrinterStatus` (Inserted ONLY when `isEligibleDefaultBridge === true`)
- `machineId`: `socket.machineId`
- `printerDeviceId`: `device.id` (Existing relation in schema, previously left null)
- `isOnline`: `!status.isError` (Boolean)
- `paperStatus`: Preserved actual status (`'OK'`, `'LOW'`, `'OUT'`, `'UNKNOWN'`)
- `tonerStatus`: Preserved actual status (`'OK'`, `'LOW'`, `'EMPTY'`, `'UNKNOWN'`)
- `jamStatus`: Boolean (`status.errorMessage.includes('Jam')`)
- `connectionType`: `status.connectionType`
- `timestamp`: Event timestamp (`DateTime`)

> [!NOTE]
> All columns above exist in [backend/prisma/schema.prisma:480-498](file:///D:/PrintGo-S3K-MULTIPRINTER-CANDIDATE/backend/prisma/schema.prisma#L480-L498). **Zero schema migrations or SQL alterations are required.**

---

## 5. Error, UNKNOWN State, and Hardware Error Handling

### 5.1 UNKNOWN Paper & Toner Preservation (Safeguard 5)
In the existing implementation ([backend/src/socket.js:329](file:///D:/PrintGo-S3K-MULTIPRINTER-CANDIDATE/backend/src/socket.js#L329)), paper status was hardcoded via:
`paperStatus: status.errorMessage === 'Out of Paper' ? 'OUT' : 'OK'` (destroying `'UNKNOWN'`).

**Proposed Canonical Resolution:**
```javascript
const sourceTelemetry = isPlainObject(status.telemetry) ? status.telemetry : {};
const rawPaper = typeof sourceTelemetry.paperStatus === 'string'
  ? sourceTelemetry.paperStatus.toUpperCase().trim()
  : '';
const rawToner = typeof sourceTelemetry.tonerStatus === 'string'
  ? sourceTelemetry.tonerStatus.toUpperCase().trim()
  : '';

// Explicitly allow UNKNOWN and preserve agent telemetry
const validPaperStatus = ['OK', 'LOW', 'OUT', 'UNKNOWN'].includes(rawPaper)
  ? rawPaper
  : (message.includes('out of paper') || message.includes('paper out') ? 'OUT' : 'UNKNOWN');

const validTonerStatus = ['OK', 'LOW', 'EMPTY', 'UNKNOWN'].includes(rawToner)
  ? rawToner
  : 'UNKNOWN';
```
- **Guarantee:** If the Agent sends `paperStatus: 'UNKNOWN'` (e.g. Epson on TCP/IP port monitor with WMI Unknown), it is stored as `'UNKNOWN'` in PostgreSQL. It is **never converted to `'OK'`**.

### 5.2 Hardware Errors & Offline States (Safeguards 6 & 7)
- **WorkOffline === true / TCP Timeout / TCP Refused:**
  - `status.isError: true`, `errorMessage: 'Printer Offline'` or `'Network Printer Unreachable'`
  - `healthStatus: 'OFFLINE'`, `isOnline: false`
  - Customer API evaluates: `hardwareStatus: 'OFFLINE'`, `statusMessage: 'Physical Printer Offline'`, `isReady: false`.
- **Out of Paper:**
  - `status.isError: true`, `errorMessage: 'Out of Paper'`
  - `healthStatus: 'PAPER_OUT'`, `isOnline: false`, `paperStatus: 'OUT'`
  - Customer API evaluates: `hardwareStatus: 'PAPER_OUT'`, `statusMessage: 'Out of Paper'`, `isReady: false`.
- **Paper Jam:**
  - `status.isError: true`, `errorMessage: 'Paper Jam'`
  - `healthStatus: 'JAMMED'`, `isOnline: false`, `jamStatus: true`
  - Customer API evaluates: `hardwareStatus: 'JAMMED'`, `statusMessage: 'Paper Jam'`, `isReady: false`.
- **WMI Unknown (DetectedErrorState = 0) with verified TCP:**
  - `status.isError: false`, `errorMessage: ''`
  - `healthStatus: 'ONLINE'`, `isOnline: true`, `statusMessage: 'Printer Ready'`
  - `paperStatus: 'UNKNOWN'`, `tonerStatus: 'UNKNOWN'`.

---

## 6. Idempotency, Timestamp Validation, and Stale Event Strategy

### 6.1 Timestamp Parsing & Clock Skew Rejection
- Parse `status.timestamp`:
  ```javascript
  const eventTimeMs = Date.parse(status.timestamp);
  const nowMs = Date.now();
  const MAX_CLOCK_SKEW_FUTURE_MS = 60 * 1000; // 60 seconds
  const MAX_EVENT_AGE_MS = 180 * 1000;         // 180 seconds

  let eventDate = new Date();
  if (Number.isFinite(eventTimeMs)) {
    if (eventTimeMs > nowMs + MAX_CLOCK_SKEW_FUTURE_MS) {
      logger?.warn?.(`Rejected future-skewed telemetry timestamp from Machine ${socket.machineId}`);
      eventDate = new Date(); // fallback to server receipt time
    } else if (nowMs - eventTimeMs > MAX_EVENT_AGE_MS) {
      logger?.warn?.(`Ignored stale telemetry (>180s old) from Machine ${socket.machineId}`);
      return { accepted: false, code: 'STALE_TELEMETRY' };
    } else {
      eventDate = new Date(eventTimeMs);
    }
  }
  ```

### 6.2 Out-of-Order Monotonic Protection
- If an agent sends an out-of-order delayed packet after a newer packet was already persisted:
  ```javascript
  if (device.lastTelemetryAt && eventDate < device.lastTelemetryAt) {
    logger?.warn?.(`Ignored out-of-order telemetry for device ${device.id}`);
    return { accepted: true, code: 'OUT_OF_ORDER_IGNORED', printerDeviceId: device.id };
  }
  ```
- Ensures newer status can never be overwritten by an older, delayed network delivery.

---

## 7. Customer QR API Integration (`printerQr.service.js`)

In [backend/src/services/printerQr.service.js:861-875](file:///D:/PrintGo-S3K-MULTIPRINTER-CANDIDATE/backend/src/services/printerQr.service.js#L861-L875), when a customer scans the counter QR `pq_YCuM5Lr2...` (`qr.printerDeviceId == null`):
1. `availability` is evaluated via `getMachineAvailability(qr.machine.id, prisma)`.
2. Because the default Epson bridge now writes fresh rows to `PrinterStatus`, `availability.isReady` is `true`, `availability.status` is `'ONLINE'`, and `availability.statusMessage` is `'Printer Ready'`.
3. To enrich the response metadata without breaking contracts, when `qr.printerDeviceId` is null, look up the machine's active default device:
   ```javascript
   const activeDefaultDevice = !qr.printerDevice
     ? await prisma.printerDevice.findFirst({
         where: { machineId: qr.machineId, isDefault: true, status: 'ACTIVE' },
         select: { id: true, displayName: true, printerModel: true, healthStatus: true, lastTelemetryAt: true }
       })
     : null;
   ```
4. Output payload:
   - `printerDeviceId`: `qr.printerDevice?.id || activeDefaultDevice?.id || null`
     → Populates **`"619665e1-3c64-44eb-8f57-cb8c3c895e9b"`**.
   - `deviceHealth`: `qr.printerDevice?.healthStatus || activeDefaultDevice?.healthStatus || null`
     → Populates **`"ONLINE"`**.
   - `lastTelemetryAt`: Fresh timestamp string.
   - `paperStatus`: Preserved **`"UNKNOWN"`**.
   - `tonerStatus`: Preserved **`"UNKNOWN"`**.

---

## 8. Required Test Suite Matrix

| # | Test Suite | Test Scenario | Expected Outcome |
| :---: | :--- | :--- | :--- |
| **1** | `printer_agent_protocol.test.js` | Telemetry from approved default printer (`isDefault: true`) | Updates `PrinterDevice.healthStatus = 'ONLINE'` AND inserts `PrinterStatus` row linked to `printerDeviceId`. |
| **2** | `printer_agent_protocol.test.js` | Telemetry from approved non-default printer (`isDefault: false`) | Updates `PrinterDevice` only. **Zero rows inserted into `PrinterStatus`**. |
| **3** | `printer_agent_protocol.test.js` | Telemetry with `paperStatus: 'UNKNOWN', tonerStatus: 'UNKNOWN'` | Persists `'UNKNOWN'` in `PrinterStatus` row. **Does NOT convert to `'OK'`**. |
| **4** | `printer_agent_protocol.test.js` | Telemetry with out-of-order timestamp | Rejects / ignores update; preserves newer status in database. |
| **5** | `printer_agent_protocol.test.js` | Telemetry from unapproved or disabled default printer | Rejects bridge; does not insert into `PrinterStatus`. |
| **6** | `printer_agent_protocol.test.js` | Telemetry with `isError: true, errorMessage: 'Out of Paper'` | Maps to `healthStatus: 'PAPER_OUT'`, `isOnline: false`, `paperStatus: 'OUT'`. |
| **7** | `printer_agent_protocol.test.js` | Telemetry with `isError: true, errorMessage: 'Printer Offline'` | Maps to `healthStatus: 'OFFLINE'`, `isOnline: false`. |
| **8** | `printer_telemetry_persistence.test.js` | `getMachineAvailability` with bridged `PrinterStatus` | Returns `isReady: true, status: 'ONLINE', statusMessage: 'Printer Ready'`. |
| **9** | `phase2_printer_qr_services_and_api.test.js` | Customer QR query on machine-level QR flyer | Returns `isOnline: true, hardwareStatus: 'ONLINE'`, populates default `printerDeviceId`. |

---

## 9. Risks and Backward-Compatibility Analysis

| Risk Area | Risk Level | Mitigation in Design |
| :--- | :---: | :--- |
| **Secondary printer overwrite** | **NONE** | Hard-locked by `device.isDefault === true` check. Only the singular default device can write machine availability. |
| **Schema breakage** | **NONE** | `printerDeviceId` already exists as a nullable column in `PrinterStatus` with an index. Zero schema migrations. |
| **Customer QR flyer disruption** | **NONE** | Preserves public code `pq_YCuM5Lr2...` and URL route. Transitions status from `"Printer Status Unavailable"` to `"Printer Ready"`. |
| **False positive consumable reporting** | **NONE** | UNKNOWN paper/toner is explicitly whitelisted in validation, preventing fallback to `'OK'`. |
| **Performance / Socket latency** | **LOW** | Device query already runs in `handlePrinterDeviceTelemetry`. Adding fields to the existing `SELECT` adds 0 queries. |

---

## 10. Exact Files Requiring Modification & Recommended Sequence

### File List:
1. `backend/src/services/printerAgentProtocol.service.js` (Expand device selection, bridge default device telemetry to `PrinterStatus` and `Machine`, validate timestamps and UNKNOWN values).
2. `backend/src/socket.js` (Allow broadcast of bridged machine availability).
3. `backend/src/services/printerQr.service.js` (Enrich machine-level QR info with active default device ID and health).
4. `backend/tests/printer_agent_protocol.test.js` (Add 7 unit tests covering matrix above).

### Recommended Implementation Sequence:
1. **Preflight:** Verify git status and ensure candidate workspace is clean.
2. **Service Layer Implementation:** Update `printerAgentProtocol.service.js` with the default printer bridge and UNKNOWN preservation.
3. **QR Layer Enrichment:** Update `printerQr.service.js` to bind default device metadata on machine-level QR lookups.
4. **Unit & Regression Testing:** Run `jest printer_agent_protocol.test.js` and full backend regression suite.
5. **Review & Audit:** Run git diff audit and preflight verification before any staging deployment.
