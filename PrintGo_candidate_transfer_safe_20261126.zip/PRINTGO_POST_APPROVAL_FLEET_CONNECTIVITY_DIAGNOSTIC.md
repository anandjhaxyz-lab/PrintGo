# PRINTGO — POST-APPROVAL PRINTER FLEET CONNECTIVITY DIAGNOSTIC REPORT

**Project:** PrintGo Multi-Printer Fleet  
**Host PC:** `DESKTOP-QB6Q3BC`  
**Workspace:** `D:\PrintGo-S3K-MULTIPRINTER-CANDIDATE`  
**Backend:** `https://printgo-backend-staging.onrender.com`  
**Machine Display Name:** `Main Shop Printer`  
**Authoritative Machine ID:** `d010496f-f176-41fe-9c98-efd2213a4a0e`  
**Diagnostic Mode:** STRICTLY READ-ONLY  
**Execution Timestamp:** 2026-11-24T04:38:30+05:30  
**Diagnostic Verdict:** **`PARTIAL CONNECTIVITY — SPECIFIC DEVICES NOT MONITORED`**

---

## 1. Executive Summary

Three printer devices were approved and registered as `ACTIVE` in the PrintGo Staging database:
1. **Epson L6460 Series** (`USB019`) — Approved
2. **HP LaserJet Professional M1136 MFP (Copy 1)** (`USB011`) — Approved (`isDefault: false`)
3. **Canon Generic Plus UFR II (Copy 2)** (`USB001`) — Approved (`isDefault: false`)

While the Admin UI shows all three devices with status `ACTIVE` in the registry table, the **Main Shop Printer Fleet Telemetry Card** displays:
> **`PRINTER DISCONNECTED`**

### **Core Findings:**
1. **The Cloud Agent Connection is Healthy:**  
   The candidate printer agent (PID `516`) is actively running, WebSocket-connected to `printgo-backend-staging` (`Socket ID: LWKROx-QlctPbZ1zAAAD`), and streaming keep-alive pings.
2. **Approved Devices Are Not Yet Monitored by the Agent:**  
   The agent connected at `02:36 AM IST` (before the three devices were approved). In the backend architecture, `approvePrinterDiscovery` records approvals in PostgreSQL but does **not push** an asynchronous registry reload event to connected agent sockets. The agent only fetches the registry at connection handshake (`printer_agent_hello`) or at print dispatch time. Consequently, the agent log reports:  
   `0 approved device(s) have independent monitors.`  
   Neither the HP nor the Canon device has an active device monitor running.
3. **Fallback Legacy Monitor Triggers `PRINTER_DISCONNECTED`:**  
   Because `fleetManager.monitors.size === 0`, the agent falls back to monitoring the single default queue defined in `.env` (`PRINTER_NAME=EPSON L6460 Series`).
4. **Physical USB Hardware State (`CM_PROB_PHANTOM`):**  
   Windows Plug-and-Play (`Get-PnpDevice`) reveals that `EPSON L6460 Series`, `HP M1136`, and `Canon 4545` currently have status `Unknown` with error code `CM_PROB_PHANTOM` (Windows Error 45: device unplugged or powered off).  
   Because the physical printer hardware is turned off or disconnected from the USB ports:
   - Windows WMI reports `Win32_Printer.WorkOffline = True` (Attributes bit `0x0400`).
   - The agent's `SpoolerMonitor` interprets `WorkOffline : True` as `isError: true` (`"Printer Offline"`).
   - The backend sets `PrinterStatus.isOnline = false`.
   - `printerAvailability.service.js` evaluates `if (!isOnline) return PRINTER_DISCONNECTED`.
   - The Admin UI card displays **`PRINTER DISCONNECTED`**.

---

## 2. Detailed Findings by Diagnostic Item

### Item 1: Printer Agent Process, Uptime & WebSocket Connection
- **Process ID (PID):** `516` (`C:\Program Files\nodejs\node.exe index.js`)
- **Working Directory:** `D:\PrintGo-S3K-MULTIPRINTER-CANDIDATE\printer-agent`
- **Parent Process:** PID `17032` (`scratch\diag_spawn.js`)
- **Uptime:** Running persistently since `2026-11-24 02:36:44 AM IST` (over 2 hours uninterrupted).
- **Socket Connection:** Active WebSocket transport connected to `https://printgo-backend-staging.onrender.com`.  
  Latest Socket ID: `LWKROx-QlctPbZ1zAAAD`.

### Item 2: Backend Machine Authentication & Heartbeat
- **Authentication:** `MACHINE_KEY` successfully validated by Staging backend.
- **Machine Registration:** `Main Shop Printer` (`d010496f-f176-41fe-9c98-efd2213a4a0e`).
- **Heartbeat & Keep-Alive:** Pings streaming every 30 seconds to `/api/health`.

### Item 3 & 4: Agent Logs & Device Synchronization Events
From active process output (`task-7292.log`):
```
OUT: ✅ Connected to cloud backend! (Socket ID: LWKROx-QlctPbZ1zAAAD)
OUT: ✅ Registration Success. Machine: Main Shop Printer
OUT: ✅ Multi-printer protocol v1 accepted for Machine d010496f-f176-41fe-9c98-efd2213a4a0e (limit: 10)
OUT: 🖨️ Printer fleet synchronized: 14 Windows queue(s) discovered; 0 approved device(s) have independent monitors.
OUT: ✅ Backend received discovery inventory: 14 queue(s).
OUT: 📡 Keep-Alive ping sent to https://printgo-backend-staging.onrender.com/api/health
```
- **Finding:** The agent received the initial registry when `devices = []`.
- When the 3 devices were approved in the Admin UI, the backend did not emit `printer_device_registry` to the agent.
- The agent has **not received** a subsequent device synchronization event.

### Item 5: Independent Printer Monitoring Implementation
- **Fleet Manager Implementation:**  
  `PrinterFleetManager` in `printer-agent/src/printerFleetManager.js` supports independent `SpoolerMonitor` instances per approved `printerDeviceId`.
- **Current Operational State:**  
  `fleetManager.monitors.size === 0`.  
  Independent monitoring is **currently disabled/idle** because the agent's internal registry has not re-synchronized.
- **Fallback Behavior:**  
  The agent falls back to `spoolerMonitor.checkPrinterStatus(socket)` on the legacy `.env` printer: `EPSON L6460 Series`.

### Item 6: Windows Queues and Physical Hardware Status
Windows spooler and hardware query results on `DESKTOP-QB6Q3BC`:

| Target Printer | Windows Queue | Port | Spooler Queue Status | Physical PnP Hardware State | WMI WorkOffline |
|---|---|---|:---:|:---:|:---:|
| **Epson L6460** | `EPSON L6460 Series` | `USB019` | Normal | `CM_PROB_PHANTOM` (Disconnected/Off) | **True** (0x0400) |
| **HP M1136** | `HP LaserJet Professional M1136 MFP (Copy 1)` | `USB011` | Normal | `CM_PROB_PHANTOM` (Disconnected/Off) | **True** (0x0400) |
| **Canon 4545** | `Canon Generic Plus UFR II (Copy 2)` | `USB001` | Normal | `CM_PROB_PHANTOM` (Disconnected/Off) | **True** (0x0400) |

- **Windows Print Spooler Service:** `Running`.
- **Physical USB Connection:** All three physical USB printer devices are physically **unplugged or powered off**. Windows PnP marks them as `CM_PROB_PHANTOM` (error code 45).

### Item 7: Printer Status Reporting Routing
In `printer-agent/index.js` (lines 195–207) and `printer-agent/src/spooler.js`:
- Because `fleetManager.monitors.size === 0`, status updates are emitted via `spoolerMonitor.emitStatus()`.
- The update payload does **not** include `printerDeviceId` (it sends `{ printerName: 'EPSON L6460 Series', isError: true, errorMessage: 'Printer Offline' }`).
- In `backend/src/socket.js` (line 307), status updates without `printerDeviceId` update the legacy `PrinterStatus` table under `machineId`.
- No status is currently being reported for the individual HP or Canon `printerDeviceId`s.

### Item 8: Admin UI Fleet Status Architecture
In `frontend/src/components/admin/views/PrintersView.jsx` (line 356) and `backend/src/modules/admin/admin.controller.js` (line 79):
```javascript
const availability = computePrinterAvailability(m, latestStatus);
hardwareStatus: availability.status,
```
- The **Main Shop Printer Fleet Overview Card** displays the status of the **Machine record**, NOT an aggregation of all approved child devices.
- It derives status from `machine.printerStatuses[0]` (the legacy stream).
- When `isOnline === false`, `computePrinterAvailability` returns `PRINTER_DISCONNECTED`.
- `PrintersView.jsx` line 429 renders: `{machine.hardwareStatus ? machine.hardwareStatus.replace('_', ' ') : 'OFFLINE'}` &rarr; **`"PRINTER DISCONNECTED"`**.

### Item 9: Epson Front Desk Counter QR Preservation
- Verified in `PrintersView.jsx` (lines 374–389): `machineQrData[machine.id]` points to the active counter QR (`QR_S3K_01`).
- The 3 approvals explicitly submitted `isDefault: false`, preventing default displacement.
- The Front Desk Counter QR remains active and mapped to the default Epson device.

### Item 10: Root Cause of "PRINTER DISCONNECTED"
The dashboard reports `PRINTER DISCONNECTED` due to two converging factors:
1. **Physical State:** The physical USB cables are disconnected or the printers are switched off on `DESKTOP-QB6Q3BC`, causing Windows to set `WorkOffline = True`.
2. **Telemetry Flow:** The agent is checking the offline Epson queue via the legacy spooler monitor and reporting `isError: true` to `PrinterStatus`. The UI card displays this machine-level offline state.

---

## 3. Evidence Table by Physical Printer

| Diagnostic Check | Epson L6460 Series | HP LaserJet M1136 MFP | Canon imageRUNNER 4545 |
|---|---|---|---|
| **Windows Queue Name** | `EPSON L6460 Series` | `HP LaserJet Professional M1136 MFP (Copy 1)` | `Canon Generic Plus UFR II (Copy 2)` |
| **Assigned Port** | `USB019` | `USB011` | `USB001` |
| **Driver Name** | `EPSON L6460 Series` | `HP LaserJet Professional M1136 MFP` | `Canon Generic Plus UFR II` |
| **Database Approval Status** | `ACTIVE` | `ACTIVE` (`isDefault: false`) | `ACTIVE` (`isDefault: false`) |
| **Physical USB State** | `CM_PROB_PHANTOM` (Off/Unplugged) | `CM_PROB_PHANTOM` (Off/Unplugged) | `CM_PROB_PHANTOM` (Off/Unplugged) |
| **WMI WorkOffline** | `True` | `True` | `True` |
| **Agent Independent Monitor** | Fallback legacy monitor only | Not monitored (registry not refreshed) | Not monitored (registry not refreshed) |
| **Current Telemetry Status** | `Printer Offline` (`isOnline: false`) | No telemetry reported | No telemetry reported |

---

## 4. Remediation Steps (When Authorized)

To restore live telemetry to `ONLINE` / `Printer Ready`:
1. **Physical Action (Operator):**  
   Turn ON the physical power switches for the printers and ensure USB cables are firmly connected to ports `USB019`, `USB011`, and `USB001` on `DESKTOP-QB6Q3BC`. Confirm Windows PnP detects them.
2. **Agent Registry Synchronization:**  
   Once the physical printers are powered on, triggering a fresh registry sync on the Agent (e.g. via an agent reconnect, or dispatching a test print) will cause the Agent to fetch the 3 approved devices and launch independent monitors for each queue.

---

## 5. Final Diagnostic Verdict

```
================================================================================
                    FLEET CONNECTIVITY DIAGNOSTIC VERDICT
================================================================================
  VERDICT: PARTIAL CONNECTIVITY — SPECIFIC DEVICES NOT MONITORED
================================================================================
```
