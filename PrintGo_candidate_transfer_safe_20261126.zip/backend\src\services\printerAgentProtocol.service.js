const { recordPrinterDiscoveryInventory } = require('./printerDiscovery.service');

const AGENT_PROTOCOL_VERSION = 1;
const MAX_REGISTERED_PRINTERS = 10;
const MAX_DISCOVERED_QUEUES = 50;
const MAX_QUEUE_NAME_LENGTH = 256;

class PrinterAgentProtocolError extends Error {
  constructor(code, message) {
    super(message);
    this.name = 'PrinterAgentProtocolError';
    this.code = code;
  }
}

const isPlainObject = (value) => (
  value !== null &&
  typeof value === 'object' &&
  !Array.isArray(value)
);

const boundedText = (value, maxLength, fieldName, required = false) => {
  if (value === null || value === undefined) {
    if (required) throw new PrinterAgentProtocolError('INVALID_' + fieldName.toUpperCase(), `${fieldName} is required.`);
    return null;
  }
  if (typeof value !== 'string') {
    throw new PrinterAgentProtocolError('INVALID_' + fieldName.toUpperCase(), `${fieldName} must be a string.`);
  }
  const normalized = value.trim();
  if ((!normalized && required) || normalized.length > maxLength || /[\u0000-\u001f\u007f]/.test(normalized)) {
    throw new PrinterAgentProtocolError('INVALID_' + fieldName.toUpperCase(), `${fieldName} is empty or invalid.`);
  }
  return normalized || null;
};

const nullableBoolean = (value, fieldName) => {
  if (value === null || value === undefined) return null;
  if (typeof value !== 'boolean') {
    throw new PrinterAgentProtocolError('INVALID_' + fieldName.toUpperCase(), `${fieldName} must be boolean or null.`);
  }
  return value;
};

const nullableStatusValue = (value, fieldName) => {
  if (value === null || value === undefined) return null;
  if (typeof value === 'number' && Number.isFinite(value)) return value;
  if (typeof value === 'string' && value.length <= 64 && !/[\u0000-\u001f\u007f]/.test(value)) return value;
  throw new PrinterAgentProtocolError('INVALID_' + fieldName.toUpperCase(), `${fieldName} must be a short string, finite number or null.`);
};

function validateAgentHello(payload) {
  if (!isPlainObject(payload)) {
    return { accepted: false, code: 'INVALID_HELLO', reason: 'Agent hello payload must be an object.' };
  }

  if (payload.protocolVersion !== AGENT_PROTOCOL_VERSION) {
    return {
      accepted: false,
      code: 'UNSUPPORTED_PROTOCOL_VERSION',
      reason: `Agent protocol version ${payload.protocolVersion} is not supported.`
    };
  }

  if (!Number.isInteger(payload.journalSchemaVersion) || payload.journalSchemaVersion < 1 || payload.journalSchemaVersion > 2) {
    return {
      accepted: false,
      code: 'UNSUPPORTED_JOURNAL_SCHEMA',
      reason: 'Agent journal schema version is not supported by this backend.'
    };
  }

  let agentVersion;
  let installationId;
  let host;
  try {
    agentVersion = boundedText(payload.agentVersion, 32, 'agentVersion') || 'unknown';
    installationId = boundedText(payload.installationId, 128, 'installationId');
    if (!isPlainObject(payload.host)) {
      throw new PrinterAgentProtocolError('INVALID_HOST', 'Agent host information is required.');
    }
    host = {
      platform: boundedText(payload.host.platform, 24, 'host.platform', true),
      arch: boundedText(payload.host.arch, 24, 'host.arch', true),
      release: boundedText(payload.host.release, 64, 'host.release')
    };
  } catch (error) {
    return {
      accepted: false,
      code: error.code || 'INVALID_HELLO',
      reason: error.message
    };
  }

  const capabilities = isPlainObject(payload.capabilities) ? payload.capabilities : {};
  const maxPrinters = Number.isInteger(capabilities.maxPrinters) ? capabilities.maxPrinters : 0;
  const majorVersion = parseInt(String(host.release || '').split('.')[0], 10);
  const isWindows10Or11 = Number.isFinite(majorVersion) && majorVersion >= 10;
  const supportsMultiPrinter =
    host.platform === 'win32' &&
    host.arch === 'x64' &&
    isWindows10Or11 &&
    capabilities.multiPrinter === true &&
    capabilities.printerDiscovery === true &&
    maxPrinters >= 1 &&
    maxPrinters <= MAX_REGISTERED_PRINTERS &&
    payload.journalSchemaVersion >= 2;

  return {
    accepted: true,
    protocolVersion: AGENT_PROTOCOL_VERSION,
    agentVersion,
    installationId,
    journalSchemaVersion: payload.journalSchemaVersion,
    host,
    supportsMultiPrinter,
    maxPrinters: supportsMultiPrinter ? maxPrinters : 1
  };
}

async function getPrinterDeviceRegistry(prisma, machineId) {
  if (!machineId || typeof machineId !== 'string') {
    throw new PrinterAgentProtocolError('MACHINE_ID_REQUIRED', 'Authenticated Machine identity is required.');
  }
  if (!prisma?.printerDevice || typeof prisma.printerDevice.findMany !== 'function') {
    throw new PrinterAgentProtocolError('REGISTRY_UNAVAILABLE', 'PrinterDevice registry is unavailable.');
  }

  // Only return devices bound to this authenticated Machine. Unbound legacy
  // placeholder devices stay on the old PRINTER_NAME path until explicitly mapped.
  const rows = await prisma.printerDevice.findMany({
    where: {
      machineId,
      windowsPrinterName: { not: null }
    },
    orderBy: [{ sortOrder: 'asc' }, { createdAt: 'asc' }],
    select: {
      id: true,
      displayName: true,
      windowsPrinterName: true,
      status: true,
      approvedAt: true,
      sortOrder: true
    }
  });

  const devices = (Array.isArray(rows) ? rows : []).filter((row) => (
    row &&
    typeof row.windowsPrinterName === 'string' &&
    row.windowsPrinterName.trim().length > 0
  ));

  if (devices.length > MAX_REGISTERED_PRINTERS) {
    throw new PrinterAgentProtocolError(
      'FLEET_LIMIT_EXCEEDED',
      `Machine ${machineId} has more than ${MAX_REGISTERED_PRINTERS} queue-bound PrinterDevice records.`
    );
  }

  return devices.map((device) => ({
    id: device.id,
    displayName: device.displayName,
    windowsPrinterName: device.windowsPrinterName,
    status: device.status,
    approvedAt: device.approvedAt ? new Date(device.approvedAt).toISOString() : null,
    sortOrder: device.sortOrder
  }));
}

function validateDiscoveredPrinterInventory(payload) {
  if (!isPlainObject(payload) || payload.protocolVersion !== AGENT_PROTOCOL_VERSION) {
    throw new PrinterAgentProtocolError('INVALID_INVENTORY_REPORT', 'Inventory report protocol version is invalid.');
  }

  const reported = payload.discoveredPrinters;
  if (!Array.isArray(reported) || reported.length > MAX_DISCOVERED_QUEUES) {
    throw new PrinterAgentProtocolError(
      'INVALID_INVENTORY_COUNT',
      `Inventory report must contain an array of at most ${MAX_DISCOVERED_QUEUES} discovered queues.`
    );
  }

  const seen = new Set();
  return reported.map((row) => {
    if (!isPlainObject(row)) {
      throw new PrinterAgentProtocolError('INVALID_INVENTORY_RECORD', 'Discovered queue record must be an object.');
    }

    const windowsPrinterName = boundedText(row.windowsPrinterName, MAX_QUEUE_NAME_LENGTH, 'windowsPrinterName', true);
    const key = windowsPrinterName.toLowerCase();
    if (seen.has(key)) {
      throw new PrinterAgentProtocolError('DUPLICATE_DISCOVERED_QUEUE', 'Inventory report contains duplicate Windows queue names.');
    }
    seen.add(key);

    const connectionType = row.connectionType === undefined ? 'Unknown' : row.connectionType;
    if (!['USB', 'Network', 'Unknown'].includes(connectionType)) {
      throw new PrinterAgentProtocolError('INVALID_CONNECTION_TYPE', 'Discovered queue connection type is invalid.');
    }

    return {
      windowsPrinterName,
      driverName: boundedText(row.driverName, MAX_QUEUE_NAME_LENGTH, 'driverName'),
      portName: boundedText(row.portName, MAX_QUEUE_NAME_LENGTH, 'portName'),
      connectionType,
      printerStatus: nullableStatusValue(row.printerStatus, 'printerStatus'),
      detectedErrorState: nullableStatusValue(row.detectedErrorState, 'detectedErrorState'),
      workOffline: nullableBoolean(row.workOffline, 'workOffline'),
      shared: nullableBoolean(row.shared, 'shared'),
      network: nullableBoolean(row.network, 'network'),
      isDefault: nullableBoolean(row.isDefault, 'isDefault')
    };
  });
}

async function handlePrinterAgentHello({ socket, prisma, logger, payload }) {
  if (socket?.userType !== 'printer' || !socket.machineId) {
    return { accepted: false, code: 'UNAUTHORIZED_AGENT' };
  }

  // A repeated malformed hello must revoke any previously negotiated fleet capability.
  socket.agentProtocol = null;
  socket.data = socket.data || {};
  socket.data.agentProtocol = null;
  const connectionId = typeof payload?.connectionId === 'string' && /^[A-Za-z0-9_-]{1,128}$/.test(payload.connectionId)
    ? payload.connectionId
    : null;
  const hello = validateAgentHello(payload);
  if (!hello.accepted) {
    socket.emit('printer_agent_hello_ack', { ...hello, connectionId });
    return hello;
  }
  if (!connectionId) {
    const rejected = { accepted: false, code: 'INVALID_CONNECTION_ID', reason: 'Agent connection identity is required.' };
    socket.emit('printer_agent_hello_ack', rejected);
    return rejected;
  }

  socket.agentProtocol = {
    protocolVersion: hello.protocolVersion,
    agentVersion: hello.agentVersion,
    installationId: hello.installationId,
    journalSchemaVersion: hello.journalSchemaVersion,
    supportsMultiPrinter: hello.supportsMultiPrinter,
    connectionId,
    connectedAt: new Date()
  };
  // Socket.IO fetchSockets() exposes socket.data on RemoteSocket instances.
  socket.data = socket.data || {};
  socket.data.agentProtocol = socket.agentProtocol;

  socket.emit('printer_agent_hello_ack', {
    accepted: true,
    protocolVersion: AGENT_PROTOCOL_VERSION,
    machineId: socket.machineId,
    connectionId,
    supportsMultiPrinter: hello.supportsMultiPrinter,
    maxPrinters: hello.maxPrinters,
    journalSchemaVersion: hello.journalSchemaVersion
  });

  if (!hello.supportsMultiPrinter) {
    return { accepted: true, supportsMultiPrinter: false };
  }

  try {
    const devices = await getPrinterDeviceRegistry(prisma, socket.machineId);
    socket.emit('printer_device_registry', {
      protocolVersion: AGENT_PROTOCOL_VERSION,
      machineId: socket.machineId,
      connectionId,
      issuedAt: new Date().toISOString(),
      devices
    });
    return { accepted: true, supportsMultiPrinter: true, deviceCount: devices.length };
  } catch (error) {
    logger?.error?.(`Failed to load PrinterDevice registry for Machine ${socket.machineId}:`, error);
    socket.emit('printer_device_registry_error', {
      connectionId,
      code: error.code || 'REGISTRY_UNAVAILABLE',
      retryable: true,
      message: 'Printer registry could not be loaded. Existing legacy printer operation is unchanged.'
    });
    return { accepted: true, supportsMultiPrinter: true, registryLoaded: false };
  }
}

async function handlePrinterDeviceRegistryRequest({ socket, prisma, logger, requestId }) {
  if (socket?.userType !== 'printer' || !socket.machineId) {
    return { accepted: false, code: 'UNAUTHORIZED_AGENT' };
  }
  if (socket.agentProtocol?.supportsMultiPrinter !== true) {
    socket.emit('printer_device_registry_error', {
      requestId: typeof requestId === 'string' ? requestId : null,
      connectionId: socket.agentProtocol?.connectionId || null,
      code: 'AGENT_PROTOCOL_NOT_NEGOTIATED',
      retryable: false,
      message: 'Multi-printer protocol must be negotiated before requesting a device registry.'
    });
    return { accepted: false, code: 'AGENT_PROTOCOL_NOT_NEGOTIATED' };
  }
  if (typeof requestId !== 'string' || !/^[A-Za-z0-9_-]{1,128}$/.test(requestId)) {
    socket.emit('printer_device_registry_error', {
      requestId: null,
      connectionId: socket.agentProtocol?.connectionId || null,
      code: 'INVALID_REGISTRY_REQUEST_ID',
      retryable: false,
      message: 'A valid registry request ID is required.'
    });
    return { accepted: false, code: 'INVALID_REGISTRY_REQUEST_ID' };
  }

  try {
    // Never trust Machine identity supplied in the event payload.
    const devices = await getPrinterDeviceRegistry(prisma, socket.machineId);
    socket.emit('printer_device_registry', {
      protocolVersion: AGENT_PROTOCOL_VERSION,
      machineId: socket.machineId,
      connectionId: socket.agentProtocol.connectionId,
      issuedAt: new Date().toISOString(),
      requestId,
      devices
    });
    return { accepted: true, requestId, deviceCount: devices.length };
  } catch (error) {
    logger?.error?.(`Failed to refresh PrinterDevice registry for Machine ${socket.machineId}:`, error);
    socket.emit('printer_device_registry_error', {
      requestId,
      connectionId: socket.agentProtocol?.connectionId || null,
      code: error.code || 'REGISTRY_UNAVAILABLE',
      retryable: true,
      message: 'Printer registry could not be refreshed. Device-bound dispatch must remain blocked.'
    });
    return { accepted: false, requestId, code: error.code || 'REGISTRY_UNAVAILABLE' };
  }
}

async function handlePrinterInventoryReport({ socket, io, logger, prisma, payload }) {
  if (socket?.userType !== 'printer' || !socket.machineId) {
    return { accepted: false, code: 'UNAUTHORIZED_AGENT' };
  }
  if (socket.agentProtocol?.supportsMultiPrinter !== true) {
    socket.emit('printer_inventory_report_ack', {
      accepted: false,
      code: 'AGENT_PROTOCOL_NOT_NEGOTIATED',
      message: 'Multi-printer capability must be negotiated before inventory can be reported.'
    });
    return { accepted: false, code: 'AGENT_PROTOCOL_NOT_NEGOTIATED' };
  }

  try {
    const discoveredPrinters = validateDiscoveredPrinterInventory(payload);
    await recordPrinterDiscoveryInventory(prisma, socket.machineId, discoveredPrinters);
    const report = {
      machineId: socket.machineId,
      machineName: socket.machineName || null,
      reportedAt: new Date().toISOString(),
      discoveredPrinters
    };

    // Persist for Admin review only. Emitted to tenant company room and superadmins.
    let companyId = socket.companyId || null;
    if (!companyId && prisma.machine && typeof prisma.machine.findUnique === 'function') {
      try {
        const machine = await prisma.machine.findUnique({
          where: { id: socket.machineId },
          select: { companyId: true }
        });
        companyId = machine?.companyId || null;
      } catch {
        // Fallback to general admin room if machine lookup not available
      }
    }

    if (companyId) {
      io.to(`company_${companyId}`).emit('printer_inventory_report', report);
      io.to('superadmins').emit('printer_inventory_report', report);
    } else {
      io.to('admins').emit('printer_inventory_report', report);
    }
    socket.emit('printer_inventory_report_ack', {
      accepted: true,
      machineId: socket.machineId,
      receivedCount: discoveredPrinters.length
    });
    return { accepted: true, receivedCount: discoveredPrinters.length };
  } catch (error) {
    logger?.warn?.(`Rejected printer inventory report from Machine ${socket.machineId}:`, error.message);
    socket.emit('printer_inventory_report_ack', {
      accepted: false,
      code: error.code || 'INVALID_INVENTORY_REPORT',
      message: error.message
    });
    return { accepted: false, code: error.code || 'INVALID_INVENTORY_REPORT' };
  }
}

function validateTelemetryTimestamp(rawTimestamp, now = Date.now()) {
  if (!rawTimestamp || (typeof rawTimestamp !== 'string' && !(rawTimestamp instanceof Date))) {
    throw new PrinterAgentProtocolError('INVALID_TELEMETRY_TIMESTAMP', 'Device telemetry must contain a timestamp.');
  }
  const eventTime = new Date(rawTimestamp).getTime();
  if (Number.isNaN(eventTime)) {
    throw new PrinterAgentProtocolError('INVALID_TELEMETRY_TIMESTAMP', 'Device telemetry timestamp is invalid.');
  }
  if (eventTime > now + 30000) {
    throw new PrinterAgentProtocolError('FUTURE_TELEMETRY_TIMESTAMP', 'Device telemetry timestamp is more than 30 seconds in the future.');
  }
  if (now - eventTime > 180000) {
    throw new PrinterAgentProtocolError('STALE_TELEMETRY_TIMESTAMP', 'Device telemetry timestamp is older than 180 seconds.');
  }
  return new Date(eventTime);
}

async function handlePrinterDeviceTelemetry({ socket, io, prisma, logger, status, now = Date.now() }) {
  if (socket?.userType !== 'printer' || !socket.machineId) {
    return { accepted: false, code: 'UNAUTHORIZED_AGENT' };
  }
  if (socket.agentProtocol?.supportsMultiPrinter !== true) {
    return { accepted: false, code: 'AGENT_PROTOCOL_NOT_NEGOTIATED' };
  }

  try {
    if (!isPlainObject(status) || typeof status.isError !== 'boolean') {
      throw new PrinterAgentProtocolError('INVALID_DEVICE_TELEMETRY', 'Device telemetry status must contain a boolean isError field.');
    }

    const printerDeviceId = boundedText(status.printerDeviceId, 128, 'printerDeviceId', true);
    const printerName = boundedText(status.printerName, MAX_QUEUE_NAME_LENGTH, 'printerName');

    const errorMessage = boundedText(status.errorMessage, 128, 'errorMessage') || '';
    const message = errorMessage.toLowerCase();
    let healthStatus = 'UNKNOWN';

    if (status.isError === false) {
      healthStatus = 'ONLINE';
    } else if (message.includes('out of paper') || message.includes('paper out')) {
      healthStatus = 'PAPER_OUT';
    } else if (message.includes('paper jam') || message.includes('jam')) {
      healthStatus = 'JAMMED';
    } else if (message.includes('offline') || message.includes('unplugged')) {
      healthStatus = 'OFFLINE';
    } else {
      healthStatus = 'ERROR';
    }

    const connectionType = ['USB', 'Network', 'Unknown'].includes(status.connectionType)
      ? status.connectionType
      : 'Unknown';

    const sourceTelemetry = isPlainObject(status.telemetry) ? status.telemetry : {};
    const telemetry = {
      connectionType,
      portName: boundedText(sourceTelemetry.portName, MAX_QUEUE_NAME_LENGTH, 'telemetry.portName')
    };

    // Backward-compatible fallback for unit test suites mocking prisma without $transaction
    if (typeof prisma?.$transaction !== 'function') {
      const eventDate = status.timestamp ? validateTelemetryTimestamp(status.timestamp, now) : new Date(now);
      const device = await prisma.printerDevice.findFirst({
        where: { id: printerDeviceId, machineId: socket.machineId },
        select: { id: true, windowsPrinterName: true, machine: { select: { companyId: true } } }
      });
      if (!device) {
        logger?.warn?.(`Rejected printer telemetry: device ${printerDeviceId} does not belong to Machine ${socket.machineId}`);
        return { accepted: false, code: 'DEVICE_MACHINE_MISMATCH' };
      }
      if (!device.windowsPrinterName || !printerName || device.windowsPrinterName.toLowerCase() !== printerName.toLowerCase()) {
        logger?.warn?.(`Rejected printer telemetry: reported queue "${printerName}" does not match approved queue "${device.windowsPrinterName}" for device ${device.id}`);
        return { accepted: false, code: 'QUEUE_IDENTITY_MISMATCH' };
      }
      if (prisma.printerDevice.update) {
        await prisma.printerDevice.update({
          where: { id: device.id },
          data: { healthStatus, lastTelemetryAt: eventDate }
        });
      }
      const companyId = socket.companyId || device.machine?.companyId || null;
      const updatePayload = {
        machineId: socket.machineId,
        printerDeviceId: device.id,
        printerName,
        connectionType,
        isError: status.isError,
        errorMessage,
        telemetry,
        healthStatus,
        lastTelemetryAt: eventDate.toISOString()
      };
      if (companyId) {
        io.to(`company_${companyId}`).emit('printer_device_status_update', updatePayload);
        io.to('superadmins').emit('printer_device_status_update', updatePayload);
      } else {
        io.to('admins').emit('printer_device_status_update', updatePayload);
      }
      return { accepted: true, printerDeviceId: device.id, healthStatus };
    }

    const eventDate = validateTelemetryTimestamp(status.timestamp, now);

    // Execute interactive transaction participating in the universal Machine-first row locking protocol
    const result = await prisma.$transaction(async (tx) => {
      // 1. Universal Machine Root Lock
      const lockedMachine = await tx.$queryRaw`SELECT "id" FROM "Machine" WHERE "id" = ${socket.machineId} FOR UPDATE`;
      if (!Array.isArray(lockedMachine) || lockedMachine.length === 0) {
        logger?.warn?.(`Rejected printer telemetry: Machine ${socket.machineId} not found during lock acquisition.`);
        return { accepted: false, code: 'MACHINE_NOT_FOUND' };
      }

      // 2. Canonical Identity & Ownership Revalidation
      const device = await tx.printerDevice.findFirst({
        where: {
          id: printerDeviceId,
          machineId: socket.machineId
        },
        select: {
          id: true,
          windowsPrinterName: true,
          status: true,
          approvedAt: true,
          isDefault: true,
          machine: { select: { companyId: true } }
        }
      });

      if (!device) {
        logger?.warn?.(`Rejected printer telemetry: device ${printerDeviceId} does not belong to Machine ${socket.machineId}`);
        return { accepted: false, code: 'DEVICE_MACHINE_MISMATCH' };
      }

      // Exact queue name check (case-insensitive)
      if (!device.windowsPrinterName || !printerName || device.windowsPrinterName.toLowerCase() !== printerName.toLowerCase()) {
        logger?.warn?.(`Rejected printer telemetry: reported queue "${printerName}" does not match approved queue "${device.windowsPrinterName}" for device ${device.id}`);
        return { accepted: false, code: 'QUEUE_IDENTITY_MISMATCH' };
      }

      // Active status and approval check
      if (device.status !== 'ACTIVE' || !device.approvedAt) {
        logger?.warn?.(`Rejected printer telemetry: device ${device.id} is not ACTIVE or lacks approvedAt.`);
        return { accepted: false, code: 'DEVICE_NOT_ACTIVE_OR_APPROVED' };
      }

      // 3. Atomic Monotonic Compare-and-Set Timestamp Update
      const updateResult = await tx.printerDevice.updateMany({
        where: {
          id: device.id,
          machineId: socket.machineId,
          status: 'ACTIVE',
          approvedAt: { not: null },
          OR: [
            { lastTelemetryAt: null },
            { lastTelemetryAt: { lt: eventDate } }
          ]
        },
        data: {
          healthStatus,
          lastTelemetryAt: eventDate,
          updatedAt: new Date()
        }
      });

      if (updateResult.count === 0) {
        logger?.warn?.(`Dropped out-of-order or stale telemetry packet for device ${device.id} on Machine ${socket.machineId}`);
        return {
          accepted: true,
          skipped: true,
          reason: 'STALE_OR_OUT_OF_ORDER_DROPPED',
          printerDeviceId: device.id,
          bridged: false
        };
      }

      // 4. Default Device Uniqueness Bridge
      let bridged = false;
      if (device.isDefault === true) {
        const activeDefaults = await tx.printerDevice.findMany({
          where: {
            machineId: socket.machineId,
            status: 'ACTIVE',
            approvedAt: { not: null },
            isDefault: true
          },
          select: { id: true }
        });

        if (activeDefaults.length === 1 && activeDefaults[0].id === device.id) {
          // Preserve diagnostics faithfully (never turn UNKNOWN into OK)
          const validPaperStatus = ['OK', 'LOW', 'OUT', 'UNKNOWN'].includes(status.paperStatus)
            ? status.paperStatus
            : (status.telemetry?.paperStatus && ['OK', 'LOW', 'OUT', 'UNKNOWN'].includes(status.telemetry.paperStatus)
                ? status.telemetry.paperStatus
                : 'UNKNOWN');

          const validTonerStatus = ['OK', 'LOW', 'EMPTY', 'UNKNOWN'].includes(status.tonerStatus)
            ? status.tonerStatus
            : (status.telemetry?.tonerStatus && ['OK', 'LOW', 'EMPTY', 'UNKNOWN'].includes(status.telemetry.tonerStatus)
                ? status.telemetry.tonerStatus
                : 'UNKNOWN');

          const isOnline = status.isError === false;
          const jamStatus = status.isError === true && (healthStatus === 'JAMMED' || status.errorMessage?.toLowerCase().includes('jam'));

          await tx.printerStatus.create({
            data: {
              machineId: socket.machineId,
              printerDeviceId: device.id,
              isOnline,
              paperStatus: validPaperStatus,
              tonerStatus: validTonerStatus,
              jamStatus,
              connectionType: connectionType !== 'Unknown' ? connectionType : undefined,
              timestamp: eventDate
            }
          });

          // Machine metadata protection: NEVER update Machine.lastOnline or Machine.printerModel!
          // Only update connectionType if valid and meaningful:
          if (connectionType && connectionType !== 'Unknown') {
            await tx.machine.update({
              where: { id: socket.machineId },
              data: { connectionType }
            });
          }

          bridged = true;
        } else {
          logger?.warn?.(`Default printer bridge skipped for Machine ${socket.machineId}: active defaults count = ${activeDefaults.length}`);
        }
      }

      return {
        accepted: true,
        printerDeviceId: device.id,
        healthStatus,
        bridged,
        lastTelemetryAt: eventDate.toISOString(),
        companyId: socket.companyId || device.machine?.companyId || null,
        printerName,
        connectionType,
        errorMessage,
        telemetry
      };
    }, { timeout: 10000 });

    if (!result.accepted || result.skipped) {
      return result;
    }

    const companyId = result.companyId;
    const updatePayload = {
      machineId: socket.machineId,
      printerDeviceId: result.printerDeviceId,
      printerName: result.printerName,
      connectionType: result.connectionType,
      isError: status.isError,
      errorMessage: result.errorMessage,
      telemetry: result.telemetry,
      healthStatus: result.healthStatus,
      lastTelemetryAt: result.lastTelemetryAt
    };

    if (companyId) {
      io.to(`company_${companyId}`).emit('printer_device_status_update', updatePayload);
      io.to('superadmins').emit('printer_device_status_update', updatePayload);
    } else {
      io.to('admins').emit('printer_device_status_update', updatePayload);
    }

    return result;
  } catch (error) {
    logger?.warn?.(`Rejected device telemetry from Machine ${socket.machineId}:`, error.message);
    return { accepted: false, code: error.code || 'INVALID_DEVICE_TELEMETRY', message: error.message };
  }
}

async function pushPrinterDeviceRegistrySync(io, prisma, machineId, logger = null) {
  if (!io || !machineId || typeof machineId !== 'string') return false;

  try {
    const devices = await getPrinterDeviceRegistry(prisma, machineId);
    const payload = {
      protocolVersion: AGENT_PROTOCOL_VERSION,
      machineId,
      issuedAt: new Date().toISOString(),
      devices
    };

    const roomName = `machine_${machineId}`;
    if (typeof io.in === 'function') {
      const room = io.in(roomName);
      if (typeof room?.fetchSockets === 'function') {
        const recipients = await room.fetchSockets();
        let emittedCount = 0;
        for (const recipient of recipients) {
          const recipientProtocol = recipient?.data?.agentProtocol || recipient?.agentProtocol;
          const connectionId = recipientProtocol?.connectionId;
          if (recipientProtocol?.supportsMultiPrinter !== true ||
              typeof connectionId !== 'string' || !connectionId) continue;
          recipient.emit('printer_device_registry', { ...payload, connectionId });
          emittedCount += 1;
        }
        logger?.info?.(`[FleetSync] Emitted connection-bound printer_device_registry to ${emittedCount} negotiated Agent(s) in ${roomName}`);
        return true;
      }
    }

    // Compatibility path for older Socket.IO adapters. Current Agents require
    // connectionId and will ignore this uncorrelated room broadcast.
    io.to(roomName).emit('printer_device_registry', payload);
    logger?.info?.(`[FleetSync] Emitted legacy-compatible printer_device_registry to ${roomName} (${devices.length} approved devices)`);
    return true;
  } catch (error) {
    logger?.error?.(`[FleetSync] Failed to push printer_device_registry to machine_${machineId}:`, error.message);
    return false;
  }
}

module.exports = {
  AGENT_PROTOCOL_VERSION,
  MAX_REGISTERED_PRINTERS,
  MAX_DISCOVERED_QUEUES,
  PrinterAgentProtocolError,
  validateAgentHello,
  validateTelemetryTimestamp,
  getPrinterDeviceRegistry,
  validateDiscoveredPrinterInventory,
  handlePrinterAgentHello,
  handlePrinterDeviceRegistryRequest,
  handlePrinterInventoryReport,
  handlePrinterDeviceTelemetry,
  pushPrinterDeviceRegistrySync
};
