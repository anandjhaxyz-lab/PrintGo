const { PrismaClient } = require('@prisma/client');

async function inspectDb(dbName) {
  console.log(`\n======================================================`);
  console.log(`DATABASE: ${dbName}`);
  console.log(`======================================================`);
  const prisma = new PrismaClient({
    datasources: {
      db: {
        url: `postgresql://postgres@127.0.0.1:55433/${dbName}`
      }
    }
  });

  try {
    console.log('--- 1. MACHINES ---');
    const machines = await prisma.machine.findMany({
      select: {
        id: true,
        name: true,
        location: true,
        printerModel: true,
        connectionType: true,
        lastOnline: true
      }
    });
    console.log(JSON.stringify(machines, null, 2));

    console.log('\n--- 2. PRINTER DEVICES ---');
    const devices = await prisma.printerDevice.findMany({
      select: {
        id: true,
        machineId: true,
        displayName: true,
        windowsPrinterName: true,
        status: true,
        isDefault: true,
        approvedAt: true,
        healthStatus: true,
        lastTelemetryAt: true
      }
    });
    console.log(JSON.stringify(devices, null, 2));

    console.log('\n--- 3. PRINTER QR CODES ---');
    const qrs = await prisma.printerQr.findMany({
      select: {
        id: true,
        machineId: true,
        printerDeviceId: true,
        status: true,
        createdAt: true,
        publicCode: true
      }
    });
    const redactedQrs = qrs.map(q => ({
      id: q.id,
      machineId: q.machineId,
      printerDeviceId: q.printerDeviceId,
      status: q.status,
      createdAt: q.createdAt,
      publicCodePrefix: q.publicCode ? q.publicCode.substring(0, 10) + '...' : null
    }));
    console.log(JSON.stringify(redactedQrs, null, 2));

    console.log('\n--- 4. RECENT SESSIONS ---');
    const sessions = await prisma.session.findMany({
      take: 5,
      orderBy: { createdAt: 'desc' },
      select: {
        id: true,
        code: true,
        machineId: true,
        printerDeviceId: true,
        createdAt: true
      }
    });
    console.log(JSON.stringify(sessions, null, 2));

    console.log('\n--- 5. RECENT PRINTER STATUS ROWS ---');
    const statuses = await prisma.printerStatus.findMany({
      take: 5,
      orderBy: { timestamp: 'desc' },
      select: {
        id: true,
        machineId: true,
        printerDeviceId: true,
        isOnline: true,
        paperStatus: true,
        tonerStatus: true,
        timestamp: true
      }
    });
    console.log(JSON.stringify(statuses, null, 2));
  } catch (err) {
    console.error(`Error inspecting ${dbName}:`, err.message);
  } finally {
    await prisma.$disconnect();
  }
}

async function run() {
  await inspectDb('printgo_staging');
  await inspectDb('printgo_e2e_phase2_db');
}

run();
