# PRINTGO — PHASE 9.4: FINAL SCHEMA, ADMIN-CONCURRENCY & QR CONTRACT AUDIT REPORT

**Workspace:** `D:\PrintGo-S3K-MULTIPRINTER-CANDIDATE`  
**Mode:** STRICTLY READ-ONLY  
**Date:** 2026-11-24  
**Target Backend:** Staging (`https://printgo-backend-staging.onrender.com`)  
**Target Machine ID:** `d010496f-f176-41fe-9c98-efd2213a4a0e` (`Main Shop Printer`)  
**Target Approved Default Device ID:** `619665e1-3c64-44eb-8f57-cb8c3c895e9b` (`EPSON L6460 Series`)

---

## Executive Summary

Phase 9.4 audits the remaining semantic and integration risks in the Phase 9 design prior to implementation authorization:
1. **Machine Metadata Semantics:** Confirmed that `Machine.printerModel` represents the physical hardware model provisioned on the machine (e.g. `'EPSON L6460 Series'`), whereas `windowsPrinterName` represents a mutable local OS print spooler queue name. We established that **`Machine.printerModel` must NOT be updated by `handlePrinterDeviceTelemetry()`**, preventing corruptions of customer flyers, UI modals, or kiosk receipts.
2. **Admin Concurrency & Locking Protocol:** Inspected all admin code paths mutating `PrinterDevice.isDefault`, `status`, or `approvedAt`. Discovered that the PrintGo backend **already enforces taking the parent `Machine` row lock first (`SELECT "id" FROM "Machine" WHERE "id" = ... FOR UPDATE`)** in `printerDeviceAdmin.service.js` and `printerDiscovery.service.js`. Integrating `handlePrinterDeviceTelemetry()` into this existing protocol provides deterministic, deadlock-free serialization without relying on speculative SSI retries.
3. **Canonical Eligibility & CAS:** Harmonized the validation checks and atomic `updateMany` conditions into a single, unified pipeline eliminating the discrepancies between Phase 9.3 Sections 1.2 and 3.
4. **QR API Contract:** Traced `getMachineAvailability()` and `getPublicPrinterQrInfo()` into the customer frontend (`MobileView.jsx`). Confirmed that populating default device health and linking `PrinterStatus` safely drives the customer flyer into `"Printer Ready"` (`hardwareStatus: 'ONLINE', isOnline: true`), while diagnostics faithfully retain `'UNKNOWN'` for paper and toner.
5. **Socket Broadcast Contract:** Verified existing event names (`printer_status_update` vs `printer_device_status_update`) and rooms (`machine_${machineId}`, `company_${companyId}`, `superadmins`). No novel event shapes are introduced.
6. **Backup & Implementation Readiness:** Confirmed the baseline SHA256 hashes of all four target files. The design is hardened, fully validated against the codebase, and **READY FOR IMPLEMENTATION**.

---

## 1. Machine Metadata Semantics

### 1.1 `Machine.printerModel` vs `windowsPrinterName`

| Field | Source / Model | Meaning & Invariants | Code References |
| :--- | :--- | :--- | :--- |
| **`Machine.printerModel`** | `model Machine` (`backend/prisma/schema.prisma:75`) | The physical manufacturer/model label of the primary printer provisioned for the kiosk (e.g. `'EPSON L6460 Series'`). Displayed to customers on QR flyers, print receipts, and admin kiosk cards. | `scripts/provisionStagingPilot.js:186`<br>`frontend/src/components/admin/views/PrinterQrModals.jsx:98, 323, 766`<br>`frontend/src/components/admin/views/PrintersView.jsx:437`<br>`frontend/src/pages/MobileView.jsx:538` |
| **`windowsPrinterName`** | `model PrinterDevice` (`backend/prisma/schema.prisma:120`) | The arbitrary Windows Spooler queue name on the Agent host (e.g. `"EPSON L6460 Series"`, or `"Front Counter Kiosk"`, or `"Epson Network"`). Controlled by the local Windows user/admin. | `backend/src/services/printerDeviceAdmin.service.js:294`<br>`printer-agent/src/spooler.js:200-220` |
| **`PrinterDevice.printerModel`** | `model PrinterDevice` (`backend/prisma/schema.prisma:121`) | Discovered hardware model string for this specific child device. | `backend/src/services/printerQr.service.js:203` |

### 1.2 Risk of Assigning `windowsPrinterName` to `Machine.printerModel`
- **Data Corruption Risk:** In Phase 9.3 Section 3, a proposal suggested `machineUpdates.printerModel = device.windowsPrinterName`. If an operator renames the local Windows queue to `"Counter Queue 1"`, assigning this to `Machine.printerModel` permanently overwrites the hardware model string across all customer QR flyers, admin views, and mobile headers.
- **Architectural Resolution:**
  `handlePrinterDeviceTelemetry()` **MUST NOT mutate `Machine.printerModel`**.
  `Machine.printerModel` is a static provisioning attribute. The customer QR service already evaluates `qr.printerDevice?.printerModel || qr.machine.printerModel || 'Unknown'` at query time. Therefore, omitting `Machine.printerModel` mutation from telemetry ingestion completely avoids schema corruption while ensuring 100% accuracy.

---

## 2. Admin Concurrency Audit

### 2.1 Inspection of Every Code Path Mutating Device Lifecycle

We inspected every backend code path that mutates `PrinterDevice.isDefault`, `status`, `approvedAt`, or queue mapping:

1. **`approvePrinterDiscovery()` (`backend/src/services/printerDiscovery.service.js:133-136, 189-225`):**
   ```javascript
   // Admin printer mutations take the Machine lock first so concurrent
   // approval/remap flows cannot deadlock while changing queue assignments.
   await tx.$queryRaw`SELECT "id" FROM "Machine" WHERE "id" = ${discoveryReference.machineId} FOR UPDATE`;
   await tx.$queryRaw`SELECT "id" FROM "PrinterDiscovery" WHERE "id" = ${discoveryId} FOR UPDATE`;
   ```
   - Sets `isDefault: false` on previously existing default devices.
   - Creates new `PrinterDevice` with `isDefault: effectiveIsDefault`, `status: 'ACTIVE'`, `approvedAt: new Date()`.
2. **`disablePrinterDevice()` (`backend/src/services/printerDeviceAdmin.service.js:19-21, 102, 115`):**
   ```javascript
   await lockMachineAndDevice(tx, reference.machineId, printerDeviceId);
   // lockMachineAndDevice acquires Machine FOR UPDATE, then PrinterDevice FOR UPDATE
   await tx.printerDevice.update({ where: { id: printerDeviceId }, data: { status: 'DISABLED', healthStatus: 'UNKNOWN' } });
   ```
3. **`enablePrinterDevice()` (`backend/src/services/printerDeviceAdmin.service.js:150, 188`):**
   ```javascript
   await lockMachineAndDevice(tx, reference.machineId, printerDeviceId);
   await tx.printerDevice.update({ where: { id: printerDeviceId }, data: { status: 'ACTIVE', approvedAt: now } });
   ```
4. **`remapPrinterDeviceQueue()` (`backend/src/services/printerDeviceAdmin.service.js:244, 294`):**
   ```javascript
   await lockMachineAndDevice(tx, deviceReference.machineId, printerDeviceId);
   await tx.printerDevice.update({ where: { id: printerDeviceId }, data: { windowsPrinterName, driverName, portName, connectionType, approvedAt: now } });
   ```

### 2.2 Critical Finding: Common Locking Protocol Exists
- **Fact:** The PrintGo application **already enforces a universal parent-row locking protocol across all admin mutation paths**:
  `await tx.$queryRawSELECT "id" FROM "Machine" WHERE "id" = ${machineId} FOR UPDATE;`
- **Telemetry Integration:**
  By having `handlePrinterDeviceTelemetry()` execute:
  ```javascript
  await tx.$queryRaw`SELECT "id" FROM "Machine" WHERE "id" = ${socket.machineId} FOR UPDATE;`;
  ```
  at the start of its interactive transaction, telemetry ingestion participates in the **exact same lock hierarchy**:
  - Step 1: `Machine` (`FOR UPDATE`)
  - Step 2: `PrinterDevice` (`updateMany` / `findFirst`)
  - Step 3: `PrinterStatus` (`create`)
- **Evaluation of SERIALIZABLE vs Row Locking:**
  Because the admin code runs under PostgreSQL default `Read Committed` isolation with explicit `FOR UPDATE` locks, running telemetry under `SERIALIZABLE` without locks would create isolation asymmetry (SSI anomalies can occur when serializable transactions interact with read-committed transactions).
  Conversely, adopting `SELECT ... FROM "Machine" ... FOR UPDATE` directly aligns telemetry with the existing codebase:
  1. It serializes telemetry against any concurrent admin approvals, disables, enables, or queue remaps for that machine.
  2. It guarantees zero deadlocks because all operations lock `Machine` first.
  3. It requires zero retries in normal operation.

---

## 3. Canonical Eligibility and Atomic CAS Conditions

We resolve the discrepancy between Phase 9.3 Section 1.2 (which omitted `approvedAt`) and Section 3 (which included it), defining one canonical condition set:

### 3.1 Pre-Transaction Gate (Fail Fast)
- `socket.userType === 'printer' && socket.machineId`
- `socket.agentProtocol?.supportsMultiPrinter === true`
- `isPlainObject(status) && typeof status.isError === 'boolean'`
- `printerDeviceId` is non-empty string, $\le 128$ chars
- `printerName` is non-empty string, $\le 255$ chars
- Timestamp parsed to `eventDate`:
  - `isNaN(eventDate.getTime())` $\rightarrow$ Reject (`INVALID_TELEMETRY_TIMESTAMP`)
  - `eventDate.getTime() > now + 30_000` $\rightarrow$ Reject (`FUTURE_TELEMETRY_TIMESTAMP`)
  - `now - eventDate.getTime() > 180_000` $\rightarrow$ Reject (`STALE_TELEMETRY_TIMESTAMP`)

### 3.2 In-Transaction Canonical Pipeline
```javascript
return await prisma.$transaction(async (tx) => {
  // 1. Root Lock: Participate in existing application Machine locking protocol
  await tx.$queryRaw`SELECT "id" FROM "Machine" WHERE "id" = ${socket.machineId} FOR UPDATE;`;

  // 2. Identity & Ownership Revalidation
  const device = await tx.printerDevice.findFirst({
    where: {
      id: printerDeviceId,
      machineId: socket.machineId
    },
    select: {
      id: true,
      windowsPrinterName: true,
      status: true,
      approvedAt: true,
      isDefault: true,
      machine: { select: { companyId: true } }
    }
  });

  if (!device) {
    return { accepted: false, code: 'DEVICE_MACHINE_MISMATCH' };
  }

  // 3. Exact Queue Name Check (Case-Insensitive)
  if (!device.windowsPrinterName || device.windowsPrinterName.toLowerCase() !== printerName.toLowerCase()) {
    return { accepted: false, code: 'QUEUE_IDENTITY_MISMATCH' };
  }

  // 4. Approval Check
  if (device.status !== 'ACTIVE' || !device.approvedAt) {
    return { accepted: false, code: 'DEVICE_NOT_ACTIVE_OR_APPROVED' };
  }

  // 5. Canonical Atomic Compare-and-Set (Monotonic Progression)
  const updateResult = await tx.printerDevice.updateMany({
    where: {
      id: device.id,
      machineId: socket.machineId,
      status: 'ACTIVE',
      approvedAt: { not: null },
      OR: [
        { lastTelemetryAt: null },
        { lastTelemetryAt: { lt: eventDate } }
      ]
    },
    data: {
      healthStatus,
      lastTelemetryAt: eventDate,
      updatedAt: new Date()
    }
  });

  if (updateResult.count === 0) {
    // Monotonic ordering check failed (newer packet already committed)
    return {
      accepted: true,
      skipped: true,
      reason: 'STALE_OR_OUT_OF_ORDER_DROPPED',
      printerDeviceId: device.id,
      bridged: false
    };
  }

  // 6. Default Device Uniqueness Check
  let bridged = false;
  if (device.isDefault === true) {
    const activeDefaults = await tx.printerDevice.findMany({
      where: {
        machineId: socket.machineId,
        status: 'ACTIVE',
        approvedAt: { not: null },
        isDefault: true
      },
      select: { id: true }
    });

    if (activeDefaults.length === 1 && activeDefaults[0].id === device.id) {
      // 7. Faithful Preservation of Diagnostics (Never coerce UNKNOWN into OK)
      const validPaperStatus = ['OK', 'LOW', 'OUT', 'UNKNOWN'].includes(status.paperStatus)
        ? status.paperStatus
        : (status.telemetry?.paperStatus && ['OK', 'LOW', 'OUT', 'UNKNOWN'].includes(status.telemetry.paperStatus)
            ? status.telemetry.paperStatus
            : 'UNKNOWN');

      const validTonerStatus = ['OK', 'LOW', 'EMPTY', 'UNKNOWN'].includes(status.tonerStatus)
        ? status.tonerStatus
        : (status.telemetry?.tonerStatus && ['OK', 'LOW', 'EMPTY', 'UNKNOWN'].includes(status.telemetry.tonerStatus)
            ? status.telemetry.tonerStatus
            : 'UNKNOWN');

      const isOnline = status.isError === false;
      const jamStatus = status.isError === true && (healthStatus === 'JAMMED' || status.errorMessage?.toLowerCase().includes('jam'));

      // 8. Machine-Level PrinterStatus Insertion
      await tx.printerStatus.create({
        data: {
          machineId: socket.machineId,
          printerDeviceId: device.id,
          isOnline,
          paperStatus: validPaperStatus,
          tonerStatus: validTonerStatus,
          jamStatus,
          connectionType: connectionType || undefined,
          timestamp: eventDate
        }
      });

      // 9. Update Machine connectionType ONLY (NEVER touch lastOnline or printerModel!)
      if (connectionType && connectionType !== 'Unknown') {
        await tx.machine.update({
          where: { id: socket.machineId },
          data: { connectionType }
        });
      }

      bridged = true;
    }
  }

  return {
    accepted: true,
    printerDeviceId: device.id,
    healthStatus,
    bridged,
    lastTelemetryAt: eventDate.toISOString()
  };
}, { timeout: 10000 });
```

---

## 4. QR API Contract Analysis

### 4.1 Trace from Database to Frontend Customer UI

```mermaid
flowchart TD
    A["Agent Telemetry (Epson L6460)"] -->|bridged=true| B["prisma.printerStatus.create()"]
    B -->|timestamp=eventDate| C["PrinterStatus Table"]
    D["Customer Scans QR Flyer"] --> E["GET /api/auth/printer-qr/:publicCode"]
    E --> F["getMachineAvailability(machineId)"]
    C -->|take 1, orderBy timestamp desc| F
    F --> G["computePrinterAvailability()"]
    G -->|isOnline=true, jam=false, paper!=OUT| H["status: 'ONLINE', isReady: true, statusMessage: 'Printer Ready'"]
    H --> I["getPublicPrinterQrInfo()"]
    I -->|JSON Response| J["MobileView.jsx (Customer Mobile Browser)"]
    J --> K["isPrinterReady = true: Green 'Printer Ready' Banner"]
```

### 4.2 Exact Field Contracts (`printer` object in `GET /api/auth/printer-qr/:publicCode`)

| Field | Source in `getPublicPrinterQrInfo` | Current Value (Phase 8 Audit) | Value After Phase 9 Bridge | Consumer Impact (`MobileView.jsx`) |
| :--- | :--- | :--- | :--- | :--- |
| `isOnline` | `availability.isReady` | `false` | `true` | Enables upload & payment buttons. |
| `hardwareStatus` | `availability.status` | `'UNKNOWN'` | `'ONLINE'` | Sets `isPrinterReady = true`. |
| `statusMessage` | `availability.statusMessage` | `'Printer Status Unavailable'` | `'Printer Ready'` | Displays customer message banner. |
| `printerDeviceId` | `qr.printerDevice.id` or fallback | `null` | `'619665e1-3c64-44eb-8f57-cb8c3c895e9b'` | Identifies target hardware device. |
| `deviceHealth` | `qr.printerDevice.healthStatus` or fallback | `null` | `'ONLINE'` | Informational diagnostic. |
| `paperStatus` | `availability.paperStatus` | `'OK'` (stale) | `'UNKNOWN'` | Accurately reflects WMI 0 diagnostic. |
| `tonerStatus` | `availability.tonerStatus` | `'OK'` (stale) | `'UNKNOWN'` | Accurately reflects WMI 0 diagnostic. |
| `lastTelemetryAt`| Fallback to default device | `null` | ISO Timestamp (<30s) | Diagnostic freshness indicator. |

**Contract Safety Conclusion:**
Populating `printerDeviceId`, `deviceHealth`, and `lastTelemetryAt` from the validated active default device when `qr.printerDeviceId == null` is 100% backwards-compatible. `MobileView.jsx` lines 92–115 specifically check `hardwareStatus` and `statusMessage`; populating the missing fields enhances observability without altering the response schema shape.

---

## 5. Socket Broadcast Contract

We audited all socket event definitions in `backend/src/socket.js` and `backend/src/services/printerAgentProtocol.service.js`:

| Event Name | Emitter | Target Rooms | Payload Shape | Purpose |
| :--- | :--- | :--- | :--- | :--- |
| **`printer_device_status_update`** | `printerAgentProtocol.service.js:460` | `company_${companyId}`, `superadmins` | `{ machineId, printerDeviceId, printerName, connectionType, isError, errorMessage, telemetry, healthStatus, lastTelemetryAt }` | Informs admin fleet overview of individual child printer state. |
| **`printer_status_update`** | `socket.js:347` (existing legacy & bridge) | `machine_${machineId}`, `company_${companyId}`, `superadmins` | `{ machineId, status: 'ONLINE', isReady: true, statusMessage: 'Printer Ready', printerModel, connectionType, paperStatus: 'UNKNOWN', tonerStatus: 'UNKNOWN', jamStatus: false, ... }` | Broadcasts authoritative machine-level availability to active customer kiosk sessions and admin dashboards. |

### Duplicate Broadcast Prevention
- When `status.printerDeviceId` is present and `result.bridged === true`:
  1. `handlePrinterDeviceTelemetry()` emits `printer_device_status_update` (device-level).
  2. `socket.js` awaits the result, obtains fresh `getMachineAvailability(socket.machineId)`, and emits `printer_status_update` (machine-level).
  These two events have **different names**, **different payloads**, and **different consumers**. There is zero duplication or circular looping.

---

## 6. Transaction Retry and Error Handling

### 6.1 Prisma 5 Details
- **Dependency:** `@prisma/client: ^5.22.0` (`backend/package.json`).
- **Error Codes:**
  - `P2034`: Transaction failed due to a write conflict or a deadlock.
  - SQLSTATE `40001`: `serialization_failure` (surfaced in `error.meta` or raw query rejections).
  - SQLSTATE `40P01`: `deadlock_detected`.

### 6.2 Side Effect Analysis
- **Non-database side effects inside transaction:** **NONE.**
- All Socket.IO emissions (`io.to(...).emit(...)`) are strictly executed outside/after the transaction commits.
- If a database query fails or times out, the transaction aborts with zero partial mutations.
- `timeout: 10000` (10 seconds) and `maxWait: 5000` (5 seconds) provide ample headroom for PostgreSQL row-lock acquisition while remaining well within Render's 30-second timeout budget.

---

## 7. Backup and Change-Safety Audit

### 7.1 Proposed Implementation Files and Baseline Hashes

We re-verified the current SHA256 hashes of all four target files:

| # | File Path | Current SHA256 Hash |
| :--- | :--- | :--- |
| 1 | `backend/src/services/printerAgentProtocol.service.js` | `58FF62A0D3684D003DB322291BF6F1FE05081E3E592E048A8FCC057997FFAC0E` |
| 2 | `backend/src/socket.js` | `9A2AA3A57B8D78D351B9704975DBDA533E3B4576CF09CC843FB27DC1F600DE3B` |
| 3 | `backend/src/services/printerQr.service.js` | `B87646822AE972F1C490B80D797AD19C46627F1590C092CFFD86FD04276CF140` |
| 4 | `backend/tests/printer_agent_protocol.test.js` | `11DB703DAA30E5C18CCA115C43F6657DBB78B298982E1557CD98F70935E0A634` |

### 7.2 Strict Change-Safety Rules
- **No Git Checkout / Reset / Clean / Stash:** Strictly prohibited. Working tree contains Phase 1, Phase 6, frontend, and test modifications that must remain intact.
- **Pre-Implementation Backup Gating:**
  Step 1 of implementation will copy these 4 files into `D:\PrintGo-S3K-MULTIPRINTER-CANDIDATE\phase9_pre_implementation_backup\`.
  Before any file is edited, an automated hash check must confirm a 100% match against the hashes above.

---

## 8. Remaining Blockers

**ZERO TECHNICAL BLOCKERS REMAIN.**
All edge cases, schema semantics, concurrency strategies, locking hierarchies, and API contracts have been resolved and verified against the live codebase.

---

## 9. Final Recommendation

### **`READY FOR IMPLEMENTATION`**

Upon receiving your explicit command, execution will proceed according to the verified 7-step checklist:
1. Create backup directory and verify SHA256 hashes against baseline.
2. Implement service layer bridge in `printerAgentProtocol.service.js`.
3. Implement socket handler broadcast in `socket.js`.
4. Implement QR fallback in `printerQr.service.js`.
5. Add unit tests to `printer_agent_protocol.test.js` and run test suites.
6. Verify customer QR API live on Staging backend.
7. Produce Phase 9 Final Implementation Report.
